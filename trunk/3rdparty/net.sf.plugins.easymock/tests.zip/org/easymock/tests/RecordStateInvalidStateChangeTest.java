/*
 * Copyright (c) 2001-2004 OFFIS. This program is made available under the terms of
 * the MIT License.
 */
package org.easymock.tests;

import junit.framework.TestCase;

import org.easymock.MockControl;

public class RecordStateInvalidStateChangeTest extends TestCase {
    MockControl control;
    IMethods mock;

    protected void setUp() {
        control = MockControl.createControl(IMethods.class);
        mock = (IMethods) control.getMock();
    }

    public void testActivateWithoutReturnValue() {
        mock.oneArgumentMethod(false);
        try {
            control.replay();
            fail("IllegalStateException expected");
        } catch (IllegalStateException e) {
            assertEquals(
                "missing behavior definition for the preceeding method call oneArgumentMethod(false)",
                e.getMessage());
        }
    }

    public void testVerifyWithoutActivation() {
        try {
            control.verify();
            fail("IllegalStateException expected");
        } catch (IllegalStateException e) {
            assertEquals(
                "calling verify is not allowed in record state",
                e.getMessage());
        }
    }
}
