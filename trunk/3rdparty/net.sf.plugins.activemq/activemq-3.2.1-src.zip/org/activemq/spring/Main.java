/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.spring;

import org.activemq.broker.BrokerContainer;
import org.activemq.broker.BrokerContext;
import org.activemq.util.IdGenerator;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

import javax.jms.JMSException;

/**
 * A simple command line tool which runs a JMS Message Broker on the command line
 * using a Spring XML deployment descriptor
 *
 * @version $Revision$
 */
public class Main {

    /**
     * run the Message Broker as a standalone application
     *
     * @param args
     */
    public static void main(String args[]) {
        try {
            String version = "";
            Package p = Package.getPackage("org.activemq");
            if (p != null) {
                version = ": " + p.getImplementationVersion();
            }
            System.out.println("ActiveMQ Message Broker (http://activemq.org/) " + version);
            System.out.println();

            SpringBrokerContainerFactory factory = new SpringBrokerContainerFactory();
            String file = null;
            if (args.length <= 0) {
                System.out.println("Loading Mesaage Broker from activemq.xml on the CLASSPATH");
                factory.setResource(new ClassPathResource("activemq.xml"));
            }
            else {
                file = args[0];

                if (file.equals("-?") || file.equals("?") || file.equals("--help") || file.equals("-h")) {
                    System.out.println("Usage: Main [xmlConfigFile]");
                    System.out.println("If an XML config file is not specified then activemq.xml is used from the CLASSPAHT");
                    return;
                }

                System.out.println("Loading Message Broker from file: " + file);
                factory.setResource(new FileSystemResource(file));
            }

            IdGenerator idgen = new IdGenerator();
            BrokerContainer container = factory.createBrokerContainer(idgen.generateId(), BrokerContext.getInstance());
            container.start();

            // lets wait until we're killed.
            Object lock = new Object();
            synchronized (lock) {
                lock.wait();
            }
        }
        catch (JMSException e) {
            System.out.println("Caught: " + e);
            e.printStackTrace();
            Exception le = e.getLinkedException();
            System.out.println("Reason: " + le);
            if (le != null) {
                le.printStackTrace();
            }
        }
        catch (Exception e) {
            System.out.println("Caught: " + e);
            e.printStackTrace();
        }
    }
}