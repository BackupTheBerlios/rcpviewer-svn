/** 
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.cache;

import org.activemq.message.ActiveMQMessage;
import org.activemq.util.LRUCache;

/**
 * A simple cache that stores messages in memory.  Cache entries are evicted 
 * when they they get to old (A LRU cache is used).
 *
 * @version $Revision: 1.1.1.1 $
 */
public class SimpleMessageCache implements MessageCache {
	
	private final LRUCache messages;
	
	public SimpleMessageCache() {
		this(1000);
	}

	public SimpleMessageCache(int cacheSize) {
		this.messages = new LRUCache(cacheSize);
	}
	
	/**
	 * Gets a message that was previously <code>put</code> into this object.   
	 * 
	 * @param msgid
	 * @return null if the message was not previously put or if the message has expired out of the cache.
	 */
	synchronized public ActiveMQMessage get(String msgid) {
		return (ActiveMQMessage) messages.get(msgid);
	}

	/**
	 * Puts a message into the cache.
	 * 
	 * @param messageID
	 * @param message
	 */
	synchronized public void put(String messageID, ActiveMQMessage message) {
		messages.put(messageID, message);		
	}

	/**
	 * Remvoes a message from the cache.
	 * 
	 * @param messageID
	 */
	synchronized public void remove(String messageID) {
		messages.remove(messageID);
	}

    public void close() {
        messages.clear();        
    }

}
