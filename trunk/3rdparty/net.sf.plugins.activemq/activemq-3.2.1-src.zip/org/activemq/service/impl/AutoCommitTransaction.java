/** 
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service.impl;

import javax.jms.JMSException;
import javax.transaction.xa.XAException;

import org.activemq.service.Transaction;
import org.activemq.service.TransactionTask;
import org.activemq.util.JMSExceptionHelper;

/**
 * Keeps track of all the actions the need to be done when
 * a transaction does a commit or rollback.
 *
 * @version $Revision: 1.1.1.1 $
 */
public class AutoCommitTransaction implements Transaction {

    static final public AutoCommitTransaction AUTO_COMMIT_TRANSACTION = new AutoCommitTransaction();
    
    private AutoCommitTransaction() {}
    
    public void addPostCommitTask(TransactionTask task) throws JMSException {
        try {
            task.execute();
        } catch (Throwable e) {
            if( e instanceof JMSException ) {
                throw (JMSException)e;
            }
            JMSExceptionHelper.newJMSException("Commit task failed: "+e,e);
        }
    }

    public void addPostRollbackTask(TransactionTask task) throws JMSException {
        // Canot rollback an auto commit transaction.
    }

    public void commit(boolean onePhase) throws XAException {
        XAException xae = new XAException("Commit not implemented on Auto Commit Transactions.");
        xae.errorCode = XAException.XAER_RMERR;
        throw xae;
    }

    public void rollback() throws XAException {
        XAException xae = new XAException("Rollback not implemented on Auto Commit Transactions.");
        xae.errorCode = XAException.XAER_RMERR;
        throw xae;
    }

    public int prepare() throws XAException {
        XAException xae = new XAException("Prepare not implemented on Auto Commit Transactions.");
        xae.errorCode = XAException.XAER_RMERR;
        throw xae;
    }

    public boolean isXaTransacted() {
        return false;
    }

    public Object getTransactionId() {
        return null;
    }
}
