/** 
 * 
 * Copyright 2004 Hiram Chirino
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.cache;

import javax.jms.JMSException;

import org.activemq.message.ActiveMQMessage;
import org.activemq.message.MessageAck;
import org.activemq.service.MessageIdentity;
import org.activemq.store.MessageStore;
import org.activemq.store.RecoveryListener;

/**
 * A MessageStore that uses an in memory cache to speed up getMessage() method calls.
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class CacheMessageStore implements MessageStore, CacheMessageStoreAware {
	
	private final MessageStore longTermStore;	
	private final MessageCache cache;

	public CacheMessageStore(CachePersistenceAdapter adapter, MessageStore longTermStore, MessageCache cache) {
		this.longTermStore = longTermStore;
		this.cache = cache;
		
		// Make any downstream CacheMessageStoreAware objects aware of us.
		setCacheMessageStore(this);
	}

	/**
	 * Add the meessage to the long term store and cache it.
	 */
	public void addMessage(ActiveMQMessage message) throws JMSException {		
		longTermStore.addMessage(message);		
		cache.put(message.getJMSMessageID(), message);		
	}
	
	/**
	 * Remove the meessage to the long term store and remove it from the cache.
	 */
	public void removeMessage(MessageAck ack) throws JMSException {		
		longTermStore.removeMessage( ack);
		cache.remove(ack.getMessageID());		
	}

	/**
	 * Return the message from the cache or go to the longTermStore if it is not 
	 * in there. 
	 */
	public ActiveMQMessage getMessage(MessageIdentity identity)	throws JMSException {
		ActiveMQMessage answer=null;
		answer = cache.get(identity.getMessageID());
		if( answer!=null )
			return answer;
		
		answer = longTermStore.getMessage(identity);
		cache.put(identity.getMessageID(), answer);
		return answer;
	}

	/**
	 * Replays the checkpointStore first as those messages are the oldest ones,
	 * then messages are replayed from the transaction log and then the cache is
	 * updated.
	 * 
	 * @param listener
	 * @throws JMSException
	 */
	public synchronized void recover(final RecoveryListener listener)
			throws JMSException {
		longTermStore.recover(listener);
	}

	public void start() throws JMSException {
		longTermStore.start();
	}

	public void stop() throws JMSException {
		longTermStore.stop();
         cache.close();
	}

	/**
	 * @return Returns the longTermStore.
	 */
	public MessageStore getLongTermStore() {
		return longTermStore;
	}

	/**
	 * @see org.activemq.store.cache.CacheMessageStoreAware#setCacheMessageStore(org.activemq.store.cache.CacheMessageStore)
	 */
	public void setCacheMessageStore(CacheMessageStore store) {
		// Make any downstream CacheMessageStoreAware objects aware of us.
		// This cache implementation could be cached by another cache.
		if( longTermStore instanceof CacheMessageStoreAware ) {
			((CacheMessageStoreAware)longTermStore).setCacheMessageStore(store);
		}
	}

    /**
     * @see org.activemq.store.MessageStore#removeAllMessages()
     */
    public void removeAllMessages() throws JMSException {
		longTermStore.removeAllMessages();
    }

	
}