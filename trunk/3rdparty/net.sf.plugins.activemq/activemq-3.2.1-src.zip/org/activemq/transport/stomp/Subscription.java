/*
 * Copyright (c) 2005 Your Corporation. All Rights Reserved.
 */
package org.activemq.transport.stomp;

import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQTextMessage;
import org.activemq.message.MessageAck;
import org.activemq.message.ConsumerInfo;
import org.activemq.message.ActiveMQBytesMessage;

import javax.jms.JMSException;
import javax.jms.DeliveryMode;
import java.io.DataOutput;
import java.io.IOException;

class Subscription
{
    private ActiveMQDestination destination;
    private int ackMode = 1;
    private StompWireFormat format;
    private short consumer_no;
    private final String consumerId;
    private final String subscriptionId;
    public static final String NO_ID = "~~ NO SUCH THING ~~%%@#!Q";

    Subscription(StompWireFormat format, short consumer_no, String consumerId, String subscriptionId)
    {
        this.format = format;
        this.consumer_no = consumer_no;
        this.consumerId = consumerId;
        this.subscriptionId = subscriptionId;
    }

    void setDestination(ActiveMQDestination actual_dest)
    {
        this.destination = actual_dest;
    }

    void receive(ActiveMQTextMessage msg, DataOutput out) throws IOException, JMSException
    {
        if (ackMode == CLIENT_ACK)
        {
            AckListener listener = new AckListener(msg, consumerId, consumer_no, subscriptionId);
            format.addAckListener(listener);
        }
        else if (ackMode == AUTO_ACK)
        {
            MessageAck ack = new MessageAck();
//            if (format.isInTransaction()) ack.setTransactionIDString(format.getTransactionId());
            ack.setDestination(msg.getJMSActiveMQDestination());
            ack.setConsumerId(consumerId);
            ack.setMessageID(msg.getJMSMessageID());
            ack.setMessageRead(true);
            ack.setSessionId(format.getSessionId());
            ack.setProducerKey(msg.getProducerKey());
            ack.setSequenceNumber(msg.getSequenceNumber());
            ack.setPersistent(msg.getJMSDeliveryMode() == DeliveryMode.PERSISTENT);
            format.enqueuePacket(ack);
        }
        FrameBuilder builder = new FrameBuilder(Stomp.Responses.MESSAGE)
                .addHeaders(msg)
                .setBody(msg.getText().getBytes());
        if (!subscriptionId.equals(NO_ID))
        {
            builder.addHeader(Stomp.Headers.Message.SUBSCRIPTION, subscriptionId);
        }
        out.write(builder.toFrame());
    }

    void receive(ActiveMQBytesMessage msg, DataOutput out) throws IOException, JMSException
    {
        // @todo refactor this and the other receive form to remoce duplication -bmc
        if (ackMode == CLIENT_ACK)
        {
            AckListener listener = new AckListener(msg, consumerId, consumer_no, subscriptionId);
            format.addAckListener(listener);
        }
        else if (ackMode == AUTO_ACK)
        {
            MessageAck ack = new MessageAck();
//            if (format.isInTransaction()) ack.setTransactionIDString(format.getTransactionId());
            ack.setDestination(msg.getJMSActiveMQDestination());
            ack.setConsumerId(consumerId);
            ack.setMessageID(msg.getJMSMessageID());
            ack.setMessageRead(true);
            ack.setSessionId(format.getSessionId());
            ack.setProducerKey(msg.getProducerKey());
            ack.setSequenceNumber(msg.getSequenceNumber());
            ack.setPersistent(msg.getJMSDeliveryMode() == DeliveryMode.PERSISTENT);
            format.enqueuePacket(ack);
        }
        FrameBuilder builder = new FrameBuilder(Stomp.Responses.MESSAGE)
                .addHeaders(msg)
                .setBody(msg.getBodyAsBytes().getBuf());
        if (!subscriptionId.equals(NO_ID))
        {
            builder.addHeader(Stomp.Headers.Message.SUBSCRIPTION, subscriptionId);
        }
        out.write(builder.toFrame());
    }

    ActiveMQDestination getDestination()
    {
        return destination;
    }

    static final int AUTO_ACK = 1;
    static final int CLIENT_ACK = 2;

    public void setAckMode(int clientAck)
    {
        this.ackMode = clientAck;
    }

    public ConsumerInfo close()
    {
        ConsumerInfo unsub = new ConsumerInfo();
        unsub.setStarted(false);
        unsub.setDestination(this.destination);
        unsub.setClientId(format.getClientId());
        unsub.setConsumerNo(consumer_no);
        return unsub;
    }
}
