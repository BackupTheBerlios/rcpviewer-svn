/** 
 * 
 * Copyright 2004 Hiram Chirino
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.journal;

import java.util.HashMap;
import java.util.Iterator;

import javax.jms.JMSException;

import org.activeio.journal.RecordLocation;
import org.activemq.message.ConsumerInfo;
import org.activemq.service.MessageIdentity;
import org.activemq.service.SubscriberEntry;
import org.activemq.service.Transaction;
import org.activemq.service.TransactionManager;
import org.activemq.service.TransactionTask;
import org.activemq.store.RecoveryListener;
import org.activemq.store.TopicMessageStore;
import org.activemq.util.Callback;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * A MessageStore that uses a Journal to store it's messages.
 * 
 * @version $Revision: 1.1 $
 */
public class JournalTopicMessageStore extends JournalMessageStore implements TopicMessageStore {
    private static final Log log = LogFactory.getLog(JournalTopicMessageStore.class);

    private TopicMessageStore longTermStore;
	private HashMap ackedLastAckLocations = new HashMap();
	
    public JournalTopicMessageStore(JournalPersistenceAdapter adapter, TopicMessageStore checkpointStore, String destinationName) {
        super(adapter, checkpointStore, destinationName);
        this.longTermStore = checkpointStore;
    }
    
    public void recoverSubscription(String subscriptionId, MessageIdentity lastDispatchedMessage, RecoveryListener listener) throws JMSException {
        peristenceAdapter.checkpoint(true);
        longTermStore.recoverSubscription(subscriptionId, lastDispatchedMessage, listener);
    }

    public SubscriberEntry getSubscriberEntry(ConsumerInfo info) throws JMSException {
        return longTermStore.getSubscriberEntry(info);
    }

    public void setSubscriberEntry(ConsumerInfo info, SubscriberEntry subscriberEntry) throws JMSException {
        peristenceAdapter.checkpoint(true);
        longTermStore.setSubscriberEntry(info, subscriberEntry);
    }

    public MessageIdentity getLastestMessageIdentity() throws JMSException {
        return longTermStore.getLastestMessageIdentity();
    }

    public void incrementMessageCount(MessageIdentity messageId) throws JMSException {
        longTermStore.incrementMessageCount(messageId);
    }
    
    public void decrementMessageCountAndMaybeDelete(MessageIdentity messageId) throws JMSException {
        longTermStore.decrementMessageCountAndMaybeDelete(messageId);
    }

    /**
     */
    public void setLastAcknowledgedMessageIdentity(final String subscription, final MessageIdentity messageIdentity) throws JMSException {
        final boolean debug = log.isDebugEnabled();
        final RecordLocation location = peristenceAdapter.writePacket(destinationName, subscription, messageIdentity, false);
        if( !TransactionManager.isCurrentTransaction() ) {
            if( debug )
                log.debug("Journalled acknowledge: "+messageIdentity.getMessageID()+" at "+location);            
            acknowledge(subscription, messageIdentity, location);
        } else {
            if( debug ) 
                log.debug("Journalled in flight acknowledge: "+messageIdentity.getMessageID()+" at "+location);
            
            synchronized (this) {
                inFlightTxLocations.add(location);
            }
            final Transaction tx = TransactionManager.getContexTransaction();
            JournalAck ack = new JournalAck(destinationName,subscription,messageIdentity.getMessageID(), tx.getTransactionId());
            transactionStore.acknowledge(this, ack, location);
            tx.addPostCommitTask(new TransactionTask(){
                public void execute() throws Throwable {
                    if( debug ) 
                        log.debug("In flight acknowledge commit: "+messageIdentity.getMessageID()+" at "+location);
                    
                    synchronized (JournalTopicMessageStore.this) {
                        inFlightTxLocations.remove(location);
                        acknowledge(subscription, messageIdentity, location);
                    }
                }
            });
            tx.addPostRollbackTask(new TransactionTask(){
                public void execute() throws Throwable {
                    if( debug ) 
                        log.debug("In flight acknowledge rollback: "+messageIdentity.getMessageID()+" at "+location);
                    // TODO Auto-generated method stub
                    synchronized (JournalTopicMessageStore.this) {
                        inFlightTxLocations.remove(location);
                    }
                }
            });
            
        }        
    }

    private void acknowledge(String subscription, MessageIdentity messageIdentity, RecordLocation location) {
        synchronized(this) {
            lastLocation = location;
		    ackedLastAckLocations.put(subscription,messageIdentity);
		}
    }
    
    public RecordLocation checkpoint() throws JMSException {
        
        // swap the acks before check pointing the added messages since we don't want to ack 
        // a message that has not been checkpointed yet.
        final HashMap cpAckedLastAckLocations;
        synchronized(this) {
            cpAckedLastAckLocations = this.ackedLastAckLocations;
            this.ackedLastAckLocations = new HashMap();
        }
        
        // Check point the added messages.
		RecordLocation rc = super.checkpoint();		

        if( log.isDebugEnabled() ) {
            log.debug("Checkpoint acknowledgments: "+cpAckedLastAckLocations);
        }
		
		transactionTemplate.run(new Callback() {
			public void execute() throws Throwable {
				
				// Checkpoint the acknowledged messages.
				Iterator iterator = cpAckedLastAckLocations.keySet().iterator();
				while (iterator.hasNext()) {					
				    String subscription = (String) iterator.next();
				    MessageIdentity identity = (MessageIdentity) cpAckedLastAckLocations.get(subscription);				    
					longTermStore.setLastAcknowledgedMessageIdentity(subscription, identity);
				}				
				
			}

		});
		
		return rc;
    }

    /**
	 * @return Returns the longTermStore.
	 */
	public TopicMessageStore getLongTermTopicMessageStore() {
		return longTermStore;
	}

    public void deleteSubscription(String subscription) throws JMSException {
        peristenceAdapter.checkpoint(true);
        longTermStore.deleteSubscription(subscription);
    }

    public void replayAcknowledge(String subscription, MessageIdentity identity) {
        try {                            
            longTermStore.setLastAcknowledgedMessageIdentity(subscription,identity);
        }
        catch (Throwable e) {
            log.debug("Could not replay acknowledge for message '"+identity.getMessageID()+"'.  Message may have already been acknowledged. reason: " + e);
        }
    }
        
}