/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.service.impl;

import org.activemq.message.ActiveMQMessage;
import org.activemq.message.MessageAck;
import org.activemq.service.MessageContainer;
import org.activemq.service.MessageIdentity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.jms.JMSException;


/**
 * An entry for a message to be dispatched
 *
 * @version $Revision: 1.1.1.1 $
 */
class MessagePointer {
    private static final Log log = LogFactory.getLog(MessagePointer.class);

    private MessageContainer container;
    private MessageIdentity messageIdentity;
    private boolean dispatched;
    private boolean read;
    private boolean redelivered;
    private boolean deleted;


    public MessagePointer(MessagePointer copy) throws JMSException {
        this.container = copy.container;
        this.messageIdentity = copy.messageIdentity;
        this.container.registerMessageInterest(this.messageIdentity);
    }

    /**
     * Create a message ptr
     *
     * @param container       the container where the message is held
     * @param message         the message to point to
     * @throws JMSException
     */

    public MessagePointer(MessageContainer container, ActiveMQMessage message) throws JMSException {
        this.container = container;
        this.messageIdentity = message.getJMSMessageIdentity();
        this.redelivered = message.getJMSRedelivered();
        this.container.registerMessageInterest(this.messageIdentity);
    }

    /**
     * Reset default states for this MessagePointer
     */

    public void reset() {
        this.dispatched = false;
        this.read = false;
        this.deleted=false;
    }

    /**
     * Simply remove the interest in the message
     *
     * @throws JMSException
     */

    public void clear() throws JMSException {
        container.unregisterMessageInterest(messageIdentity);
    }


    /**
     * Notify the container it should delete the message
     *
     * @param ack
     * @throws JMSException
     */

    public void delete(MessageAck ack) throws JMSException {
        clear();
        deleted=true;
        container.delete(messageIdentity, ack);
    }

    /**
     * @return Returns the container.
     */
    public MessageContainer getContainer() {
        return container;
    }

    /**
     * @param container The container to set.
     */
    public void setContainer(MessageContainer container) {
        this.container = container;
    }

    /**
     * @return Returns the dispatched.
     */
    public boolean isDispatched() {
        return dispatched;
    }

    /**
     * @return Returns the deleted.
     */
    public boolean isDeleted() {
        return deleted;
    }

    /**
     * @param dispatched The dispatched to set.
     */
    public void setDispatched(boolean dispatched) {
        this.dispatched = dispatched;
    }

    /**
     * @return Returns the read.
     */
    public boolean isRead() {
        return read;
    }

    /**
     * @param read The read to set.
     */
    public void setRead(boolean read) {
        this.read = read;
    }

    public MessageIdentity getMessageIdentity() {
        return messageIdentity;
    }

    public void setMessageIdentity(MessageIdentity messageIdentity) {
        this.messageIdentity = messageIdentity;
    }
    /**
     * @return Returns the redilivered.
     */
    public boolean isRedelivered() {
        return redelivered;
    }
    /**
     * @param redelivered The redilivered to set.
     * @throws JMSException
     */
    public void setRedelivered(boolean redelivered) throws JMSException {
        if( !deleted ) {
            this.redelivered = redelivered;
            ActiveMQMessage message = getContainer().getMessage(getMessageIdentity());
            if (message == null) {
                log.warn("Could not find message: " + getMessageIdentity() + " when trying to set redelivered to: " + redelivered);
            }
            else {
                message.setJMSRedelivered(redelivered);
            }
        }
    }
}
