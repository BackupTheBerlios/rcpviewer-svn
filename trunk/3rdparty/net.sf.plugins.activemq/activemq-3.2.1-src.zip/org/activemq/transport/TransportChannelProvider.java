/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.transport;

import org.activemq.io.WireFormat;
import org.activemq.util.FactoryFinder;

import javax.jms.JMSException;
import java.io.IOException;
import java.net.URI;

/**
 * A TransportChannel is used for tranporting packets between nodes
 *
 * @version $Revision: 1.1.1.1 $
 */
public class TransportChannelProvider {
    private static FactoryFinder finder = new FactoryFinder("META-INF/services/org/activemq/transport/");

    /**
     * Create a Channel to a remote Node - e.g. a Broker
     *
     * @param remoteLocation
     * @return the TransportChannel bound to the remote node
     * @throws JMSException
     */
    public static TransportChannel create(WireFormat wireFormat, URI remoteLocation) throws JMSException {
        return getFactory(remoteLocation).create(wireFormat, remoteLocation);
    }

    /**
     * Create a Channel to a remote Node - e.g. a Broker
     *
     * @param remoteLocation
     * @param localLocation  -
     *                       e.g. local InetAddress and local port
     * @return the TransportChannel bound to the remote node
     * @throws JMSException
     */
    public static TransportChannel create(WireFormat wireFormat, URI remoteLocation, URI localLocation) throws JMSException {
        return getFactory(remoteLocation).create(wireFormat, remoteLocation, localLocation);
    }

    public static TransportChannelFactory getFactory(URI remoteLocation) throws JMSException {
        String protocol = remoteLocation.getScheme();
        try {
            Object value = finder.newInstance(protocol);
            if (value instanceof TransportChannelFactory) {
                return (TransportChannelFactory) value;
            }
            else {
                throw new JMSException("Factory does not implement TransportChannelFactory: " + value);
            }
        }
        catch (IllegalAccessException e) {
            throw createJMSexception(protocol, e);
        }
        catch (InstantiationException e) {
            throw createJMSexception(protocol, e);
        }
        catch (IOException e) {
            throw createJMSexception(protocol, e);
        }
        catch (ClassNotFoundException e) {
            throw createJMSexception(protocol, e);
        }

    }

    protected static JMSException createJMSexception(String protocol, Exception e) {
        JMSException answer = new JMSException("Could not load protocol: " + protocol + ". Reason: " + e);
        answer.setLinkedException(e);
        return answer;
    }
}