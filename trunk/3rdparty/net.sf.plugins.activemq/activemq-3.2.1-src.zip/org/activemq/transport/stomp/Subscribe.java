/*
 * Copyright (c) 2005 Your Corporation. All Rights Reserved.
 */
package org.activemq.transport.stomp;

import org.activemq.message.ConsumerInfo;
import org.activemq.message.ActiveMQDestination;

import java.io.DataInput;
import java.io.IOException;
import java.util.Properties;

class Subscribe implements Command
{
    private HeaderParser headerParser = new HeaderParser();
    private StompWireFormat format;

    Subscribe(StompWireFormat format)
    {
        this.format = format;
    }

    public PacketEnvelope build(String commandLine, DataInput in) throws IOException
    {
        ConsumerInfo ci = new ConsumerInfo();
        Properties headers = headerParser.parse(in);
        String destination = headers.getProperty(Stomp.Headers.Subscribe.DESTINATION);
        ActiveMQDestination actual_dest  = DestinationNamer.convert(destination);
        ci.setDestination(DestinationNamer.convert(destination));
        ci.setStarted(true);
        ci.setStartTime(System.currentTimeMillis());
        ci.setClientId(format.getClientId());
        short consumer_no = StompWireFormat.clientIds.getNextShortSequence();
        ci.setConsumerNo(consumer_no);
        ci.setReceiptRequired(true);
        ci.setSessionId(format.getSessionId());
        while (in.readByte() != 0) {}
        String consumerId = StompWireFormat.clientIds.generateId();
        ci.setConsumerId(consumerId);
        String subscriptionId = headers.getProperty(Stomp.Headers.Subscribe.ID, Subscription.NO_ID);
        Subscription s = new Subscription(format, consumer_no, consumerId, subscriptionId);
        s.setDestination(actual_dest);
        String ack_mode_key = headers.getProperty(Stomp.Headers.Subscribe.ACK_MODE);
        if (ack_mode_key != null && ack_mode_key.equals(Stomp.Headers.Subscribe.AckModeValues.CLIENT))
        {
            s.setAckMode(Subscription.CLIENT_ACK);
        }

        format.addSubscription(s);
        return new PacketEnvelope(ci, headers);
    }
}
