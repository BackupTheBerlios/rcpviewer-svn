/** 
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.cache;

import java.io.IOException;
import java.util.Map;

import javax.jms.JMSException;

import org.activemq.store.MessageStore;
import org.activemq.store.PersistenceAdapter;
import org.activemq.store.TopicMessageStore;
import org.activemq.store.TransactionStore;

/**
 * Implements a {@link PersistenceAdapter} designed to
 * to speed up access to recently added messages by using
 * a MessageCache .
 *
 * @version $Revision: 1.1.1.1 $
 */
public abstract class CachePersistenceAdapter implements PersistenceAdapter {

    private PersistenceAdapter longTermPersistence;    

    public CachePersistenceAdapter() {
    }
    
    public CachePersistenceAdapter(PersistenceAdapter longTermPersistence) throws IOException {
		this.longTermPersistence = longTermPersistence;
    }

    public Map getInitialDestinations() {
        return longTermPersistence.getInitialDestinations();
    }

    public MessageStore createQueueMessageStore(String destinationName) throws JMSException {
        MessageStore longtermStore = longTermPersistence.createQueueMessageStore(destinationName);
        CacheMessageStore store = new CacheMessageStore(this, longtermStore, createMessageCache(destinationName));
        return store;
    }

	public TopicMessageStore createTopicMessageStore(String destinationName) throws JMSException {
    	    TopicMessageStore longtermStore = longTermPersistence.createTopicMessageStore(destinationName);
        CacheTopicMessageStore store = new CacheTopicMessageStore(this, longtermStore, new SimpleMessageCache());
        return store;
    }

    public TransactionStore createTransactionStore() throws JMSException {
        return longTermPersistence.createTransactionStore();
    }

    public void beginTransaction() throws JMSException {
    	longTermPersistence.beginTransaction();
    }

    public void commitTransaction() throws JMSException {
    	longTermPersistence.commitTransaction();
    }

    public void rollbackTransaction() {
    	longTermPersistence.rollbackTransaction();
    }

    public void start() throws JMSException {
        longTermPersistence.start();
    }

	public void stop() throws JMSException {
        longTermPersistence.stop();
    }
	
    /**
     * Verifies if a dead letter has already been sent for a message  
     * @param seq
     * @param useLocking to prevent concurrency/dups
     * @return
     */
    public boolean deadLetterAlreadySent(long seq, boolean useLocking) {
    	return longTermPersistence.deadLetterAlreadySent(seq, useLocking);
    }

    // Properties
    //-------------------------------------------------------------------------
    public PersistenceAdapter getLongTermPersistence() {
        return longTermPersistence;
    }
    
    public void setLongTermPersistence(PersistenceAdapter longTermPersistence) {
        this.longTermPersistence = longTermPersistence;
    }

    /**
     * Subclasses should override this method to change the type 
     * of MessageCache that is used to cache messages.
     *  
     * @param destinationName
     * @return
     */
	abstract protected MessageCache createMessageCache(String destinationName);

}
