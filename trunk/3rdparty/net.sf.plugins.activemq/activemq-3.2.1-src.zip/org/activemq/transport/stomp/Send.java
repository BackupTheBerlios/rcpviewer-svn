/*
 * Copyright (c) 2005 Your Corporation. All Rights Reserved.
 */
package org.activemq.transport.stomp;

import org.activemq.message.ActiveMQBytesMessage;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ActiveMQTextMessage;

import javax.jms.JMSException;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.IOException;
import java.net.ProtocolException;
import java.util.Properties;

class Send implements Command
{
    private final HeaderParser parser = new HeaderParser();
    private final StompWireFormat format;

    Send(StompWireFormat format)
    {
        this.format = format;
    }

    public PacketEnvelope build(String commandLine, DataInput in) throws IOException
    {
        Properties headers = parser.parse(in);
        String destination = (String) headers.remove(Stomp.Headers.Send.DESTINATION);
        // now the body
        ActiveMQMessage msg;
        if (headers.containsKey(Stomp.Headers.CONTENT_LENGTH))
        {
            ActiveMQBytesMessage bm = new ActiveMQBytesMessage();
            String content_length = headers.getProperty(Stomp.Headers.CONTENT_LENGTH).trim();
            int length;
            try
            {
                length = Integer.parseInt(content_length);
            }
            catch (NumberFormatException e)
            {
                throw new ProtocolException("Specified content-length is not a valid integer");
            }
            byte[] bytes = new byte[length];
            in.readFully(bytes);
            byte nil = in.readByte();
            if (nil != 0) throw new ProtocolException("content-length bytes were read and " +
                                                      "there was no trailing null byte");
            bm.setBodyAsBytes(bytes, 0, bytes.length);
            msg = bm;
        }
        else
        {
            ActiveMQTextMessage text = new ActiveMQTextMessage();
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte b;
            while ((b = in.readByte()) != 0)
            {
                bytes.write(b);
            }
            bytes.close();
            String body = new String(bytes.toByteArray());
            try
            {
                text.setText(body);
            }
            catch (JMSException e)
            {
                throw new RuntimeException("Something is really wrong, we instantiated this thing!");
            }
            msg = text;
        }

        msg.setJMSMessageID(StompWireFormat.PACKET_IDS.generateId());

        ActiveMQDestination d = DestinationNamer.convert(destination);
        msg.setJMSDestination(d);
        msg.setJMSClientID(format.getClientId());

        // the standard JMS headers
        msg.setJMSCorrelationID((String) headers.remove(Stomp.Headers.Send.CORRELATION_ID));

        Object expiration = headers.remove(Stomp.Headers.Send.EXPIRATION_TIME);
        if (expiration != null)
        {
            msg.setJMSExpiration(asLong(expiration));
        }
        Object priority = headers.remove(Stomp.Headers.Send.PRORITY);
        if (priority != null)
        {
            msg.setJMSExpiration(asInt(priority));
        }

        msg.setJMSReplyTo(DestinationNamer.convert((String) headers.remove(Stomp.Headers.Send.REPLY_TO)));

        // now the general headers
        msg.setProperties(headers);

        if (headers.containsKey(Stomp.Headers.TRANSACTION))
        {
            String tx_id = format.getTransactionId(headers.getProperty(Stomp.Headers.TRANSACTION));
            if (tx_id == null) throw new ProtocolException(headers.getProperty(Stomp.Headers.TRANSACTION) +
                                                           " is an invalid transaction id");
            msg.setTransactionIDString(tx_id);
        }

        return new PacketEnvelope(msg, headers);
    }

    protected boolean asBool(Object value)
    {
        if (value != null)
        {
            return String.valueOf(value).equals("true");
        }
        return false;
    }

    protected long asLong(Object value)
    {
        if (value instanceof Number)
        {
            Number n = (Number) value;
            return n.longValue();
        }
        return Long.parseLong(value.toString());
    }

    protected int asInt(Object value)
    {
        if (value instanceof Number)
        {
            Number n = (Number) value;
            return n.intValue();
        }
        return Integer.parseInt(value.toString());
    }
}
