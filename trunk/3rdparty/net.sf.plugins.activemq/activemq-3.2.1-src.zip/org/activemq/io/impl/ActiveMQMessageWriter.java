/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.io.impl;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.activemq.io.util.ByteArray;
import org.activemq.message.AbstractPacket;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ActiveMQXid;
import org.activemq.message.Packet;
import org.activemq.util.BitArray;

/**
 * Writes a ActiveMQMessage packet to a Stream
 */
public class ActiveMQMessageWriter extends AbstractPacketWriter {
    private static final Log log = LogFactory.getLog(ActiveMQMessageWriter.class);
    private AbstractDefaultWireFormat wireFormat;
    
    
    ActiveMQMessageWriter(AbstractDefaultWireFormat wf){
        this.wireFormat = wf;
    }
    
    /**
     * Return the type of Packet
     * 
     * @return integer representation of the type of Packet
     */
    public int getPacketType() {
        return Packet.ACTIVEMQ_MESSAGE;
    }

    /**
     * Write a Packet instance to data output stream
     *
     * @param packet  the instance to be seralized
     * @param dataOut the output stream
     * @throws IOException thrown if an error occurs
     */
    public void writePacket(Packet packet, DataOutput dataOut) throws IOException {
        ActiveMQMessage msg = (ActiveMQMessage) packet;
        
        //check producerKey is set (will not be set by most Junit tests)
        boolean externalMessageId = msg.isExternalMessageId() || msg.getProducerKey() == null || msg.getProducerKey().length() == 0;
        msg.setExternalMessageId(externalMessageId);
        
        ActiveMQDestination destination = msg.getJMSActiveMQDestination();
        ByteArray payload = msg.getBodyAsBytes();
        BitArray ba = msg.getBitArray();
        ba.reset();
        boolean cachingEnabled = wireFormat.isCachingEnabled();
        boolean cachingDestination = cachingEnabled && destination != null && !destination.isOrdered() && !destination.isExclusive();
        boolean longSequence = msg.getSequenceNumber() > Integer.MAX_VALUE;
        
        ba.set(AbstractPacket.RECEIPT_REQUIRED_INDEX, packet.isReceiptRequired());
        Object[] visited = msg.getBrokersVisited();
        boolean writeVisited = visited != null && visited.length > 0;
        ba.set(AbstractPacket.BROKERS_VISITED_INDEX,writeVisited);
        ba.set(ActiveMQMessage.CORRELATION_INDEX, msg.getJMSCorrelationID() != null);
        ba.set(ActiveMQMessage.TYPE_INDEX, msg.getJMSType() != null);
        ba.set(ActiveMQMessage.BROKER_NAME_INDEX, msg.getEntryBrokerName() != null);
        ba.set(ActiveMQMessage.CLUSTER_NAME_INDEX, msg.getEntryClusterName() != null);
        ba.set(ActiveMQMessage.TRANSACTION_ID_INDEX, msg.getTransactionId() != null);
        ba.set(ActiveMQMessage.REPLY_TO_INDEX, msg.getJMSReplyTo() != null);
        ba.set(ActiveMQMessage.TIMESTAMP_INDEX, msg.getJMSTimestamp() > 0);
        ba.set(ActiveMQMessage.EXPIRATION_INDEX, msg.getJMSExpiration() > 0);
        ba.set(ActiveMQMessage.REDELIVERED_INDEX, msg.getJMSRedelivered());
        ba.set(ActiveMQMessage.XA_TRANS_INDEX, msg.isXaTransacted());
        ba.set(ActiveMQMessage.CID_INDEX, msg.getConsumerNos() != null);
        ba.set(ActiveMQMessage.PROPERTIES_INDEX, msg.getProperties() != null && msg.getProperties().size() > 0);
        ba.set(ActiveMQMessage.DISPATCHED_FROM_DLQ_INDEX,msg.isDispatchedFromDLQ());
        ba.set(ActiveMQMessage.PAYLOAD_INDEX, payload != null);
        ba.set(ActiveMQMessage.EXTERNAL_MESSAGE_ID_INDEX,msg.isExternalMessageId());
        ba.set(ActiveMQMessage.MESSAGE_PART_INDEX,msg.isMessagePart());
        ba.set(ActiveMQMessage.CACHED_VALUES_INDEX, cachingEnabled);
        ba.set(ActiveMQMessage.CACHED_DESTINATION_INDEX,cachingDestination);
        ba.set(ActiveMQMessage.LONG_SEQUENCE_INDEX, longSequence);
        
        ba.writeToStream(dataOut);
        if (msg.isReceiptRequired()){
            dataOut.writeShort(msg.getId());
        }
        if (msg.isExternalMessageId()){
            writeUTF(msg.getJMSMessageID(),dataOut);
        }
        if (msg.isMessagePart()){
            writeUTF(msg.getParentMessageID(), dataOut);
            dataOut.writeShort(msg.getNumberOfParts());
            dataOut.writeShort(msg.getPartNumber());
        }
        if (writeVisited){
            dataOut.writeShort(visited.length);
            for(int i =0; i < visited.length; i++){
                final String brokerName = visited[i].toString();
                if (brokerName != null) {
                    dataOut.writeUTF(brokerName);
                } else {
                    log.warn("The brokerVisited name is null");
                }
            }
        }
       
        if (cachingEnabled){
            dataOut.writeShort(wireFormat.getWriteCachedKey(msg.getJMSClientID()));
            dataOut.writeShort(wireFormat.getWriteCachedKey(msg.getProducerKey()));
            if (cachingDestination){
                dataOut.writeShort(wireFormat.getWriteCachedKey(destination));
            }else {
                ActiveMQDestination.writeToStream(destination, dataOut);
            }
            if (msg.getJMSReplyTo() != null){
                dataOut.writeShort(wireFormat.getWriteCachedKey(msg.getJMSReplyTo()));
            }
            if (ba.get(ActiveMQMessage.TRANSACTION_ID_INDEX)) {
                dataOut.writeShort(wireFormat.getWriteCachedKey(msg.getTransactionId()));
            }
            
            
        }else {
            super.writeUTF(msg.getJMSClientID(), dataOut);
            writeUTF(msg.getProducerKey(),dataOut);
            ActiveMQDestination.writeToStream(destination, dataOut);
            if (ba.get(ActiveMQMessage.REPLY_TO_INDEX)) {
                ActiveMQDestination.writeToStream((ActiveMQDestination) msg.getJMSReplyTo(), dataOut);
            }
            if (ba.get(ActiveMQMessage.TRANSACTION_ID_INDEX)) {
                if( ba.get(ActiveMQMessage.XA_TRANS_INDEX) ) {
                    ActiveMQXid xid = (ActiveMQXid) msg.getTransactionId();
                    xid.write(dataOut);
                } else {
                    super.writeUTF((String) msg.getTransactionId(), dataOut);
                }            
            }
        }
        
        dataOut.writeByte(msg.getJMSDeliveryMode());
        dataOut.writeByte(msg.getJMSPriority());
        

        if (ba.get(ActiveMQMessage.CORRELATION_INDEX)) {
            super.writeUTF(msg.getJMSCorrelationID(), dataOut);
        }
        if (ba.get(ActiveMQMessage.TYPE_INDEX)) {
            super.writeUTF(msg.getJMSType(), dataOut);
        }
        if (ba.get(ActiveMQMessage.BROKER_NAME_INDEX)) {
            super.writeUTF(msg.getEntryBrokerName(), dataOut);
        }
        if (ba.get(ActiveMQMessage.CLUSTER_NAME_INDEX)) {
            super.writeUTF(msg.getEntryClusterName(), dataOut);
        }
        
        
        if (ba.get(ActiveMQMessage.TIMESTAMP_INDEX)) {
            dataOut.writeLong(msg.getJMSTimestamp());
        }
        if (ba.get(ActiveMQMessage.EXPIRATION_INDEX)) {
            dataOut.writeLong(msg.getJMSExpiration());
        }
        if (longSequence){
            dataOut.writeLong(msg.getSequenceNumber());
        }else{
            dataOut.writeInt((int) msg.getSequenceNumber());
        }
       
        dataOut.writeByte(msg.getDeliveryCount());
       
        if (ba.get(ActiveMQMessage.CID_INDEX)) {
            //write out consumer numbers ...
            int[] cids = msg.getConsumerNos();
            dataOut.writeShort(cids.length);
            for (int i = 0; i < cids.length; i++) {
                dataOut.writeShort(cids[i]);
            }
        }
        if (ba.get(ActiveMQMessage.PROPERTIES_INDEX)) {
            msg.writeMapProperties(msg.getProperties(), dataOut);
        }
        if (ba.get(ActiveMQMessage.PAYLOAD_INDEX)) {
            dataOut.writeInt(payload.getLength());
            dataOut.write(payload.getBuf(),payload.getOffset(),payload.getLength());
        }
        
        
       
       
    }
}
