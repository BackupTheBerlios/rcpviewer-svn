/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service;

import org.activemq.message.ConsumerInfo;

import javax.jms.JMSException;


/**
 * A Topic based {@link MessageContainer}
 *
 * @version $Revision: 1.1.1.1 $
 */
public interface TopicMessageContainer extends MessageContainer {


    /**
     * Sets the last acknowleged message ID for the given subscriber in this
     * container so that if we shut down and recover we know where to start
     * replaying messages from.
     *
     * @param subscription
     * @param messageIdentity
     */
    public void setLastAcknowledgedMessageID(Subscription subscription, MessageIdentity messageIdentity) throws JMSException;

    /**
     * A durable subscription has started so recovery any messages that are required.
     * This method should find the last acknowledged message for the given subscription
     * and then iterate through any further messages and those that match the subscription
     * should be dispatched to this subscription so that they can be dispatched in the future
     *
     * @param subscription
     */
    public void recoverSubscription(Subscription subscription) throws JMSException;

    /**
     * Stores the persistence details in the database
     *
     * @param info
     * @param subscription
     */
    public void storeSubscription(ConsumerInfo info, Subscription subscription) throws JMSException;
}
