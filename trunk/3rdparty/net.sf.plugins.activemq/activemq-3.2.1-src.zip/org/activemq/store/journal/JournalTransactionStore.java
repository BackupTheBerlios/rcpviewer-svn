/** 
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.store.journal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.jms.JMSException;
import javax.transaction.xa.XAException;

import org.activeio.journal.RecordLocation;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ActiveMQXid;
import org.activemq.message.MessageAck;
import org.activemq.store.TransactionStore;
import org.apache.derby.iapi.store.raw.xact.TransactionId;

import EDU.oswego.cs.dl.util.concurrent.ConcurrentHashMap;

/**
 */
public class JournalTransactionStore implements TransactionStore {

    private final JournalPersistenceAdapter peristenceAdapter;
    ConcurrentHashMap inflightTransactions = new ConcurrentHashMap();
    ConcurrentHashMap preparedTransactions = new ConcurrentHashMap();
    
    public static class TxOperation {
        
        static final byte ADD_OPERATION_TYPE       = 0;
        static final byte REMOVE_OPERATION_TYPE    = 1;
        static final byte ACK_OPERATION_TYPE       = 3;
        
        public byte operationType;
        public JournalMessageStore store;
        public Object data;
        
        public TxOperation(byte operationType, JournalMessageStore store, Object data) {
            this.operationType=operationType;
            this.store=store;
            this.data=data;
        }
        
    }
    /**
     * Operations
     * @version $Revision: 1.3 $
     */
    public static class Tx {

        private final RecordLocation location;
        private ArrayList operations = new ArrayList();

        public Tx(RecordLocation location) {
            this.location=location;
        }

        public void add(JournalMessageStore store, ActiveMQMessage msg) {
            operations.add(new TxOperation(TxOperation.ADD_OPERATION_TYPE, store, msg));
        }

        public void add(JournalMessageStore store, MessageAck ack) {
            operations.add(new TxOperation(TxOperation.REMOVE_OPERATION_TYPE, store, ack));
        }

        public void add(JournalTopicMessageStore store, JournalAck ack) {
            operations.add(new TxOperation(TxOperation.ACK_OPERATION_TYPE, store, ack));
        }
        
        public ActiveMQMessage[] getMessages() {
            ArrayList list = new ArrayList();
            for (Iterator iter = operations.iterator(); iter.hasNext();) {
                TxOperation op = (TxOperation) iter.next();
                if( op.operationType==TxOperation.ADD_OPERATION_TYPE ) {
                    list.add(op.data);
                }
            }
            ActiveMQMessage rc[] = new ActiveMQMessage[list.size()];
            list.toArray(rc);
            return rc;
        }

        public MessageAck[] getAcks() {
            ArrayList list = new ArrayList();
            for (Iterator iter = operations.iterator(); iter.hasNext();) {
                TxOperation op = (TxOperation) iter.next();
                if( op.operationType==TxOperation.REMOVE_OPERATION_TYPE ) {
                    list.add(op.data);
                }
            }
            MessageAck rc[] = new MessageAck[list.size()];
            list.toArray(rc);
            return rc;
        }

        public ArrayList getOperations() {
            return operations;
        }

    }

    public interface AddMessageCommand {
        ActiveMQMessage getMessage();

        void run() throws IOException;
    }

    public interface RemoveMessageCommand {
        MessageAck getMessageAck();

        void run() throws IOException;
    }

    public JournalTransactionStore(JournalPersistenceAdapter adapter) {
        this.peristenceAdapter = adapter;
    }

    /**
     * @throws XAException 
     * @throws IOException
     * @see org.activemq.store.TransactionStore#prepare(TransactionId)
     */
    public void prepare(Object txid) throws XAException {
        Tx tx = (Tx) inflightTransactions.remove(txid);
        if (tx == null)
            return;
        peristenceAdapter.writeTxCommand(new TxCommand(TxCommand.XA_PREPARE, txid, false), true);
        preparedTransactions.put(txid, tx);
    }
    
    /**
     * @throws IOException
     * @see org.activemq.store.TransactionStore#prepare(TransactionId)
     */
    public void replayPrepare(Object txid) throws IOException {
        Tx tx = (Tx) inflightTransactions.remove(txid);
        if (tx == null)
            return;
        preparedTransactions.put(txid, tx);
    }

    public Tx getTx(Object txid, RecordLocation location) {
        Tx tx = (Tx) inflightTransactions.get(txid);
        if (tx == null) {
            tx = new Tx(location);
            inflightTransactions.put(txid, tx);
        }
        return tx;
    }

    /**
     * @throws XAException 
     * @throws XAException
     * @see org.activemq.store.TransactionStore#commit(org.activemq.service.Transaction)
     */
    public void commit(Object txid, boolean wasPrepared) throws XAException  {
        Tx tx;
        if (wasPrepared) {
            tx = (Tx) preparedTransactions.remove(txid);
        } else {
            tx = (Tx) inflightTransactions.remove(txid);
        }

        if (tx == null)
            return;

        if (txid.getClass() == ActiveMQXid.class ) {
            peristenceAdapter.writeTxCommand(new TxCommand(TxCommand.XA_COMMIT, txid, wasPrepared),
                    true);
        } else {
            peristenceAdapter.writeTxCommand(new TxCommand(TxCommand.LOCAL_COMMIT, txid, wasPrepared),
                    true);
        }
    }

    /**
     * @throws XAException
     * @see org.activemq.store.TransactionStore#commit(org.activemq.service.Transaction)
     */
    public Tx replayCommit(Object txid, boolean wasPrepared) throws IOException {
        if (wasPrepared) {
            return (Tx) preparedTransactions.remove(txid);
        } else {
            return (Tx) inflightTransactions.remove(txid);
        }
    }

    /**
     * @throws XAException 
     * @throws IOException
     * @see org.activemq.store.TransactionStore#rollback(TransactionId)
     */
    public void rollback(Object txid) throws XAException {

        Tx tx = (Tx) inflightTransactions.remove(txid);
        if (tx != null)
            tx = (Tx) preparedTransactions.remove(txid);

        if (tx != null) {
            if (txid.getClass() == ActiveMQXid.class ) {
                peristenceAdapter.writeTxCommand(new TxCommand(TxCommand.XA_ROLLBACK, txid, false),
                        true);
            } else {
                peristenceAdapter.writeTxCommand(new TxCommand(TxCommand.LOCAL_ROLLBACK, txid, false),
                        true);
            }
        }

    }

    /**
     * @throws IOException
     * @see org.activemq.store.TransactionStore#rollback(TransactionId)
     */
    public void replayRollback(Object txid) throws IOException {
        Tx tx = (Tx) inflightTransactions.remove(txid);
        if (tx != null)
            tx = (Tx) preparedTransactions.remove(txid);
    }
        
    synchronized public void recover(RecoveryListener listener) throws XAException {
        // All the inflight transactions get rolled back..
        inflightTransactions.clear();
        try {
            for (Iterator iter = preparedTransactions.keySet().iterator(); iter.hasNext();) {
                Object txid = (Object) iter.next();
                Tx tx = (Tx) preparedTransactions.get(txid);
                try {
                    listener.recover((ActiveMQXid) txid,tx.getMessages(), tx.getAcks());
                } catch (JMSException e) {
                    throw (XAException)new XAException().initCause(e);
                }
            }
        } finally {
        }
    }

    /**
     * @param message
     * @throws IOException
     */
    void addMessage(JournalMessageStore store, ActiveMQMessage message, RecordLocation location) {
        Tx tx = getTx(message.getTransactionId(), location);
        tx.add(store, message);
    }

    /**
     * @param ack
     * @throws IOException
     */
    public void removeMessage(JournalMessageStore store, MessageAck ack, RecordLocation location) {
        Tx tx = getTx(ack.getTransactionId(), location);
        tx.add(store, ack);
    }
    
    
    public void acknowledge(JournalTopicMessageStore store, JournalAck ack, RecordLocation location) {
        Tx tx = getTx(ack.getTransactionId(), location);
        tx.add(store, ack);
    }


    public RecordLocation checkpoint() throws IOException {
        
        // Nothing really to checkpoint.. since, we don't
        // checkpoint tx operations in to long term store until they are committed.

        // But we keep track of the first location of an operation
        // that was associated with an active tx. The journal can not
        // roll over active tx records.        
        RecordLocation rc = null;
        for (Iterator iter = inflightTransactions.values().iterator(); iter.hasNext();) {
            Tx tx = (Tx) iter.next();
            RecordLocation location = tx.location;
            if (rc == null || rc.compareTo(location) < 0) {
                rc = location;
            }
        }
        for (Iterator iter = preparedTransactions.values().iterator(); iter.hasNext();) {
            Tx tx = (Tx) iter.next();
            RecordLocation location = tx.location;
            if (rc == null || rc.compareTo(location) < 0) {
                rc = location;
            }
        }
        return rc;
    }

    public void start() throws JMSException {
    }

    public void stop() throws JMSException {
    }


}
