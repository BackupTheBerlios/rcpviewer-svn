/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

/**
 * Provides a infomation about a Transaction
 *
 * @version $Revision: 1.1.1.1 $
 */
public class TransactionInfo extends AbstractPacket implements TransactionType {

    private int type;
    private String transactionId;

    /**
     * @return Returns the transactionId.
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * @param transactionId The transactionId to set.
     */
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return TRANSACTION_INFO;
    }


    /**
     * Test for equality
     *
     * @param obj object to test
     * @return true if equivalent
     */
    public boolean equals(Object obj) {
        boolean result = false;
        if (obj != null && obj instanceof TransactionInfo) {
            TransactionInfo info = (TransactionInfo) obj;
            result = this.transactionId == info.transactionId;
        }
        return result;
    }

    /**
     * @return hash code for instance
     */
    public int hashCode() {
        return this.transactionId != null ? this.transactionId.hashCode() : super.hashCode();
    }

    /**
     * @return Returns the type of transacton command.
     */
    public int getType() {
        return this.type;
    }

    /**
     * @param newType the type of transaction command The type to set.
     */
    public void setType(int newType) {
        this.type = newType;
    }

    public String toString() {
        return super.toString() + " TransactionInfo{ " +
                "transactionId = '" + transactionId + "' " +
                ", type = " + type +
                " }";
    }
}
