/** 
 * 
 * Copyright 2004 Protique Ltd
 * Copyright 2005 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.service.boundedvm;


import javax.jms.JMSException;

import org.activemq.broker.BrokerClient;
import org.activemq.broker.BrokerConnector;
import org.activemq.filter.Filter;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.BrokerInfo;
import org.activemq.message.ConsumerInfo;

/**
 * A holder for Durable  consumer info and message routing
 * 
 * @version $Revision: 1.1.1.1 $
 */
public abstract class DurableSubscription  {
    protected Filter filter;
    protected ConsumerInfo consumerInfo;
    protected BrokerClient client;
    protected String brokerName;
    protected String clusterName;

    /**
     * Construct the DurableSubscription
     * @param filter
     * @param info
     */
    public DurableSubscription(Filter filter, ConsumerInfo info, BrokerClient client) {
        this.filter = filter;
        this.consumerInfo = info;
        this.client = client;
        if (client != null) {
            BrokerConnector connector = client.getBrokerConnector();
            if (connector != null) {
                BrokerInfo bi = connector.getBrokerInfo();
                if (bi != null) {
                    this.brokerName = bi.getBrokerName();
                    this.clusterName = bi.getClusterName();
                }
            }
        }
    }

    
    /**
     * determines if the Subscription is interested in the message
     *
     * @param message
     * @return true if this Subscription will accept the message
     * @throws JMSException
     */
    public abstract boolean isTarget(ActiveMQMessage message) throws JMSException;
   
    /**
     * @return Returns the consumerInfo.
     */
    public ConsumerInfo getConsumerInfo() {
        return consumerInfo;
    }
    /**
     * @param consumerInfo The consumerInfo to set.
     */
    public void setConsumerInfo(ConsumerInfo consumerInfo) {
        this.consumerInfo = consumerInfo;
    }
    /**
     * @return Returns the filter.
     */
    public Filter getFilter() {
        return filter;
    }
    /**
     * @param filter The filter to set.
     */
    public void setFilter(Filter filter) {
        this.filter = filter;
    }
    
    /**
     * close the subscription
     */
    public void close(){
    }

    /**
     * @return Returns the destination.
     */
    public ActiveMQDestination getDestination() {
        return consumerInfo.getDestination();
    }

    /**
     * @return true if this subscription is for a non-broker consumer
     */
    public boolean isLocalSubscription() {
        boolean localSubscription = true;
        if (client != null) {
            localSubscription = !(client.isClusteredConnection() || client.isBrokerConnection());
        }
        return localSubscription;
    }
}