/**
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.transport.composite;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.jms.JMSException;

import org.activemq.io.WireFormat;
import org.activemq.transport.TransportChannel;
import org.activemq.transport.TransportChannelFactorySupport;
import org.activemq.util.JMSExceptionHelper;

/**
 * A Composite implementation of a TransportChannelFactory
 *
 * @version $Revision: 1.1.1.1 $
 */
public class CompositeTransportChannelFactory extends TransportChannelFactorySupport {
    private static String separator = ",";

    public TransportChannel create(WireFormat wireFormat, URI remoteLocation) throws JMSException {
        try {
            List uris = new ArrayList();
            String text = parseURIs(uris, remoteLocation);
            uris = randomizeURIs(uris);
            TransportChannel channel = new CompositeTransportChannel(wireFormat, uris);

            return populateProperties(channel, text);
        }
        catch (URISyntaxException e) {
            throw JMSExceptionHelper.newJMSException("Can't parse list of URIs for: " + remoteLocation + ". Reason: " + e, e);
        }
    }

    public TransportChannel create(WireFormat wireFormat, URI remoteLocation, URI localLocation) throws JMSException {
        return create(wireFormat, remoteLocation);
    }

    public boolean requiresEmbeddedBroker() {
        return false;
    }

    public static String parseURIs(List uris, URI uri) throws URISyntaxException {
        String answer = "";
        String text = uri.getSchemeSpecificPart();
        if (text.startsWith("(")) {
            // lets find the end of the string
            int count = 1;
            int size = text.length();
            for (int i = 1; i < size; i++) {
                char ch = text.charAt(i);
                if (ch == '(') {
                    count++;
                }
                else if (ch == ')') {
                    if (--count == 0) {
                        // we're at the end
                        answer = text.substring(i + 1);
                        text = text.substring(1, i);
                        break;
                    }
                }
            }
        }
        // else URI is not a group
        else {
            answer = uri.getQuery();
        }
        
        StringTokenizer iter = new StringTokenizer(text, separator);
        while (iter.hasMoreTokens()) {
            String child = stripLeadingSlashes(iter.nextToken().trim());
            uris.add(new URI(child));
        }
        return answer;
    }

    protected static String stripLeadingSlashes(String text) {
        int idx = 0;
        while (idx < text.length() && text.charAt(idx) == '/') {
            idx++;
        }
        if (idx > 0) {
            return text.substring(idx);
        }
        return text;
    }


    protected List randomizeURIs(List uris) {
        return uris;
    }
}