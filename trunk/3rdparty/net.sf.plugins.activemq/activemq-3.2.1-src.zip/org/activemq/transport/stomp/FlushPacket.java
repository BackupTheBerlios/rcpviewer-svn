/*
 * Copyright (c) 2005 Your Corporation. All Rights Reserved.
 */
package org.activemq.transport.stomp;

import org.activemq.message.AbstractPacket;

/**
 * Dummy Marker packet to let the transport layer know that it should flush the wireformat.
 * 
 * @version $Revision$
 */
public class FlushPacket extends AbstractPacket {

    static public final FlushPacket PACKET = new FlushPacket();
    
    private FlushPacket() {
    }
    
    public int getPacketType() {
        return 0;
    }

}
