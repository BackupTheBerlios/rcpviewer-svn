/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.transport;

import org.activemq.service.Service;

import javax.jms.JMSException;
import java.net.InetSocketAddress;

/**
 * Represents a Server which accepts incoming client connections
 * in the form of TransportChannels which is used inside the JMS Broker
 *
 * @version $Revision: 1.1.1.1 $
 */
public interface TransportServerChannel extends Service {

    /**
     * close the ServerChannel
     */
    public void stop() throws JMSException;


    /**
     * start listeneing for events
     *
     * @throws JMSException if an error occurs
     */
    public void start() throws JMSException;

    /**
     * Registers the listener to be used when new clients connect or
     * disconnect
     *
     * @param listener the listener to be invoked when a client connects
     *                 or disconnects
     */
    public void setTransportChannelListener(TransportChannelListener listener);

    /**
     * Returns the URL to connect to this connector
     */
    String getUrl();

    /**
     * An optional method to return the socket address if there is one on which this
     * channel is listening. An implementation may return null for this operation; its mostly intended
     * to be used for tooling to be able to access socket address information.
     *
     * @return
     */
    InetSocketAddress getSocketAddress();
}
