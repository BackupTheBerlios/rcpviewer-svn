/**
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service.impl;

import EDU.oswego.cs.dl.util.concurrent.ConcurrentHashMap;
import org.activemq.broker.BrokerClient;
import org.activemq.filter.DestinationMap;
import org.activemq.filter.Filter;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ConsumerInfo;
import org.activemq.service.DeadLetterPolicy;
import org.activemq.service.Dispatcher;
import org.activemq.service.Subscription;
import org.activemq.service.SubscriptionContainer;
import org.activemq.service.RedeliveryPolicy;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * A default RAM only implementation of the {@link SubscriptionContainer}
 *
 * @version $Revision: 1.1.1.1 $
 */
public class SubscriptionContainerImpl implements SubscriptionContainer {
    private Map subscriptions;
    private DestinationMap destinationIndex = new DestinationMap();
    private RedeliveryPolicy redeliveryPolicy;
    private DeadLetterPolicy deadLetterPolicy;

    public SubscriptionContainerImpl(RedeliveryPolicy redeliveryPolicy,DeadLetterPolicy deadLetterPolicy) {
        this(new ConcurrentHashMap(), redeliveryPolicy,deadLetterPolicy);
    }

    public SubscriptionContainerImpl(Map subscriptions, RedeliveryPolicy redeliveryPolicy,DeadLetterPolicy deadLetterPolicy) {
        this.subscriptions = subscriptions;
        this.redeliveryPolicy = redeliveryPolicy;
        this.deadLetterPolicy = deadLetterPolicy;
    }

    public String toString() {
        return super.toString() + "[size:" + subscriptions.size() + "]";
    }

    public RedeliveryPolicy getRedeliveryPolicy() {
        return redeliveryPolicy;
    }

    public DeadLetterPolicy getDeadLetterPolicy(){
        return deadLetterPolicy;
    }
    public Subscription getSubscription(String consumerId) {
        return (Subscription) subscriptions.get(consumerId);
    }

    public Subscription removeSubscription(String consumerId) {
        Subscription subscription = (Subscription) subscriptions.remove(consumerId);
        if (subscription != null) {
            destinationIndex.remove(subscription.getDestination(), subscription);
        }
        return subscription;
    }

    public Set getSubscriptions(ActiveMQDestination destination) {
        Object answer = destinationIndex.get(destination);
        if (answer instanceof Set) {
            return (Set) answer;
        }
        else {
            Set set = new HashSet(1);
            set.add(answer);
            return set;
        }
    }

    public Iterator subscriptionIterator() {
        return subscriptions.values().iterator();
    }

    public Subscription makeSubscription(Dispatcher dispatcher,BrokerClient client, ConsumerInfo info, Filter filter) {
        Subscription subscription = createSubscription(dispatcher, client,info, filter);
        subscriptions.put(info.getConsumerId(), subscription);
        destinationIndex.put(subscription.getDestination(), subscription);
        return subscription;
    }

    protected Subscription createSubscription(Dispatcher dispatcher, BrokerClient client,ConsumerInfo info, Filter filter) {
        return new SubscriptionImpl(dispatcher, client,info, filter, getRedeliveryPolicy(),getDeadLetterPolicy());
    }
}
