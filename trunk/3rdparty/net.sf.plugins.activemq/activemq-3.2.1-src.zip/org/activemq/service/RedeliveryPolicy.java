/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service;

/**
 * Represents the redelivery policy which is used when a rollback() occurs
 * (either JMS or XA). Various options are possible which this policy tries to capture
 * the main variants.
 * If enabled, a typical redelivery policy could be to use a back-off timeout period.
 *
 * @version $Revision: 1.1.1.1 $
 */
public class RedeliveryPolicy {
    private int maximumRetryCount = 5;
    private boolean backOffMode = false;
    private long initialRedeliveryTimeout = 1000L;
    private double backOffIncreaseRate = 2.0;

    /**
     * Returns whether or not we use a back-off timeout (increasing the timeout
     * by the {@link #getBackOffIncreaseRate()} each time).
     */
    public boolean isBackOffMode() {
        return backOffMode;
    }

    public void setBackOffMode(boolean backOffMode) {
        this.backOffMode = backOffMode;
    }

    /**
     * Returns the initial redelivery timeout
     */
    public long getInitialRedeliveryTimeout() {
        return initialRedeliveryTimeout;
    }

    public void setInitialRedeliveryTimeout(long initialRedeliveryTimeout) {
        this.initialRedeliveryTimeout = initialRedeliveryTimeout;
    }

    /**
     * Returns the maximum retry count on a single message before its forwarded
     * to a Dead Letter Queue
     */
    public int getMaximumRetryCount() {
        return maximumRetryCount;
    }

    public void setMaximumRetryCount(int maximumRetryCount) {
        this.maximumRetryCount = maximumRetryCount;
    }

    public double getBackOffIncreaseRate() {
        return backOffIncreaseRate;
    }

    public void setBackOffIncreaseRate(double backOffIncreaseRate) {
        this.backOffIncreaseRate = backOffIncreaseRate;
    }
}
