/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.spring;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import java.io.InputStream;

/**
 * A Spring BeanFactory for creating ActiveMQ objects
 *
 * @version $Revision$
 */
public class ActiveMQBeanFactory extends DefaultListableBeanFactory {

    private XmlBeanDefinitionReader reader;

    /**
     * A static factory method which can be used easily from spring.xml
     *
     * @param resource XML resource to load bean definitions from
     */
    public static ActiveMQBeanFactory newInstance(String brokerName, Resource resource) {
        return new ActiveMQBeanFactory(brokerName, resource);
    }

    /**
     * Create a new ActiveMQBeanFactory with the given resource,
     * which must be parsable using DOM.
     *
     * @param resource XML resource to load bean definitions from
     * @throws org.springframework.beans.BeansException
     *          in case of loading or parsing errors
     */
    public ActiveMQBeanFactory(String brokerName, Resource resource) throws BeansException {
        this(brokerName, resource, null);
    }

    /**
     * Create a new ActiveMQBeanFactory with the given InputStream,
     * which must be parsable using DOM.
     * <p>It's preferable to use a Resource argument instead of an
     * InputStream, to retain location information. This constructor
     * is mainly kept for backward compatibility.
     *
     * @param is XML InputStream to load bean definitions from
     * @throws BeansException in case of loading or parsing errors
     * @see #ActiveMQBeanFactory(String, Resource)
     */
    public ActiveMQBeanFactory(String brokerName, InputStream is) throws BeansException {
        this(brokerName, new InputStreamResource(is, "(no description)"), null);
    }

    /**
     * Create a new ActiveMQBeanFactory with the given input stream,
     * which must be parsable using DOM.
     *
     * @param resource          XML resource to load bean definitions from
     * @param parentBeanFactory parent bean factory
     * @throws BeansException in case of loading or parsing errors
     */
    public ActiveMQBeanFactory(String brokerName, Resource resource, BeanFactory parentBeanFactory) throws BeansException {
        super(parentBeanFactory);
        reader = createReader(brokerName);
        reader.loadBeanDefinitions(resource);
        PropertyPlaceholderConfigurer configurer = new PropertyPlaceholderConfigurer();
        configurer.setSystemPropertiesMode(PropertyPlaceholderConfigurer.SYSTEM_PROPERTIES_MODE_OVERRIDE);
        configurer.postProcessBeanFactory(this);
    }

    protected XmlBeanDefinitionReader getReader() {
        return reader;
    }

    /**
     * A hook to allow custom ActiveMQBeanFactory implementations to provide
     * their own custom parser of the XML to perform macro processing
     * or perform XSLT etc
     *
     * @return
     */
    protected XmlBeanDefinitionReader createReader(String brokerName) {
        return new ActiveMQBeanDefinitionReader(this, brokerName);
    }
}
