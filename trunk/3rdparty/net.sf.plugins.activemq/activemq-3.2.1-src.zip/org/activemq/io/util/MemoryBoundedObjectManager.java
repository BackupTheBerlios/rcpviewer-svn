/** 
 * 
 * Copyright 2004 Protique Ltd
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.io.util;
import java.util.HashSet;
import java.util.Iterator;

import org.activemq.capacity.BasicCapacityMonitor;

import EDU.oswego.cs.dl.util.concurrent.SynchronizedLong;

/**
 * Keeps track of MemoryBoundedObjects 
 *  
 * @version $Revision: 1.1.1.1 $
 */
public class MemoryBoundedObjectManager extends BasicCapacityMonitor {
    
    private final SynchronizedLong totalMemoryUsedSize = new SynchronizedLong(0);
    private final HashSet managedObjects = new HashSet();
    boolean closed;
    private boolean supportJMSPriority = false;

    /**
     * @param name
     * @param maxSize
     */
    public MemoryBoundedObjectManager(String name, long maxSize) {
        this(name, maxSize, false);
    }

    public MemoryBoundedObjectManager(String name, long maxSize, boolean supportJMSPriority) {
        super(name, maxSize);
        this.supportJMSPriority = supportJMSPriority;
    }

    synchronized public void add(MemoryBoundedObject o) {
        managedObjects.add(o);
    }

    /**
     * close this queue manager and all associated MemoryBoundedQueues
     */
    public void close() {        
        HashSet copy;
        synchronized (this) {
            if(closed)
                return;
            closed=true;
            copy = new HashSet(managedObjects);
        }        
        for (Iterator i = copy.iterator(); i.hasNext();) {
            MemoryBoundedObject o = (MemoryBoundedObject) i.next();
            o.close();
        }
    }

    /**
     * @param name
     */
    public synchronized void remove(MemoryBoundedObject o) {
        managedObjects.remove(o);
    }

    /**
     * @return the calculated total memory usage assocated with all it's queues
     */
    public long getTotalMemoryUsedSize() {
        return totalMemoryUsedSize.get();
    }

    /**
     * @return true if this MemoryBoundedObjectManager                            has reached it's predefined limit
     */
    public boolean isFull() {
        boolean result = totalMemoryUsedSize.get() >= super.getValueLimit();
        return result;
    }

    /**
     * @return true if this MemoryBoundedObjectManager                            has reached it's predefined limit
     */
    public float getPercentFull() {
        return ( totalMemoryUsedSize.get() / super.getValueLimit() );
    }

    public void incrementMemoryUsed(int size) {
        totalMemoryUsedSize.add(size);
        super.setCurrentValue(totalMemoryUsedSize.get());
    }

    public void decrementMemoryUsed(int size) {
        totalMemoryUsedSize.subtract(size);
        super.setCurrentValue(totalMemoryUsedSize.get());
    }

    protected void finalize() {
        close();
    }

	/**
	 * @return Returns the supportJMSPriority.
	 */
	public boolean isSupportJMSPriority() {
		return supportJMSPriority;
	}
	/**
	 * @param supportJMSPriority The supportJMSPriority to set.
	 */
	public void setSupportJMSPriority(boolean supportJMSPriority) {
		this.supportJMSPriority = supportJMSPriority;
	}
}
