/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;

import org.activemq.service.QueueList;
import org.activemq.service.QueueListEntry;

/**
 * Linked list class to provide uniformly named methods to <tt>get</tt>,<tt>remove</tt> and <tt>insert</tt> an
 * element at the beginning and end of the list. These operations allow linked lists to be used as a stack, queue, or
 * double-ended queue (dequeue).
 * <p/>
 *
 * @version $Revision: 1.1.1.1 $
 */
public final class DefaultQueueList implements QueueList, Cloneable, Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 664118850296696821L;
    private transient DefaultQueueListEntry header = new DefaultQueueListEntry(null, null, null);
    private transient int size = 0;

    /**
     * Constructs an empty list.
     */
    public DefaultQueueList() {
        header.next = header.previous = header;
    }

    /**
     * @return the first object from the list or null
     */

    public synchronized Object getFirst() {
        if (size == 0) {
            return null;
        }
        return header.next.element;
    }

    /**
     * @return the last object from the list
     */

    public synchronized Object getLast() {
        if (size == 0) {
            return null;
        }
        return header.previous.element;
    }

    /**
     * remove the first object from the list
     */

    public synchronized Object removeFirst() {
        if (size == 0) {
            return null;
        }
        Object first = header.next.element;
        remove(header.next);
        return first;
    }

    /**
     * move the first object to the back of the list
     */

    public synchronized void rotate() {
        if (size > 1) {
            Object obj = removeFirst();
            if (obj != null) {
                addLast(obj);
            }
        }
    }

    /**
     * remove the last object
     */
    public synchronized Object removeLast() {
        if (size == 0) {
            return null;
        }
        Object last = header.previous.element;
        remove(header.previous);
        return last;
    }


    public synchronized QueueListEntry addAllFirst(Collection c) {
        return addAllBefore(c, header.next);
    }

    public synchronized QueueListEntry addFirst(Object o) {
        return addBefore(o, header.next);
    }

    public synchronized QueueListEntry addLast(Object o) {
        return addBefore(o, header);
    }

    public synchronized boolean contains(Object o) {
        return indexOf(o) != -1;
    }

    public synchronized int size() {
        return size;
    }

    public synchronized boolean isEmpty() {
        return size == 0;
    }

    public synchronized QueueListEntry add(Object o) {
        return addBefore(o, header);
    }

    public synchronized boolean remove(Object o) {
        if (o == null) {
            for (DefaultQueueListEntry e = header.next; e != header; e = e.next) {
                if (e.element == null) {
                    remove(e);
                    return true;
                }
            }
        }
        else {
            for (DefaultQueueListEntry e = header.next; e != header; e = e.next) {
                if (o.equals(e.element)) {
                    remove(e);
                    return true;
                }
            }
        }
        return false;
    }

    public synchronized void clear() {
        header.next = header.previous = header;
        size = 0;
    }

    // Positional Access Operations
    public synchronized Object get(int index) {
        return entry(index).element;
    }
    
    /**
     * get the object from the queue
     * @param obj
     * @return
     */
    public synchronized Object get(Object obj){
        int index = indexOf(obj);
        if (index >= 0){
            return get(index);
        }
        return null;
    }

    public synchronized Object set(int index, Object element) {
        DefaultQueueListEntry e = entry(index);
        Object oldVal = e.element;
        e.element = element;
        return oldVal;
    }

    public synchronized void add(int index, Object element) {
        addBefore(element, (index == size ? header : entry(index)));
    }

    public synchronized Object remove(int index) {
        DefaultQueueListEntry e = entry(index);
        remove(e);
        return e.element;
    }

    public synchronized DefaultQueueListEntry entry(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        DefaultQueueListEntry e = header;
        if (index < size / 2) {
            for (int i = 0; i <= index; i++) {
                e = e.next;
            }
        }
        else {
            for (int i = size; i > index; i--) {
                e = e.previous;
            }
        }
        return e;
    }

    // Search Operations
    public synchronized int indexOf(Object o) {
        int index = 0;
        if (o == null) {
            for (DefaultQueueListEntry e = header.next; e != header; e = e.next) {
                if (e.element == null) {
                    return index;
                }
                index++;
            }
        }
        else {
            for (DefaultQueueListEntry e = header.next; e != header; e = e.next) {
                if (o.equals(e.element)) {
                    return index;
                }
                index++;
            }
        }
        return -1;
    }

    public synchronized int lastIndexOf(Object o) {
        int index = size;
        if (o == null) {
            for (DefaultQueueListEntry e = header.previous; e != header; e = e.previous) {
                index--;
                if (e.element == null) {
                    return index;
                }
            }
        }
        else {
            for (DefaultQueueListEntry e = header.previous; e != header; e = e.previous) {
                index--;
                if (o.equals(e.element)) {
                    return index;
                }
            }
        }
        return -1;
    }

    public synchronized QueueListEntry getFirstEntry() {
        DefaultQueueListEntry result = header.next;
        return result != header ? result : null;
    }

    public synchronized QueueListEntry getLastEntry() {
        DefaultQueueListEntry result = header.previous;
        return result != header ? result : null;
    }

    public QueueListEntry getNextEntry(QueueListEntry node) {
        DefaultQueueListEntry entry = (DefaultQueueListEntry) node;
        if (entry == null) {
            return null;
        }
        DefaultQueueListEntry result = entry.next;
        return (result != entry && result != header) ? result : null;
    }

    public QueueListEntry getPrevEntry(QueueListEntry node) {
        DefaultQueueListEntry entry = (DefaultQueueListEntry) node;
        if (entry == null) {
            return null;
        }
        DefaultQueueListEntry result = entry.previous;
        return (result != entry && result != header) ? result : null;
    }

    public synchronized QueueListEntry addBefore(Object o, QueueListEntry node) {
        DefaultQueueListEntry e = (DefaultQueueListEntry) node;
        DefaultQueueListEntry newLinkedListEntry = new DefaultQueueListEntry(o, e, e.previous);
        newLinkedListEntry.previous.next = newLinkedListEntry;
        newLinkedListEntry.next.previous = newLinkedListEntry;
        size++;
        return newLinkedListEntry;
    }

    public synchronized QueueListEntry addAllBefore(Collection c, QueueListEntry node) {
        
        // Nothing to insert?
        if( c.size() < 1 )
            return node;
        
        // Link together the items in the array
        DefaultQueueListEntry e = (DefaultQueueListEntry) node;        
        DefaultQueueListEntry newLinkedListEntry[] = new DefaultQueueListEntry[c.size()];
        Iterator iterator = c.iterator();
        for( int i=0; i < newLinkedListEntry.length; i++) {
            // Create and link to the previous.
            newLinkedListEntry[i] = new DefaultQueueListEntry(iterator.next(), e, i==0 ? e.previous : newLinkedListEntry[i-1] );
        }
        for( int i=0; i < newLinkedListEntry.length-1; i++) {
            // Link to the next.
            newLinkedListEntry[i].next = newLinkedListEntry[i+1];
        }
        
        // Now link those items into the rest of the list.
        synchronized (this) {
            newLinkedListEntry[0].previous.next = newLinkedListEntry[0];
            newLinkedListEntry[newLinkedListEntry.length-1].next.previous = newLinkedListEntry[newLinkedListEntry.length-1];
            size+=newLinkedListEntry.length;
        }
        return newLinkedListEntry[0];
    }

    public synchronized void remove(QueueListEntry node) {
        DefaultQueueListEntry e = (DefaultQueueListEntry) node;
        if (e == header) {
            return;
        }
        e.previous.next = e.next;
        e.next.previous = e.previous;
        size--;
    }

    /**
     * Returns a shallow copy of this <tt>DefaultQueueList</tt>. (The elements themselves are not cloned.)
     *
     * @return a shallow copy of this <tt>DefaultQueueList</tt> instance.
     */
    public synchronized Object clone() {
        DefaultQueueList clone = new DefaultQueueList();
        // Put clone into "virgin" state
        clone.header = new DefaultQueueListEntry(null, null, null);
        clone.header.next = clone.header.previous = clone.header;
        clone.size = 0;
        // Initialize clone with our elements
        for (DefaultQueueListEntry e = header.next; e != header; e = e.next) {
            clone.add(e.element);
        }
        return clone;
    }

    public synchronized Object[] toArray() {
        Object[] result = new Object[size];
        int i = 0;
        for (DefaultQueueListEntry e = header.next; e != header; e = e.next) {
            result[i++] = e.element;
        }
        return result;
    }
    
    /**
     * @return pretty print
     */
    public synchronized String toString(){
        String result = super.toString();
        result += ":";
        for (DefaultQueueListEntry e = header.next; e != header; e = e.next) {
            result += e.element;
            if (e != header){
                result += ",";
            }
        }
        return result;
    }
}
