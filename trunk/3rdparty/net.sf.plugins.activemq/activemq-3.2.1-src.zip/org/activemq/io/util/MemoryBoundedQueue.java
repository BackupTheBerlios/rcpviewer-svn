/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.io.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jms.JMSException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.activemq.service.QueueListEntry;
import org.activemq.service.impl.DefaultQueueList;

import EDU.oswego.cs.dl.util.concurrent.SynchronizedLong;

/**
 * MemoryBoundedQueue is a queue bounded by memory usage for MemoryManageable                s
 *
 * @version $Revision: 1.1.1.1 $
 */
public class MemoryBoundedQueue implements MemoryBoundedObject {
    
    private static final Log log = LogFactory.getLog(MemoryBoundedQueue.class);
    
    private static final int OBJECT_OVERHEAD = 50;
    protected static final int WAIT_TIMEOUT = 100;

    private final MemoryBoundedQueueManager manager;
    private final String name;

    protected final Object outLock = new Object();
    protected final Object inLock = new Object();
    private final DefaultQueueList internalList = new DefaultQueueList();
    protected boolean stopped = false;
    protected boolean closed = false;
    private SynchronizedLong memoryUsedByThisQueue = new SynchronizedLong(0);

    /**
     * Constructor
     *
     * @param name
     * @param manager
     * @param name 
     */
    public MemoryBoundedQueue(MemoryBoundedQueueManager manager, String name) {
        this.manager = manager;
        this.name = name;
        this.manager.add(this);
    }
    /**
     * @return a pretty print of this queue
     */
    public String toString() {
        return "MemoryBoundedQueue{ size=" + size() + ", memory usage=" + memoryUsedByThisQueue + " }";
    }

    /**
     * @return the number of items held by this queue
     */
    public int size() {
        return internalList.size();
    }

    /**
     * @return an aproximation the memory used by this queue
     */
    public long getLocalMemoryUsedByThisQueue() {
        return memoryUsedByThisQueue.get();
    }

    /**
     * close and remove this queue from the MemoryBoundedQueueManager
     */
    public void close() {
        try {
            clear();
            closed = true;
            synchronized (outLock) {
                outLock.notifyAll();
            }
            synchronized (inLock) {
                inLock.notifyAll();
            }
        }
        catch (Throwable e) {
            e.printStackTrace();
        }
        finally {
            manager.remove(this);
        }
    }

    /**
     * Enqueue a MemoryManageable                 without checking memory usage limits
     *
     * @param packet
     */
    public void enqueueNoBlock(MemoryManageable packet) {
        if (!closed) {
            internalList.add(packet);
            incrementMemoryUsed(packet);
            synchronized (outLock) {
                outLock.notify();
            }
        }
    }

    /**
     * Enqueue a MemoryManageable                 to this queue
     *
     * @param packet
     */
    public void enqueue(MemoryManageable packet) {
        if (!manager.isMemoryLimitEnforced() || !manager.isFull()) {
            enqueueNoBlock(packet);
        }
        else {
            synchronized (inLock) {
                try {
                    while (manager.isFull() && !closed) {
                        log.warn("Queue is full, waiting for it to be dequeued.");
                        inLock.wait(WAIT_TIMEOUT);
                    }
                }
                catch (InterruptedException ie) {
                }
            }
            enqueueNoBlock(packet);
        }
    }

    /**
     * Enqueue a packet to the head of the queue with total disregard for memory constraints
     *
     * @param packet
     */
    public void enqueueFirstNoBlock(MemoryManageable packet) {
        if (!closed) {
            internalList.addFirst(packet);
            incrementMemoryUsed(packet);
            synchronized (outLock) {
                outLock.notify();
            }
        }
    }

    /**
     * Enqueue an array of packets to the head of the queue with total disregard for memory constraints
     *
     * @param packets
     */
    public void enqueueAllFirstNoBlock(List packets) {
        if (!closed) {
            internalList.addAllFirst(packets);
            Iterator iterator = packets.iterator();
            for (Iterator iter = packets.iterator(); iter.hasNext();) {
                MemoryManageable packet = (MemoryManageable) iter.next();
                incrementMemoryUsed(packet);
            }
            synchronized (outLock) {
                outLock.notify();
            }
        }
    }

    /**
     * Enqueue a MemoryManageable                 to the head of the queue
     *
     * @param packet
     * @throws InterruptedException
     */
    public void enqueueFirst(MemoryManageable packet) throws InterruptedException {
        if (!manager.isMemoryLimitEnforced() || !manager.isFull()) {
            enqueueFirstNoBlock(packet);
        }
        else {
            synchronized (inLock) {
                while (manager.isFull() && !closed) {
                    inLock.wait(WAIT_TIMEOUT);
                }
            }
            enqueueFirstNoBlock(packet);
        }
    }

    /**
     * @return the first dequeued MemoryManageable                 or blocks until one is available
     * @throws InterruptedException
     */
    public MemoryManageable dequeue() throws InterruptedException {
        MemoryManageable result = null;
        synchronized (outLock) {
            while (internalList.isEmpty() && !closed) {
                outLock.wait(WAIT_TIMEOUT);
            }
            result = dequeueNoWait();
        }
        return result;
    }

    /**
     * Dequeues a MemoryManageable                 from the head of the queue
     *
     * @param timeInMillis time to wait for a MemoryManageable                 to be available
     * @return the first MemoryManageable                 or null if none available within <I>timeInMillis </I>
     * @throws InterruptedException
     */
    public MemoryManageable dequeue(long timeInMillis) throws InterruptedException {
        MemoryManageable result = null;
        if (timeInMillis == 0) {
            result = dequeue();
        }
        else {
            synchronized (outLock) {
                // if timeInMillis is less than zero assume nowait
                long waitTime = timeInMillis;
                long start = (timeInMillis <= 0) ? 0 : System.currentTimeMillis();
                while (!closed) {
                    result = dequeueNoWait();
                    if (result != null || waitTime <= 0) {
                        break;
                    }
                    else {
                        outLock.wait(waitTime);
                        waitTime = timeInMillis - (System.currentTimeMillis() - start);
                    }
                }
            }
        }
        return result;
    }

    /**
     * dequeues a MemoryManageable from the head of the queue
     *
     * @return the MemoryManageable                 at the head of the queue or null, if none is available
     * @throws InterruptedException
     */
    public MemoryManageable dequeueNoWait() throws InterruptedException {
        MemoryManageable packet = null;
        synchronized (outLock) {
            while (stopped && !closed) {
                outLock.wait(WAIT_TIMEOUT);
            }
        }
        packet = (MemoryManageable) internalList.removeFirst();
        decrementMemoryUsed(packet);
        if (packet != null) {
            synchronized (inLock) {
                inLock.notify();
            }
        }
        return packet;
    }

    /**
     * @return true if the queue is enabled for dequeing (default = true)
     */
    public boolean isStarted() {
        synchronized (outLock) {
            return stopped == false;
        }
    }

    /**
     * disable dequeueing
     */
    public void stop() {
        synchronized (outLock) {
            stopped = true;
        }
    }

    /**
     * enable dequeueing
     */
    public void start() {
        synchronized (outLock) {
            stopped = false;
            outLock.notifyAll();
        }
        synchronized (inLock) {
            inLock.notifyAll();
        }
    }

    /**
     * Remove a packet from the queue
     *
     * @param packet
     * @return true if the packet was found
     */
    public boolean remove(MemoryManageable packet) {
        boolean result = false;
        if (!internalList.isEmpty()) {
            result = internalList.remove(packet);
        }
        if (result) {
            decrementMemoryUsed(packet);
        }
        synchronized (inLock) {
            inLock.notify();
        }
        return result;
    }

    /**
     * Remove a MemoryManageable                 by it's id
     *
     * @param id
     * @return
     */
    public MemoryManageable remove(Object id) {
        MemoryManageable result = null;
        QueueListEntry entry = internalList.getFirstEntry();
        try {
            while (entry != null) {
                MemoryManageable p = (MemoryManageable) entry.getElement();
                if (p.getMemoryId().equals(id)) {
                    result = p;
                    remove(p);
                    break;
                }
                entry = internalList.getNextEntry(entry);
            }
        }
        catch (JMSException jmsEx) {
            jmsEx.printStackTrace();
        }
        synchronized (inLock) {
            inLock.notify();
        }
        return result;
    }

    /**
     * remove any MemoryManageable                s in the queue
     */
    public void clear() {
        while (!internalList.isEmpty()) {
            MemoryManageable packet = (MemoryManageable) internalList.removeFirst();
            decrementMemoryUsed(packet);
        }
        synchronized (inLock) {
            inLock.notifyAll();
        }
    }

    /**
     * @return true if the queue is empty
     */
    public boolean isEmpty() {
        return internalList.isEmpty();
    }

    /**
     * retrieve a MemoryManageable                 at an indexed position in the queue
     *
     * @param index
     * @return
     */
    public MemoryManageable get(int index) {
        return (MemoryManageable) internalList.get(index);
    }

    /**
     * Retrieve a shallow copy of the contents as a list
     *
     * @return a list containing the bounded queue contents
     */
    public List getContents() {
        Object[] array = internalList.toArray();
        List list = new ArrayList();
        for (int i = 0; i < array.length; i++) {
            list.add(array[i]);
        }
        return list;
    }

    protected void incrementMemoryUsed(MemoryManageable packet) {
        if (packet != null) {
            int size = OBJECT_OVERHEAD;
            if (packet != null) {
                if (packet.incrementMemoryReferenceCount() == 1) {
                    size += packet.getMemoryUsage();
                }
            }    
            memoryUsedByThisQueue.add(size);
            manager.incrementMemoryUsed(size);
        }
    }

    protected void decrementMemoryUsed(MemoryManageable packet) {
        if (packet != null) {
            int size = OBJECT_OVERHEAD;
            if (packet != null) {
                if ( packet.decrementMemoryReferenceCount() == 0) {
                    size += packet.getMemoryUsage();
                }
            }
                        
            memoryUsedByThisQueue.subtract(size);
            manager.decrementMemoryUsed(size);
        }
    }
    /**
     * @return Returns the name.
     */
    public String getName() {
        return name;
    }
}