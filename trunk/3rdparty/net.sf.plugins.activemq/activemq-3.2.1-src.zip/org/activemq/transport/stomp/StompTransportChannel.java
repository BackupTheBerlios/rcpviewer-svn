/**
 * 
 * Copyright 2005 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.transport.stomp;

import EDU.oswego.cs.dl.util.concurrent.Executor;

import org.activemq.message.Packet;
import org.activemq.transport.tcp.TcpTransportChannel;
import org.activemq.transport.tcp.TcpTransportServerChannel;

import javax.jms.JMSException;
import java.net.Socket;
import java.net.URI;
import java.io.IOException;

/**
 * A transport for using Stomp to talk to ActiveMQ
 *
 * @version $Revision: 1.1 $
 */
public class StompTransportChannel extends TcpTransportChannel {

    public StompTransportChannel() {
        super(new StompWireFormat());
    }

    public StompTransportChannel(URI remoteLocation) throws JMSException {
        super(new StompWireFormat(), remoteLocation);
    }

    public StompTransportChannel(URI remoteLocation, URI localLocation) throws JMSException {
        super(new StompWireFormat(), remoteLocation, localLocation);
    }

    public StompTransportChannel(TcpTransportServerChannel serverChannel, Socket socket, Executor executor)
            throws JMSException {
        super(serverChannel, new StompWireFormat(), socket, executor);
    }

    public StompTransportChannel(Socket socket, Executor executor) throws JMSException {
        super(new StompWireFormat(), socket, executor);
    }

    public StompWireFormat getTTMPWireFormat() {
        return (StompWireFormat) getWireFormat();
    }

    protected void readWireFormat() throws JMSException, IOException {
        // no need to read wire format from wire
    }
    
    protected void doConsumePacket(Packet packet) {
        if( packet == FlushPacket.PACKET ) {
            try {
                doAsyncSend(null);
            } catch (JMSException e) {
                getExceptionListener().onException(e);
            }
        } else {
            super.doConsumePacket(packet);
        }
    }
    
}
