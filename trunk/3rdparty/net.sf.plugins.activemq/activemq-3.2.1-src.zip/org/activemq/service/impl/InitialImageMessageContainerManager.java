/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service.impl;

import java.util.Iterator;
import java.util.Map;

import javax.jms.Destination;
import javax.jms.JMSException;

import org.activemq.broker.BrokerClient;
import org.activemq.filter.DestinationFilter;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ConsumerInfo;
import org.activemq.service.MessageContainerManager;

/**
 * Implements an initial image service where on subscription
 * the client will receive the last image that was previously cached.
 * This is very useful in financial market data and in rapidly changing
 * transient event models where you don't want to persist messages
 * when you are away, but wish to cache the last image, per destination
 * around so that when a new reliable consumer subscribes you receive the
 * latest value you may have missed.
 * <p/>
 * This is especially true in finance with slow moving markets where you may
 * have to wait a while for an update (or times when you subscribe after
 * market close etc).
 *
 * @version $Revision: 1.1.1.1 $
 */
public class InitialImageMessageContainerManager extends ProxyMessageContainerManager {
    private Map cache;
    private boolean topic;
    private DestinationFilter destinationFilter;

    /**
     * Creates a topic based initial image message container manager using the given destination filter
     *
     * @param delegate
     * @param cache
     * @param destinationFilter
     */
    public InitialImageMessageContainerManager(MessageContainerManager delegate, Map cache, DestinationFilter destinationFilter) {
        this(delegate, cache, true, destinationFilter);
    }

    public InitialImageMessageContainerManager(MessageContainerManager delegate, Map cache, boolean topic, DestinationFilter destinationFilter) {
        super(delegate);
        this.cache = cache;
        this.topic = topic;
        this.destinationFilter = destinationFilter;
    }

    public void addMessageConsumer(BrokerClient client, ConsumerInfo info) throws JMSException {
        super.addMessageConsumer(client, info);

        // lookup message for destination
        ActiveMQDestination destination = info.getDestination();
        if (isValid(destination)) {
            if (destination.isWildcard()) {
                DestinationFilter filter = DestinationFilter.parseFilter(destination);
                sendMatchingInitialImages(client, info, filter);
            }
            else {
                ActiveMQMessage message = null;
                synchronized (cache) {
                    message = (ActiveMQMessage) cache.get(destination);
                }
                if (message != null) {
                    sendMessage(client, message);
                }
            }
        }
    }

    public void sendMessage(BrokerClient client, ActiveMQMessage message) throws JMSException {
        ActiveMQDestination destination = message.getJMSActiveMQDestination();
        if (isValid(destination)) {
            cache.put(destination, message);
        }
        super.sendMessage(client, message);
    }
   

    // Implementation methods
    //-------------------------------------------------------------------------
    protected void sendMatchingInitialImages(BrokerClient client, ConsumerInfo info, DestinationFilter filter) throws JMSException {
        synchronized (cache) {
            for (Iterator iter = cache.entrySet().iterator(); iter.hasNext();) {
                Map.Entry entry = (Map.Entry) iter.next();
                Destination destination = (Destination) entry.getKey();
                if (filter.matches(destination)) {
                    ActiveMQMessage message = (ActiveMQMessage) entry.getValue();
                    sendMessage(client, message);
                }
            }
        }
    }


    /**
     * Does this message match the destinations on which initial image caching should be used
     *
     * @param destination
     * @return true if the given destination should use initial image caching
     *         which is typically true if the message is a topic which may match
     *         an optional DestinationFilter
     */
    protected boolean isValid(ActiveMQDestination destination) {
        return destination.isTopic() == topic && (destinationFilter == null || destinationFilter.matches(destination));
    }
}
