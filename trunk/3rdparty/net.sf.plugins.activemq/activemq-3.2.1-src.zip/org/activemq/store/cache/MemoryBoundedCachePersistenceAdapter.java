/** 
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.cache;

import java.io.IOException;

import org.activemq.io.util.MemoryBoundedMessageCache;
import org.activemq.io.util.MemoryBoundedObjectManager;
import org.activemq.store.PersistenceAdapter;

/**
 * Provides a CachePersistenceAdapter that uses a MemoryBoundedLRUCache
 * for each destination.
 *
 * @version $Revision: 1.1.1.1 $
 */
public class MemoryBoundedCachePersistenceAdapter extends CachePersistenceAdapter {
	
	private MemoryBoundedObjectManager memoryManager;
    
    public MemoryBoundedCachePersistenceAdapter() {
		super();
	}

	public MemoryBoundedCachePersistenceAdapter(PersistenceAdapter longTermPersistence) throws IOException {
		super(longTermPersistence);
	}
	
	/**
	 * @see org.activemq.store.cache.CachePersistenceAdapter#createMessageCache(java.lang.String)
	 */
	protected MessageCache createMessageCache(String destinationName) {
		return new MemoryBoundedMessageCache(memoryManager);
	}

    /**
     * @return Returns the memoryManager.
     */
    public MemoryBoundedObjectManager getMemoryManager() {
        return memoryManager;
    }
    
    /**
     * @param memoryManager The memoryManager to set.
     */
    public void setMemoryManager(MemoryBoundedObjectManager memoryManager) {
        this.memoryManager = memoryManager;
    }
}
