/**
 * 
 * Copyright 2004 Hiram Chirino
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

import javax.jms.JMSException;

import org.activemq.io.WireFormat;
import org.activemq.message.ConsumerInfo;
import org.activemq.service.MessageIdentity;
import org.activemq.service.SubscriberEntry;
import org.activemq.store.RecoveryListener;
import org.activemq.store.TopicMessageStore;
import org.activemq.store.jdbc.JDBCAdapter.MessageListResultHandler;
import org.activemq.util.JMSExceptionHelper;

/**
 * @version $Revision: 1.1 $
 */
public class JDBCTopicMessageStore extends JDBCMessageStore implements TopicMessageStore {

    public JDBCTopicMessageStore(JDBCPersistenceAdapter persistenceAdapter, JDBCAdapter adapter, WireFormat wireFormat, String destinationName) {
        super(persistenceAdapter, adapter, wireFormat, destinationName);
    }

    public void setLastAcknowledgedMessageIdentity(String subscription, MessageIdentity messageIdentity) throws JMSException {
        long seq = getMessageSequenceId(messageIdentity);
        // Get a connection and insert the message into the DB.
        Connection c = null;
        try {
            c = persistenceAdapter.getConnection();
            adapter.doSetLastAck(c, destinationName, subscription,  seq);
        }
        catch (SQLException e) {
            throw JMSExceptionHelper.newJMSException("Failed to store ack for: " + subscription + " on message " + messageIdentity + " in container: " + e, e);
        }
        finally {
            persistenceAdapter.returnConnection(c);
        }
    }

    /**
     * @see org.activemq.store.TopicMessageStore#getLastestMessageIdentity()
     */
    public MessageIdentity getLastestMessageIdentity() throws JMSException {
        return new MessageIdentity(null, new Long(sequenceGenerator.getLastSequenceId()));
    }

    /**
     * 
     */
    public void recoverSubscription(String subscriptionId, MessageIdentity lastDispatchedMessage, final RecoveryListener listener) throws JMSException {

        Connection c = null;
        try {
            c = persistenceAdapter.getConnection();
            adapter.doRecoverSubscription(c, destinationName, subscriptionId, new MessageListResultHandler() {
                public void onMessage(long seq, String messageID) throws JMSException {
                    MessageIdentity messageIdentity = new MessageIdentity(messageID, new Long(seq));
                    listener.recoverMessage(messageIdentity);
                }
            });
        }
        catch (SQLException e) {
            throw JMSExceptionHelper.newJMSException("Failed to recover subscription: " + subscriptionId + ". Reason: " + e, e);
        }
        finally {
            persistenceAdapter.returnConnection(c);
        }
    }

    /**
     * @see org.activemq.store.TopicMessageStore#setSubscriberEntry(org.activemq.message.ConsumerInfo, org.activemq.service.SubscriberEntry)
     */
    public void setSubscriberEntry(ConsumerInfo info, SubscriberEntry subscriberEntry) throws JMSException {
        String key = info.getConsumerKey();
        Connection c = null;
        try {
            c = persistenceAdapter.getConnection();
            adapter.doSetSubscriberEntry(c, destinationName, key, subscriberEntry);
        }
        catch (SQLException e) {
            throw JMSExceptionHelper.newJMSException("Failed to lookup subscription for info: " + info + ". Reason: " + e, e);
        }
        finally {
            persistenceAdapter.returnConnection(c);
        }
    }

    /**
     * @see org.activemq.store.TopicMessageStore#getSubscriberEntry(org.activemq.message.ConsumerInfo)
     */
    public SubscriberEntry getSubscriberEntry(ConsumerInfo info) throws JMSException {
        String key = info.getConsumerKey();
        Connection c = null;
        try {
            c = persistenceAdapter.getConnection();
            return adapter.doGetSubscriberEntry(c, destinationName, key);
        }
        catch (SQLException e) {
            throw JMSExceptionHelper.newJMSException("Failed to lookup subscription for info: " + info + ". Reason: " + e, e);
        }
        finally {
            persistenceAdapter.returnConnection(c);
        }
    }

    public void deleteSubscription(String subscription) throws JMSException {
        Connection c = null;
        try {
            c = persistenceAdapter.getConnection();
            adapter.doDeleteSubscription(c, destinationName, subscription);
        }
        catch (SQLException e) {
            throw JMSExceptionHelper.newJMSException("Failed to remove subscription for: " + subscription + ". Reason: " + e, e);
        }
        finally {
            persistenceAdapter.returnConnection(c);
        }
    }

    public void incrementMessageCount(MessageIdentity messageId) throws JMSException {
    }

    public void decrementMessageCountAndMaybeDelete(MessageIdentity messageIdentity) throws JMSException {
    }

}
