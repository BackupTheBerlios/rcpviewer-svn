/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.transport.reliable;

/**
 * A Shuffled Multiple Combined Linear Congruential Generator Uses L'Ecuyer's CLCG4 with a Bays-Durham shuffle. From
 * <cite>Numerical Recipes inC </cite> This produces a more random stream of results than just
 * <code>java.util.Random</code>
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class SMLCGRandom {
    private static final long MULTIPLIER_1 = 40014;
    private static final long MOD_1 = 2147483563;
    private static final long MULTIPLIER_2 = 40692;
    private static final long MOD_2 = 2147483399;
    private static final int SHUFFLE_LEN = 32;
    private static final int WARMUP_LENGTH = 19;
    private int generated_1, generated_2, state;
    private int[] shuffle;

    /**
     * Creates a new pseudorandom number generator, seeded from the current time.
     */
    public SMLCGRandom() {
        this(System.currentTimeMillis());
    }

    /**
     * Creates the generator with the provided seed
     * 
     * @param seed
     */
    public SMLCGRandom(long seed) {
        shuffle = new int[SHUFFLE_LEN];
        this.setSeed(seed);
    }

    /**
     * Set the seed for the random generator
     * @param seed
     * @throws IllegalArgumentException
     */
    public void setSeed(long seed) throws IllegalArgumentException {
        int i;
        generated_1 = generated_2 = (int) (seed & 0x7FFFFFFFFL);  
        for (i = 0;i < WARMUP_LENGTH;i++) {
            generated_1 = (int) ((generated_1 * MULTIPLIER_1) % MOD_1);
        }
        for (i = 0;i < SHUFFLE_LEN;i++) {
            generated_1 = (int) ((generated_1 * MULTIPLIER_1) % MOD_1);
            shuffle[(SHUFFLE_LEN - 1) - i] = generated_1;
        }
        state = shuffle[0];
    }

    /**
     * @return the next random, uniformly distrubted, <tt>short</tt> value
     */
    public short nextShort() {
        return (short) ((((short) nextByte()) << 8) | ((short) (nextByte() & 0xFF)));
    }

    /**
     * @return the next random, uniformly distrubted, <tt>int</tt> value
     */
    public int nextInt() {
        return (int) ((((int) nextShort()) << 16) | (((int) nextShort()) & 0xFFFF));
    }

    /**
     * @return the next random, uniformly distrubted, <tt>long</tt> value
     */
    public long nextLong() {
        return (long) ((((long) nextInt()) << 32) | (((long) nextInt()) & 0xFFFFFFFFl));
    }

    /**
     * @return the next random, uniformly distributed, <tt>float</tt> value, greater than or equal to 0 and less than
     * 1.
     */
    public float nextFloat() {
        return (float) ((nextInt() & 0x7FFFFFFF) / (0x7FFFFFFF * 1.0));
    }

    /**
     * @return the next random, uniformly distributed, <tt>double</tt> value, greater than or equal to 0 and less than
     * 1.
     */
    public double nextDouble() {
        return (double) ((nextLong() & 0x7FFFFFFFFFFFFFFFl) / (0x7FFFFFFFFFFFFFFFl * 1.0));
    }

    /**
     * @return the next random, uniformly distrubted, <tt>byte</tt> value
     */
    public byte nextByte() {
        int i = 0;
        generated_1 = (int) ((generated_1 * MULTIPLIER_1) % MOD_1);
        generated_2 = (int) ((generated_2 * MULTIPLIER_2) % MOD_2);
        i = state / (1 + (((int) MOD_1) - 1) / SHUFFLE_LEN);
        i = Math.abs(i);
        state = (int) ((((long) shuffle[i]) + generated_2) % MOD_1);
        shuffle[i] = generated_1;
        return (byte) (state / (1 + (((int) MOD_1) - 1) / 256));
    }
}