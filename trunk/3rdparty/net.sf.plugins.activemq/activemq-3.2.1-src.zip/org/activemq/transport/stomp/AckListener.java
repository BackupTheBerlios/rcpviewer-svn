/*
 * Copyright (c) 2005 Your Corporation. All Rights Reserved.
 */
package org.activemq.transport.stomp;

import org.activemq.message.ActiveMQMessage;

class AckListener
{
    private final ActiveMQMessage msg;
    private final String consumerId;
    private final short consumerNo;
    private final String subscriptionId;

    public AckListener(ActiveMQMessage msg, String consumerId, short consumer_no, String subscriptionId)
    {
        this.msg = msg;
        this.consumerId = consumerId;
        consumerNo = consumer_no;
        this.subscriptionId = subscriptionId;
    }

    boolean handle(String messageId)
    {
        return msg.getJMSMessageID().equals(messageId);
    }

    public ActiveMQMessage getMessage()
    {
        return msg;
    }

    public String getConsumerId()
    {
        return consumerId;
    }

    public short getConsumerNo()
    {
        return consumerNo;
    }

    public String getSubscriptionId()
    {
        return subscriptionId;
    }
}
