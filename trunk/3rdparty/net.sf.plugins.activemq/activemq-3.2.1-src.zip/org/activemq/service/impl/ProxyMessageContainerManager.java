/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service.impl;

import java.util.Map;

import javax.jms.JMSException;

import org.activemq.broker.BrokerClient;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ConsumerInfo;
import org.activemq.message.MessageAck;
import org.activemq.service.DeadLetterPolicy;
import org.activemq.service.MessageContainer;
import org.activemq.service.MessageContainerManager;

/**
 * A Proxy implementation of {@link MessageContainerManager} which
 * delegates to some other implementation which is useful for writing
 * Facade implementations
 *
 * @version $Revision: 1.1.1.1 $
 */
public abstract class ProxyMessageContainerManager implements MessageContainerManager {
    private MessageContainerManager delegate;

    public ProxyMessageContainerManager() {
    }

    public ProxyMessageContainerManager(MessageContainerManager delegate) {
        this.delegate = delegate;
    }

    public Map getDestinations() {
        return getDelegate().getDestinations();
    }

    public Map getLocalDestinations() {
        return getDelegate().getDestinations();
    }

    public void acknowledgeMessage(BrokerClient client, MessageAck ack) throws JMSException {
        getDelegate().acknowledgeMessage(client, ack);
    }

    public void addMessageConsumer(BrokerClient client, ConsumerInfo info) throws JMSException {
        getDelegate().addMessageConsumer(client, info);
    }

    public void deleteSubscription(String clientId, String subscriberName) throws JMSException {
        getDelegate().deleteSubscription(clientId, subscriberName);
    }

    public void poll() throws JMSException {
        getDelegate().poll();
    }

    public void removeMessageConsumer(BrokerClient client, ConsumerInfo info) throws JMSException {
        getDelegate().removeMessageConsumer(client, info);
    }

    public void sendMessage(BrokerClient client, ActiveMQMessage message) throws JMSException {
        getDelegate().sendMessage(client, message);
    }

    public MessageContainer getContainer(String physicalName) throws JMSException {
        return getDelegate().getContainer(physicalName);
    }

    public void start() throws JMSException {
        getDelegate().start();
    }

    public void stop() throws JMSException {
        getDelegate().stop();
    }
    
    public void createMessageContainer(ActiveMQDestination destination) throws JMSException {
        getDelegate().createMessageContainer(destination);
    }
    
    public void destroyMessageContainer(ActiveMQDestination destination) throws JMSException {
        getDelegate().destroyMessageContainer(destination);
    }
    
    public Map getMessageContainerAdmins() throws JMSException {
        return getDelegate().getMessageContainerAdmins();
    }
    
    /**
     * @return the DeadLetterPolicy for this Container Manager
     */
    public DeadLetterPolicy getDeadLetterPolicy(){
        return getDelegate().getDeadLetterPolicy();
    }
    
    /**
     * Set the DeadLetterPolicy for this Container Manager
     * @param policy
     */
    public void setDeadLetterPolicy(DeadLetterPolicy policy){
        getDelegate().setDeadLetterPolicy(policy);
    }

    // Implementation methods
    //-------------------------------------------------------------------------
    protected MessageContainerManager getDelegate() {
        return delegate;
    }

    protected void setDelegate(MessageContainerManager delegate) {
        this.delegate = delegate;
    }
}
