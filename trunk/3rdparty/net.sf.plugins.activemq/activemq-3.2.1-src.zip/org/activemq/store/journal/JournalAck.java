package org.activemq.store.journal;

public class JournalAck {


    private String destination;
    private String subscription;
    private String messageId;
    private Object transactionId;


    public JournalAck(String destination, String subscription, String messageId, Object transactionId) {
        this.destination = destination;
        this.subscription = subscription;
        this.messageId = messageId;
        this.transactionId = transactionId;
    }


    public String getDestination() {
        return destination;
    }


    public void setDestination(String destination) {
        this.destination = destination;
    }


    public String getMessageId() {
        return messageId;
    }


    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }


    public String getSubscription() {
        return subscription;
    }


    public void setSubscription(String subscription) {
        this.subscription = subscription;
    }


    public Object getTransactionId() {
        return transactionId;
    }


    public void setTransactionId(Object transactionId) {
        this.transactionId = transactionId;
    }



}
