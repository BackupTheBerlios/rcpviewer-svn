/*
 * Created on Apr 22, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package org.activemq.service;

import java.util.Map;

import javax.jms.JMSException;

import org.activemq.broker.BrokerClient;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ConsumerInfo;
import org.activemq.message.MessageAck;

/**
 * A manager of MessageContainer instances
 */
public interface MessageContainerManager extends Service {
    
    /**
     * Creates a destination.
     * @param dest
     * @throws JMSException
     *
     */
    public void createMessageContainer(ActiveMQDestination dest) throws JMSException;

    /**
     * Destroys a destination.
     * @param dest
     * @throws JMSException
     *
     */
    public void destroyMessageContainer(ActiveMQDestination dest) throws JMSException;
        
    /**
     * Returns an unmodifiable map, indexed by ActiveMQDestination, of all the {@link org.activemq.service.MessageContainerAdmin}
     * objects available in this container
     * 
     * @return the Map
     * @throws JMSException
     */
    public Map getMessageContainerAdmins() throws JMSException;

    /**
     * Returns an unmodifiable map, indexed by String name, of all the {@link javax.jms.Destination}
     * objects available in this container
     *
     * @return
     */
    public Map getDestinations();

    /**
     * Returns an unmodifiable map, indexed by String name, of all the {@link javax.jms.Destination}
     * objects used by non-broker consumers directly connected to this container
     *
     * @return
     */
    public Map getLocalDestinations();

    /**
     * @param client
     * @param info
     * @throws JMSException
     */
    public abstract void addMessageConsumer(BrokerClient client, ConsumerInfo info) throws JMSException;

    /**
     * @param client
     * @param info
     * @throws JMSException
     */
    public abstract void removeMessageConsumer(BrokerClient client, ConsumerInfo info) throws JMSException;

    /**
     * Delete a durable subscriber
     *
     * @param clientId
     * @param subscriberName
     * @throws JMSException if the subscriber doesn't exist or is still active
     */
    public abstract void deleteSubscription(String clientId, String subscriberName) throws JMSException;

    /**
     * @param client
     * @param message
     * @throws JMSException
     */
    public abstract void sendMessage(BrokerClient client, ActiveMQMessage message) throws JMSException;

    /**
     * Acknowledge a message as being read and consumed by the Consumer
     *
     * @param client
     * @param ack
     * @throws JMSException
     */
    public abstract void acknowledgeMessage(BrokerClient client, MessageAck ack) throws JMSException;

    /**
     * Poll for messages
     *
     * @throws JMSException
     */
    public abstract void poll() throws JMSException;

    /**
     * Allows the lookup of a specific named message container
     *
     * @param physicalName
     * @return the MessageContainer
     * @throws JMSException
     */
    public MessageContainer getContainer(String physicalName) throws JMSException;

    /**
     * @return the DeadLetterPolicy for this Container Manager
     */
    public DeadLetterPolicy getDeadLetterPolicy();
    
    /**
     * Set the DeadLetterPolicy for this Container Manager
     * @param policy
     */
    public void setDeadLetterPolicy(DeadLetterPolicy policy);
}