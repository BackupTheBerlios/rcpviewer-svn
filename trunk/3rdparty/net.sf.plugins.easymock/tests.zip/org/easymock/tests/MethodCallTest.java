/*
 * Copyright (c) 2001-2004 OFFIS. This program is made available under the terms of
 * the MIT License.
 */
package org.easymock.tests;

import java.lang.reflect.Method;

import org.easymock.internal.Arguments;
import org.easymock.internal.MethodCall;

import junit.framework.TestCase;

public class MethodCallTest extends TestCase {

    
	private MethodCall call;
    private MethodCall equalCall;
    private MethodCall nonEqualCall;

    protected void setUp() throws SecurityException, NoSuchMethodException {
		Arguments arguments1 = new Arguments(new Object[] { "" });
		Arguments arguments2 = new Arguments(new Object[] { "" });
		Arguments arguments3 = new Arguments(new Object[] { "X" });
		Method m = Object.class.getMethod("equals", new Class[] {Object.class});
		call = new MethodCall(m, arguments1);
		equalCall = new MethodCall(m, arguments2);
		nonEqualCall = new MethodCall(m, arguments3);
	}

    public void testEquals() {
		assertFalse(call.equals(null));
		assertFalse(call.equals(""));
		assertTrue(call.equals(equalCall));		
        assertFalse(call.equals(nonEqualCall));
    }
    
    public void testHashCode() {
        try {
	        call.hashCode();
	        fail();
        } catch (UnsupportedOperationException expected) {
            assertEquals("hashCode() is not implemented", expected.getMessage());
        }
	// TODO: handle exception
}
    
}