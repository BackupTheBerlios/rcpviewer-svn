/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.io.util;
import java.io.IOException;
import java.util.zip.Deflater;
import java.util.zip.GZIPInputStream;

/**
 * Compression stream
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class ByteArrayCompression{
    
    /**
     * Data size above which compression will be used
     */
    public static final int DEFAULT_COMPRESSION_LIMIT = 32 * 1024;
    
    /**
     * Default compression level - 0 being none, 9 being best
     */
    public static final int DEFAULT_COMPRESSION_LEVEL = Deflater.BEST_SPEED;
    
    /**
     * Default Compression Strategy
     */
    public static final int DEFAULT_COMPRESSION_STRATEGY = Deflater.DEFAULT_STRATEGY;
    
    private int compressionLimit = DEFAULT_COMPRESSION_LIMIT;
    private int compressionLevel = DEFAULT_COMPRESSION_LEVEL;
    private int compressionStrategy = DEFAULT_COMPRESSION_STRATEGY;//default compression strategy
    
    /**
     * @return Returns the compressionLevel.
     */
    public int getCompressionLevel() {
        return compressionLevel;
    }
    /**
     * @param compressionLevel The compressionLevel to set.
     */
    public void setCompressionLevel(int compressionLevel) {
        this.compressionLevel = compressionLevel;
    }
    /**
     * @return Returns the compressionLimit.
     */
    public int getCompressionLimit() {
        return compressionLimit;
    }
    /**
     * @param compressionLimit The compressionLimit to set.
     */
    public void setCompressionLimit(int compressionLimit) {
        this.compressionLimit = compressionLimit;
    }
    /**
     * @return Returns the compressionStrategy.
     */
    public int getCompressionStrategy() {
        return compressionStrategy;
    }
    /**
     * @param compressionStrategy The compressionStrategy to set.
     */
    public void setCompressionStrategy(int compressionStrategy) {
        this.compressionStrategy = compressionStrategy;
    }
    /**
     * test for compressed data
     * @param ba
     * @return true if the data in the ByteArray is compressed
     */
    public static boolean isCompressed(ByteArray ba){
        boolean answer = false;
        if (ba != null && ba.getLength() > 2){
           answer = ((int)(ba.get(0) & 0xff) | (int)((ba.get(1) & 0xff)<< 8)) == GZIPInputStream.GZIP_MAGIC;
        }
        return answer; 
    }
    
    /**
     * Deflate the data in the ByteArray
     * @param ba
     * @return the passed in ba if data is not compressed else a new ByteArray
     * @throws IOException
     */
    public ByteArray deflate(ByteArray ba) throws IOException{
        ByteArray answer = ba;
        if (ba != null && ba.getLength() > compressionLimit && !ByteArrayCompression.isCompressed(ba)){
            WireByteArrayOutputStream bytesOut = new WireByteArrayOutputStream();
            WireGZIPOutputStream gzipOut = new WireGZIPOutputStream(bytesOut);
            gzipOut.getDeflater().setStrategy(compressionStrategy);
            gzipOut.getDeflater().setLevel(compressionLevel);
            gzipOut.write(ba.getBuf(),ba.getOffset(),ba.getLength());
            gzipOut.close();
            bytesOut.close();
            answer = new ByteArray(bytesOut.getData(),0,bytesOut.size());
        }
        return answer;
    }
    
    /**
     * Inflate a ByteArray (if it contains compressed data)
     * @param ba
     * @return the inflated ByteArray
     * @throws IOException
     */
    public ByteArray inflate(ByteArray ba) throws IOException {
        ByteArray answer = ba;
        if (ba != null && ByteArrayCompression.isCompressed(ba)){
            WireByteArrayInputStream bytesIn = new WireByteArrayInputStream(ba);
            GZIPInputStream gzipIn = new GZIPInputStream(bytesIn);
            WireByteArrayOutputStream bytesOut = new WireByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int count = 0;
            while ((count = gzipIn.read(buffer)) > 0 ){
                bytesOut.write(buffer,0,count);
            }
            bytesOut.close();
            answer = new ByteArray(bytesOut.getData(),0,bytesOut.size());
        }
        return answer;
    }
        
}