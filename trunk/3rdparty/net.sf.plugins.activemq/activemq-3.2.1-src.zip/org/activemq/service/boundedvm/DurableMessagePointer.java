/** 
 * 
 * Copyright 2004 Protique Ltd
 * Copyright 2005 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service.boundedvm;

import javax.jms.JMSException;

import org.activemq.io.util.MemoryManageable;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQMessage;
import org.activemq.store.MessageStore;

/**
 * DurableMessagePointers are moved around in the DurableQueueBoundedMessageManager
 * so that we remember the associated messageStore that the message has been 
 * persisted to.
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class DurableMessagePointer implements MemoryManageable {
    
    private final MessageStore messageStore;
    private final ActiveMQMessage message;
        
    public DurableMessagePointer(MessageStore messageStore, ActiveMQDestination destination, ActiveMQMessage message) {
        this.messageStore = messageStore;
        this.message = message;
    }

    public ActiveMQMessage getMessage() {
        return message;
    }

    public Object getMemoryId() {
        return message.getMemoryId();
    }

    public int getMemoryUsage() {
        return message.getMemoryUsage();
    }

    public int incrementMemoryReferenceCount() {
        return message.incrementMemoryReferenceCount();
    }

    public int decrementMemoryReferenceCount() {
        return message.decrementMemoryReferenceCount();
    }

    public int getMemoryUsageReferenceCount() {
        return message.getMemoryUsageReferenceCount();
    }
    
    public int incrementDeliveryCount() throws JMSException {
        return message.incrementDeliveryCount();
    }

    public int incrementRedeliveryCount() throws JMSException {
        return message.incrementRedeliveryCount();
    }

    /**
     * @return Returns the messageStore.
     */
    public MessageStore getMessageStore() {
        return messageStore;
    }
    
    public String toString(){
        return "DMP - msg = " +  message;
    }
    
    public int getPriority() {
    	return message.getPriority();
    }
}
