/**
 *
 * Copyright 2004 Protique Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/

package org.activemq.io.impl;
import java.io.DataInput;
import java.io.IOException;

import org.activemq.message.AbstractPacket;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQXid;
import org.activemq.message.MessageAck;
import org.activemq.message.Packet;
import org.activemq.util.BitArray;

/**
 * Reads a ConsumerInfo object from a Stream
 */
public class MessageAckReader extends AbstractPacketReader {
    private AbstractDefaultWireFormat wireFormat;

    MessageAckReader(AbstractDefaultWireFormat wf) {
        this.wireFormat = wf;
    }

    MessageAckReader() {
    }

    /**
     * Return the type of Packet
     * 
     * @return integer representation of the type of Packet
     */
    public int getPacketType() {
        return Packet.ACTIVEMQ_MSG_ACK;
    }

    /**
     * @return a new Packet instance
     */
    public Packet createPacket() {
        return new MessageAck();
    }

    /**
     * build a Packet instance from the data input stream
     * 
     * @param packet A Packet object
     * @param dataIn the data input stream to build the packet from
     * @throws IOException
     */
    public void buildPacket(Packet packet, DataInput dataIn) throws IOException {
        MessageAck ack = (MessageAck) packet;
        BitArray ba = ack.getBitArray();
        ba.readFromStream(dataIn);
        boolean cachingEnabled = ba.get(MessageAck.CACHED_VALUES_INDEX);
        ack.setMessageRead(ba.get(MessageAck.MESSAGE_READ_INDEX));
        ack.setPersistent(ba.get(MessageAck.PERSISTENT_INDEX));
        ack.setExpired(ba.get(MessageAck.EXPIRED_INDEX));
        if (ba.get(AbstractPacket.RECEIPT_REQUIRED_INDEX)) {
            ack.setReceiptRequired(true);
            ack.setId(dataIn.readShort());
        }
        if (ba.get(MessageAck.EXTERNAL_MESSAGE_ID_INDEX)) {
            ack.setExternalMessageId(true);
            ack.setMessageID(dataIn.readUTF());
        }
        else {
            if (cachingEnabled) {
                short key = dataIn.readShort();
                ack.setProducerKey((String) wireFormat.getValueFromReadCache(key));
            }
            else {
                ack.setProducerKey(dataIn.readUTF());
            }
            if (ba.get(MessageAck.LONG_SEQUENCE_INDEX)) {
                ack.setSequenceNumber(dataIn.readLong());
            }
            else {
                ack.setSequenceNumber(dataIn.readInt());
            }
        }
        if (ba.get(AbstractPacket.BROKERS_VISITED_INDEX)) {
            int visitedLen = dataIn.readShort();
            for (int i = 0;i < visitedLen;i++) {
                ack.addBrokerVisited(dataIn.readUTF());
            }
        }
        if (ba.get(MessageAck.TRANSACTION_ID_INDEX)) {
            if (cachingEnabled) {
                short key = dataIn.readShort();
                ack.setTransactionId(wireFormat.getValueFromReadCache(key));
            } else {
                if (ba.get(MessageAck.XA_TRANS_INDEX)) {
                    ack.setTransactionId(ActiveMQXid.read(dataIn));
                }
                else {
                    ack.setTransactionId(super.readUTF(dataIn));
                }
            }
        }
        else {
            ack.setTransactionId(null);
        }
        if (cachingEnabled) {
            short key = dataIn.readShort();
            ack.setConsumerId((String) wireFormat.getValueFromReadCache(key));
            key = dataIn.readShort();
            ack.setDestination((ActiveMQDestination) wireFormat.getValueFromReadCache(key));
        }
        else {
            ack.setConsumerId(dataIn.readUTF());
            ack.setDestination(ActiveMQDestination.readFromStream(dataIn));
        }
    }
}