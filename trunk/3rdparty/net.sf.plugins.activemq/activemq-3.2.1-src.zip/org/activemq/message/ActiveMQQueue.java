/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

import org.activemq.management.JMSDestinationStats;
import org.activemq.management.JMSQueueStatsImpl;

import javax.jms.Destination;
import javax.jms.Queue;


/**
 * A <CODE>Queue</CODE> object encapsulates a provider-specific queue name.
 * It is the way a client specifies the identity of a queue to JMS API methods.
 * For those methods that use a <CODE>Destination</CODE> as a parameter, a
 * <CODE>Queue</CODE> object used as an argument. For example, a queue can
 * be used  to create a <CODE>MessageConsumer</CODE> and a
 * <CODE>MessageProducer</CODE>  by calling:
 * <UL>
 * <LI> <CODE>Session.CreateConsumer(Destination destination)</CODE>
 * <LI> <CODE>Session.CreateProducer(Destination destination)</CODE>
 * <p/>
 * </UL>
 * <p/>
 * <P>The actual length of time messages are held by a queue and the
 * consequences of resource overflow are not defined by the JMS API.
 *
 * @see javax.jms.Session#createConsumer(javax.jms.Destination)
 * @see javax.jms.Session#createProducer(javax.jms.Destination)
 * @see javax.jms.Session#createQueue(String)
 * @see javax.jms.QueueSession#createQueue(String)
 */

public class ActiveMQQueue extends ActiveMQDestination implements Queue {

    private static final long serialVersionUID = -8153802971552885826L;

    /**
     * Default constructor for an ActiveMQQueue Destination
     */
    public ActiveMQQueue() {
        super();
    }

    /**
     * Construct a named ActiveMQQueue Destination
     *
     * @param name
     */

    public ActiveMQQueue(String name) {
        super(name);
    }

    /**
     * Gets the name of this queue.
     * <p/>
     * <P>Clients that depend upon the name are not portable.
     *
     * @return the queue name
     */

    public String getQueueName() {
        return super.getPhysicalName();
    }

    /**
     * @return Returns the Destination type
     */

    public int getDestinationType() {
        return ACTIVEMQ_QUEUE;
    }
    
    /**
     * Returns true if a Topic Destination
     *
     * @return true/false
     */

    public boolean isTopic() {
        return false;
    }

    /**
     * Returns true if a Queue Destination
     *
     * @return true/false
     */
    public boolean isQueue() {
        return true;
    }

    protected Destination createDestination(String name) {
        return new ActiveMQQueue(name);
    }

    protected JMSDestinationStats createDestinationStats() {
        return new JMSQueueStatsImpl();
    }

}
