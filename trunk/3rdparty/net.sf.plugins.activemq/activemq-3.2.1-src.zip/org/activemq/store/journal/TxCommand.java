/** 
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.journal;

/**
 */
public class TxCommand {
    public static final byte XA_PREPARE=1; 
    public static final byte XA_COMMIT=2; 
    public static final byte XA_ROLLBACK=3; 
    public static final byte LOCAL_COMMIT=4; 
    public static final byte LOCAL_ROLLBACK=5; 
    
    public byte type;
    public boolean wasPrepared;
    public Object transactionId;

    public TxCommand(byte type, Object transactionId, boolean wasPrepared) {
        this.type = type;
        this.transactionId = transactionId;
        this.wasPrepared=wasPrepared;
    }
    public TxCommand() {
    }
  
    public Object getTransactionId() {
        return transactionId;
    }
    
    public void setTransactionId(Object transactionId) {
        this.transactionId = transactionId;
    }
    
    public byte getType() {
        return type;
    }
    public void setType(byte type) {
        this.type = type;
    }
    
    public boolean getWasPrepared() {
        return wasPrepared;
    }
    public void setWasPrepared(boolean wasPrepared) {
        this.wasPrepared = wasPrepared;
    }
}
