/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.transport.remote;

import javax.jms.JMSException;

import org.activemq.broker.BrokerConnector;
import org.activemq.broker.BrokerContainer;
import org.activemq.broker.impl.BrokerConnectorImpl;
import org.activemq.broker.impl.BrokerContainerImpl;
import org.activemq.io.WireFormat;
import org.activemq.transport.NetworkChannel;
import org.activemq.transport.NetworkConnector;
import org.activemq.transport.RemoteNetworkConnector;
import org.activemq.transport.vm.VmTransportChannel;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import EDU.oswego.cs.dl.util.concurrent.SynchronizedBoolean;

/**
 * A <CODE>RemoteTransportChannel</CODE> creates an embedded broker that creates a remote connection to another
 * broker. This connection type is designed for reliable connections, that can use the storage mechansims of an embedded
 * broker to be decoupled from the remote broker - i.e. for connections that need to be reliable, don't block but maybe
 * using a transport across an unreliable network connection
 * <P>
 * 
 * <P>
 * An example of the expected format is: <CODE>remote://tcp://remotebroker:5060</CODE>
 * <P>
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class RemoteTransportChannel extends VmTransportChannel{

    private static final Log log = LogFactory.getLog(RemoteTransportChannel.class);
    private WireFormat wireFormat;
    private String remoteUserName;
    private String remotePassword;
    private String brokerName;
    private String remoteLocation;
    private BrokerContainer container;
    private NetworkConnector networkConnector;
    private SynchronizedBoolean brokerConnectorStarted = new SynchronizedBoolean(false);

    /**
     * Construct a RemoteTransportChannel
     * 
     * @param wireFormat
     * @param peerURIs
     * @throws JMSException
     */
    protected RemoteTransportChannel(WireFormat wireFormat,String remoteLocation) throws JMSException{
        this.wireFormat = wireFormat;
        this.remoteLocation = remoteLocation;
    }

    /**
     * @return true if the transport channel is active, this value will be false through reconnecting
     */
    public boolean isTransportConnected(){
        return true;
    }

    /**
     * Some transports rely on an embedded broker (beer based protocols)
     * 
     * @return true if an embedded broker required
     */
    public boolean requiresEmbeddedBroker(){
        return true;
    }

    /**
     * Provides a way to specify the client ID that this channel is using
     * 
     * @param clientID
     */
    public void setClientID(String clientID){
        super.setClientID(clientID);
        if(brokerConnectorStarted.commit(false,true)){
            if(brokerName==null){
                brokerName = clientID;
            }
            if(container!=null){
                container.getBroker().getBrokerInfo().setBrokerName(brokerName);
                container.getBroker().getBrokerInfo().setClusterName(brokerName);
                try{
                    container.start();
                    Thread.sleep(1000);
        
                   
                }catch(Exception e){
                    log.error("Failed to start brokerConnector",e);
                }
            }
        }
    }

    public void stop(){
        super.stop();
        if(container!=null){
            try{
                container.stop();
            }catch(JMSException e){
                log.warn("Caught exception stopping Broker",e);
            }
        }
    }

    /**
     * Some transports that rely on an embedded broker need to create the connector used by the broker
     * 
     * @return the BrokerConnector or null if not applicable
     * @throws JMSException
     */
    public BrokerConnector getEmbeddedBrokerConnector() throws JMSException{
        try{
            BrokerConnector brokerConnector = null;
            if(container==null){

                container = new BrokerContainerImpl("NotSet","NotSet");

                networkConnector = networkConnector = new RemoteNetworkConnector(container);
                NetworkChannel channel = networkConnector.addNetworkChannel(remoteLocation);
                channel.setRemoteUserName(remoteUserName);
                channel.setRemotePassword(remotePassword);

                container.addNetworkConnector(networkConnector);
                brokerConnector = new BrokerConnectorImpl(container);
               
            }
            return brokerConnector;
        }catch(Exception e){
            e.printStackTrace();
            String errorStr = "Failed to get embedded connector";
            log.error(errorStr,e);
            JMSException jmsEx = new JMSException(errorStr);
            jmsEx.setLinkedException(e);
            throw jmsEx;
        }
    }

    /**
     * @return Returns the remoteLocation.
     */
    public String getRemoteLocation(){
        return remoteLocation;
    }

    /**
     * @param remoteLocation
     *            The remoteLocation to set.
     */
    public void setRemoteLocation(String remoteLocation){
        this.remoteLocation = remoteLocation;
    }

    /**
     * @return Returns the remotePassword.
     */
    public String getRemotePassword(){
        return remotePassword;
    }

    /**
     * @param remotePassword
     *            The remotePassword to set.
     */
    public void setRemotePassword(String remotePassword){
        this.remotePassword = remotePassword;
    }

    /**
     * @return Returns the remoteUserName.
     */
    public String getRemoteUserName(){
        return remoteUserName;
    }

    /**
     * @param remoteUserName
     *            The remoteUserName to set.
     */
    public void setRemoteUserName(String remoteUserName){
        this.remoteUserName = remoteUserName;
    }

    /**
     * @return Returns the wireFormat.
     */
    public WireFormat getWireFormat(){
        return wireFormat;
    }

    /**
     * @param wireFormat
     *            The wireFormat to set.
     */
    public void setWireFormat(WireFormat wireFormat){
        this.wireFormat = wireFormat;
    }

    /**
     * @return Returns the brokerName.
     */
    public String getBrokerName(){
        return brokerName;
    }

    /**
     * @param brokerName
     *            The brokerName to set.
     */
    public void setBrokerName(String brokerName){
        this.brokerName = brokerName;
    }

}