/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.message;

import java.io.Serializable;

/**
 * Describes a Message consumer
 *
 * @version $Revision: 1.1.1.1 $
 */
public class ConsumerInfo extends AbstractPacket implements Serializable{
    static final long serialVersionUID = 3489666609L;
    private ActiveMQDestination destination;
    private String clientId;
    private short sessionId;
    private String consumerName;
    private String selector;
    private long startTime;
    private boolean started;
    private int consumerNo;
    private boolean noLocal;
    private boolean browser;
    private int prefetchNumber = 100;
    private transient String consumerKey;
    private String consumerId;

    
    
    /**
     * @return Returns the sessionId.
     */
    public short getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId The sessionId to set.
     */
    public void setSessionId(short sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */
    public int getPacketType() {
        return CONSUMER_INFO;
    }

    /**
     * Test for equality
     *
     * @param obj object to test
     * @return true if equivalent
     */
    public boolean equals(Object obj) {
        boolean result = false;
        if (obj != null && obj instanceof ConsumerInfo) {
            ConsumerInfo that = (ConsumerInfo) obj;
            result = this.getConsumerId().equals(that.getConsumerId());
        }
        return result;
    }

    /**
     * @return hash code for instance
     */
    public int hashCode() {
        return getConsumerId().hashCode();
    }

    /**
     * @return Returns the clientId.
     */
    public String getClientId() {
        return this.clientId;
    }

    /**
     * @param newClientId The clientId to set.
     */
    public void setClientId(String newClientId) {
        this.clientId = newClientId;
    }

    /**
     * @return Returns the destination.
     */
    public ActiveMQDestination getDestination() {
        return this.destination;
    }

    /**
     * @param newDestination The destination to set.
     */
    public void setDestination(ActiveMQDestination newDestination) {
        this.destination = newDestination;
    }

    /**
     * @return Returns the selector.
     */
    public String getSelector() {
        return this.selector;
    }

    /**
     * @param newSelector The selector to set.
     */
    public void setSelector(String newSelector) {
        this.selector = newSelector;
    }

    /**
     * @return Returns the started.
     */
    public boolean isStarted() {
        return this.started;
    }

    /**
     * @param flag to indicate if started
     */
    public void setStarted(boolean flag) {
        this.started = flag;
    }

    /**
     * @return Returns the startTime.
     */
    public long getStartTime() {
        return this.startTime;
    }

    /**
     * @param newStartTime The startTime to set.
     */
    public void setStartTime(long newStartTime) {
        this.startTime = newStartTime;
    }

    /**
     * @return Returns the consumerNo.
     */
    public int getConsumerNo() {
        return this.consumerNo;
    }

    /**
     * @param newConsumerNo The consumerNo to set.
     */
    public void setConsumerNo(int newConsumerNo) {
        this.consumerNo = newConsumerNo;
    }

    /**
     * @return Returns the consumer name.
     */
    public String getConsumerName() {
        return this.consumerName;
    }

    /**
     * @param newconsumerName The consumerName to set.
     */
    public void setConsumerName(String newconsumerName) {
        this.consumerName = newconsumerName;
    }

    /**
     * @return Returns true if the Consumer is a durable Topic subscriber
     */
    public boolean isDurableTopic() {
        return this.destination.isTopic() && !this.destination.isTemporary() && this.consumerName != null
                && this.consumerName.length() > 0;
    }

    /**
     * @return Returns the noLocal.
     */
    public boolean isNoLocal() {
        return noLocal;
    }

    /**
     * @param noLocal The noLocal to set.
     */
    public void setNoLocal(boolean noLocal) {
        this.noLocal = noLocal;
    }

    /**
     * @return Returns the browser.
     */
    public boolean isBrowser() {
        return browser;
    }

    /**
     * @param browser The browser to set.
     */
    public void setBrowser(boolean browser) {
        this.browser = browser;
    }

    /**
     * @return Returns the prefetchNumber.
     */
    public int getPrefetchNumber() {
        return prefetchNumber;
    }

    /**
     * @param prefetchNumber The prefetchNumber to set.
     */
    public void setPrefetchNumber(int prefetchNumber) {
        this.prefetchNumber = prefetchNumber;
    }


    /**
     * Creates a primary key for the consumer info which uniquely
     * describes the consumer using a combination of clientID and
     * consumerName
     *
     * @return the consumerKey
     */
    public String getConsumerKey() {
        if (consumerKey == null){
            consumerKey = generateConsumerKey(clientId,consumerName);
        }
        return consumerKey;
    }
    
    /**
     * @return Returns the consumerIdentifier.
     */
    public String getConsumerId() {
        if (consumerId == null){
            consumerId = clientId + "." + sessionId + "." + consumerNo;
        }
        return consumerId;
    }
    /**
     * @param consumerIdentifier The consumerIdentifier to set.
     */
    public void setConsumerId(String consumerIdentifier) {
        this.consumerId = consumerIdentifier;
    }
    
    
    /**
     * Generate a primary key for a consumer from the clientId and consumerName
     * @param clientId
     * @param consumerName
     * @return
     */
    public static String generateConsumerKey(String clientId, String consumerName){
        return "[" + clientId + ":" + consumerName + "]";
    }

    /**
     * @return true if the consumer is interested in advisory messages
     */
    public boolean isAdvisory(){
        return destination != null && destination.isAdvisory();
    }
    
    /**
     * @return a pretty print
     */
    public String toString() {
        return super.toString() + " ConsumerInfo{ " +
                "browser = " + browser +
                ", destination = " + destination +
                ", consumerIdentifier = '" + getConsumerId() + "' " +
                ", clientId = '" + clientId + "' " +
                ", sessionId = '" + sessionId + "' " +
                ", consumerName = '" + consumerName + "' " +
                ", selector = '" + selector + "' " +
                ", startTime = " + startTime +
                ", started = " + started +
                ", consumerNo = " + consumerNo +
                ", noLocal = " + noLocal +
                ", prefetchNumber = " + prefetchNumber +
                ", consumerKey = '" + getConsumerKey() + "' " +
                " }";
    }
}
