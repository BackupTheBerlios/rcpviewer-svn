/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

import javax.jms.TemporaryQueue;


/**
 * A <CODE>TemporaryQueue</CODE> object is a unique <CODE>Queue</CODE> object
 * created for the duration of a <CODE>Connection</CODE>. It is a
 * system-defined queue that can be consumed only by the
 * <CODE>Connection</CODE> that created it.
 * <p/>
 * <P>A <CODE>TemporaryQueue</CODE> object can be created at either the
 * <CODE>Session</CODE> or <CODE>QueueSession</CODE> level. Creating it at the
 * <CODE>Session</CODE> level allows to the <CODE>TemporaryQueue</CODE> to
 * participate in transactions with objects from the Pub/Sub  domain.
 * If it is created at the <CODE>QueueSession</CODE>, it will only
 * be able participate in transactions with objects from the PTP domain.
 *
 * @see javax.jms.Session#createTemporaryQueue()
 * @see javax.jms.QueueSession#createTemporaryQueue()
 */

public class ActiveMQTemporaryQueue extends ActiveMQQueue implements TemporaryQueue {

    private static final long serialVersionUID = 2177608393508673752L;

    /**
     * Default constructor for an ActiveMQTemporaryQueue Destination
     */
    public ActiveMQTemporaryQueue() {
        super();
    }

    /**
     * Construct a named ActiveMQTemporaryQueue Destination
     *
     * @param name
     */

    public ActiveMQTemporaryQueue(String name) {
        super(name);
    }
    
    /**
     * @return Returns the Destination type
     */

    public int getDestinationType() {
        return ACTIVEMQ_TEMPORARY_QUEUE;
    }
    
    /**
     * Returns true if a temporary Destination
     *
     * @return true/false
     */

    public boolean isTemporary() {
        return true;
    }
    
    /**
    * Returns true if a Topic Destination
    *
    * @return true/false
    */

   public boolean isTopic() {
       return false;
   }

   /**
    * Returns true if a Queue Destination
    *
    * @return true/false
    */
   public boolean isQueue() {
       return true;
   }
    
}
