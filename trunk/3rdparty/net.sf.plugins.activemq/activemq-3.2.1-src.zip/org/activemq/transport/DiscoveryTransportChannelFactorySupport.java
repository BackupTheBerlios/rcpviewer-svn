/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.transport;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;

import javax.jms.JMSException;

import org.activemq.io.WireFormat;
import org.activemq.transport.composite.CompositeTransportChannelFactory;
import org.activemq.util.BeanUtils;
import org.activemq.util.JMSExceptionHelper;
import org.activemq.util.URIHelper;

/**
 * @version $Revision: 1.1.1.1 $
 */
public abstract class DiscoveryTransportChannelFactorySupport extends CompositeTransportChannelFactory {
    private DiscoveryAgent discoveryAgent;

    public TransportChannel create(WireFormat wireFormat, URI remoteLocation) throws JMSException {
        if (discoveryAgent == null) {
            try {
                discoveryAgent = createDiscoveryAgent(remoteLocation);
            }
            catch (URISyntaxException e) {
                throw JMSExceptionHelper.newJMSException("Could not parse URI: " + remoteLocation + ". Reason: " + e, e);
            }

            // populate any properties on the discovery agent
            discoveryAgent = populateAgentProperties(discoveryAgent, remoteLocation);
        }
        return new DiscoveryTransportChannel(wireFormat, discoveryAgent);
    }

    public DiscoveryAgent getDiscoveryAgent() {
        return discoveryAgent;
    }

    public void setDiscoveryAgent(DiscoveryAgent discoveryAgent) {
        this.discoveryAgent = discoveryAgent;
    }

    protected abstract DiscoveryAgent createDiscoveryAgent(URI remoteLocation) throws JMSException, URISyntaxException;

    protected DiscoveryAgent populateAgentProperties(DiscoveryAgent agent, URI uri) throws JMSException {
        Map properties = URIHelper.parseQuery(uri);
        if (!properties.isEmpty()) {
            BeanUtils.populate(agent, properties);
        }
        return agent;
    }


}