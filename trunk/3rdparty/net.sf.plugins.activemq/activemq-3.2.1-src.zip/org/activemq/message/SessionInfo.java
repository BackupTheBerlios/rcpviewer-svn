/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

/**
 * Denotes an object that can be serialized/deserailized using a Packet Reader/Writer
 */

public class SessionInfo extends AbstractPacket {

    private String clientId;
    private short sessionId;
    private long startTime;
    private boolean started;
    private int sessionMode;

    /**
     * @return Returns the sessionMode.
     */
    public int getSessionMode() {
        return sessionMode;
    }
    /**
     * @param sessionMode The sessionMode to set.
     */
    public void setSessionMode(int sessionMode) {
        this.sessionMode = sessionMode;
    }
    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return SESSION_INFO;
    }


    /**
     * Test for equality
     *
     * @param obj object to test
     * @return true if equivalent
     */
    public boolean equals(Object obj) {
        boolean result = false;
        if (obj != null && obj instanceof SessionInfo) {
            SessionInfo info = (SessionInfo) obj;
            result = this.clientId.equals(info.clientId) && this.sessionId == info.sessionId;
        }
        return result;
    }

    /**
     * @return hash code for instance
     */
    public int hashCode() {
        if (cachedHashCode == -1){
            String hashCodeStr = clientId + sessionId;
            cachedHashCode = hashCodeStr.hashCode();
        }
        return cachedHashCode;
    }
    


    /**
     * @return Returns the sessionId.
     */
    public short getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId The sessionId to set.
     */
    public void setSessionId(short sessionId) {
        this.sessionId = sessionId;
    }


    /**
     * @return Returns the clientId.
     */
    public String getClientId() {
        return this.clientId;
    }

    /**
     * @param newClientId The clientId to set.
     */
    public void setClientId(String newClientId) {
        this.clientId = newClientId;
    }


    /**
     * @return Returns the started.
     */
    public boolean isStarted() {
        return this.started;
    }

    /**
     * @param flag to indicate if started
     */
    public void setStarted(boolean flag) {
        this.started = flag;
    }

    /**
     * @return Returns the startTime.
     */
    public long getStartTime() {
        return this.startTime;
    }

    /**
     * @param newStartTime The startTime to set.
     */
    public void setStartTime(long newStartTime) {
        this.startTime = newStartTime;
    }

    public String toString() {
        return super.toString() + " SessionInfo{ " +
                "clientId = '" + clientId + "' " +
                ", sessionId = '" + sessionId + "' " +
                ", startTime = " + startTime +
                ", started = " + started +
                " }";
    }
}
