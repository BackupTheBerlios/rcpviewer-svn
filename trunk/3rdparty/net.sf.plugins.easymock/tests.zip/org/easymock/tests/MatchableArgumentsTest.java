/*
 * Copyright (c) 2001-2004 OFFIS. This program is made available under the terms of
 * the MIT License.
 */
package org.easymock.tests;

import junit.framework.TestCase;

import org.easymock.MockControl;
import org.easymock.internal.Arguments;
import org.easymock.internal.MatchableArguments;

public class MatchableArgumentsTest extends TestCase {

    private Arguments arguments;
    private Arguments arguments2;
    private Arguments arguments3;

    protected void setUp() {
		arguments = new Arguments(new Object[] { "" });
		arguments2 = new Arguments(new Object[] { "" });
		arguments3 = new Arguments(new Object[] { "X" });
    }

    
    public void testEquals() {
		MatchableArguments matchableArguments = new MatchableArguments(arguments, MockControl.EQUALS_MATCHER);
		MatchableArguments equalMatchableArguments = new MatchableArguments(arguments2, MockControl.EQUALS_MATCHER);
		MatchableArguments nonEqualMatchableArguments = new MatchableArguments(arguments3, MockControl.EQUALS_MATCHER);
       
		assertFalse(matchableArguments.equals(null));
		assertFalse(matchableArguments.equals(""));
		assertTrue(matchableArguments.equals(equalMatchableArguments));		
        assertFalse(matchableArguments.equals(nonEqualMatchableArguments));
    }
    
    public void testHashCode() {
        try {
            new MatchableArguments(arguments, MockControl.EQUALS_MATCHER).hashCode();
	        fail();
        } catch (UnsupportedOperationException expected) {
            assertEquals("hashCode() is not implemented", expected.getMessage());
        }
    }
}