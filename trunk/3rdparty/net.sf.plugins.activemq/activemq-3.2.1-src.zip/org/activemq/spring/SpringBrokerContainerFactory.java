/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.spring;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.activemq.broker.BrokerContainer;
import org.activemq.broker.BrokerContainerFactory;
import org.activemq.broker.BrokerContext;
import org.activemq.util.IdGenerator;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceEditor;

/**
 * A Spring implementatation of {@link BrokerContainerFactory} which uses an XML
 * deployment configuration file to load and configure a {@link BrokerContainer}
 *
 * @version $Revision$
 */
public class SpringBrokerContainerFactory implements BrokerContainerFactory {
    private static final Log log = LogFactory.getLog(SpringBrokerContainerFactory.class);

    private Resource resource;


    /**
     * A static factory method that can be used in Spring config files using a factory method
     * mechanism to create a broker container easily.
     */
    public static BrokerContainer newInstance(Resource resource) {
        IdGenerator idgen = new IdGenerator();
        return newInstance(resource, idgen.generateId());
    }

    /**
     * A static factory method that can be used in Spring config files using a factory method
     * mechanism to create a broker container easily.
     */
    public static BrokerContainer newInstance(Resource resource, String brokerName) {
        SpringBrokerContainerFactory factory = new SpringBrokerContainerFactory(resource);
        return factory.createBrokerContainer(brokerName, BrokerContext.getInstance());
    }

    /**
     * A helper method, invoked via reflection, to create a new factory from a given configuration
     * file String which if it starts with classpath: is a classpath URI otherwise a URL is assumed.
     *
     * @param resourceName
     * @return
     */
    public static SpringBrokerContainerFactory newFactory(String resourceName) {
        ResourceEditor editor = new ResourceEditor();
        editor.setAsText(resourceName);
        Resource resource = (Resource) editor.getValue();
        if (resource == null) {
            throw new IllegalArgumentException("Could not convert '" + resourceName + "' into a Spring Resource");
        }
        return new SpringBrokerContainerFactory(resource);
    }

    public SpringBrokerContainerFactory() {
    }

    public SpringBrokerContainerFactory(Resource resource) {
        this.resource = resource;
    }

    public BrokerContainer createBrokerContainer(String brokerName, BrokerContext context) {
        log.info("Loading ActiveMQ broker from configuration: " + resource);

        ActiveMQBeanFactory beanFactory = new ActiveMQBeanFactory(brokerName, resource);
        return (BrokerContainer) beanFactory.getBean("broker");
    }

    // Properties
    //-------------------------------------------------------------------------
    public Resource getResource() {
        return resource;
    }

    public void setResource(Resource resource) {
        this.resource = resource;
    }

}
