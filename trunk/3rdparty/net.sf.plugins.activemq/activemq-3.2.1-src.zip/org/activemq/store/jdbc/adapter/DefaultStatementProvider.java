/**
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.jdbc.adapter;

import org.activemq.store.jdbc.StatementProvider;


/**
 * @version $Revision: 1.1 $
 */
public class DefaultStatementProvider implements StatementProvider {

    protected String tablePrefix = "";
    protected String messageTableName = "ACTIVEMQ_MSGS";
    protected String txTableName = "ACTIVEMQ_TXS";
    protected String durableSubAcksTableName = "ACTIVEMQ_ACKS";

    protected String binaryDataType = "BLOB";
    protected String containerNameDataType = "VARCHAR(250)";
    protected String xidDataType = "VARCHAR(250)";
    protected String msgIdDataType = "VARCHAR(250)";
    protected String subscriptionIdDataType = "VARCHAR(250)";
    protected String sequenceDataType = "INTEGER";
    protected String charDataType = "CHAR(1)";
    protected String longDataType = "BIGINT";
    protected String stringIdDataType = "VARCHAR(250)";
    
    public String [] getCreateSchemaStatments() {
        return new String[]{
            "CREATE TABLE "+tablePrefix+messageTableName+"("
            			   +"ID "+sequenceDataType+" NOT NULL"
            			   +", CONTAINER "+containerNameDataType
            			   +", MSGID "+msgIdDataType
            			   +", MSG "+binaryDataType
            			   +", PRIMARY KEY ( ID ) )",						   
            "CREATE INDEX "+tablePrefix+messageTableName+"_MIDX ON "+tablePrefix+messageTableName+" (MSGID)",
            "CREATE INDEX "+tablePrefix+messageTableName+"_CIDX ON "+tablePrefix+messageTableName+" (CONTAINER)",
			
            "CREATE TABLE "+tablePrefix+txTableName+"("
            			   +"XID "+xidDataType+" NOT NULL"
            			   +", PRIMARY KEY ( XID ))",
						   
            "CREATE TABLE "+tablePrefix+durableSubAcksTableName+"("
                           +"SUB "+subscriptionIdDataType+" NOT NULL"
                           +", CONTAINER "+containerNameDataType+" NOT NULL"
                           +", LAST_ACKED_ID "+sequenceDataType
            			   +", SE_ID INTEGER"
            			   +", SE_CLIENT_ID "+stringIdDataType
            			   +", SE_CONSUMER_NAME "+stringIdDataType
            			   +", SE_SELECTOR "+stringIdDataType
            			   +", PRIMARY KEY ( SUB, CONTAINER ))",
            "CREATE INDEX "+tablePrefix+durableSubAcksTableName+"_CIDX ON "+tablePrefix+durableSubAcksTableName+" (CONTAINER)",            
            "ALTER TABLE "+tablePrefix+messageTableName+" ADD EXPIRATION "+longDataType,
            "ALTER TABLE "+tablePrefix+messageTableName+" ADD SENT_TO_DEADLETTER "+charDataType
        };
    }

    public String [] getDropSchemaStatments() {
        return new String[]{
            "DROP TABLE "+tablePrefix+durableSubAcksTableName+"",
            "DROP TABLE "+tablePrefix+messageTableName+"",
            "DROP TABLE "+tablePrefix+txTableName+""
        };
    }

    public String getAddMessageStatment() {
        return "INSERT INTO "+tablePrefix+messageTableName+"(ID, CONTAINER, MSGID, MSG, EXPIRATION) VALUES (?, ?, ?, ?, ?)";
    }
    public String getUpdateMessageStatment() {
        return "UPDATE "+tablePrefix+messageTableName+" SET MSG=? WHERE ID=?";
    }
    public String getRemoveMessageStatment() {
        return "DELETE FROM "+tablePrefix+messageTableName+" WHERE ID=?";
    }
    public String getFindMessageSequenceIdStatment() {
        return "SELECT ID FROM "+tablePrefix+messageTableName+" WHERE MSGID=?";
    }
    public String getFindMessageStatment() {
        return "SELECT MSG FROM "+tablePrefix+messageTableName+" WHERE ID=?";
    }
    public String getFindMessageAttributesStatment() {
        return "SELECT CONTAINER, MSGID, SENT_TO_DEADLETTER FROM "+tablePrefix+messageTableName+" WHERE ID=?";
    }
    public String getFindMessageAttributesForUpdateStatment() {
        return "SELECT CONTAINER, MSGID, SENT_TO_DEADLETTER FROM "+tablePrefix+messageTableName+" WHERE ID=? FOR UPDATE";
    }
    public String getFindAllMessagesStatment() {
        return "SELECT ID, MSGID FROM "+tablePrefix+messageTableName+" WHERE CONTAINER=? ORDER BY ID";
    }
    public String getFindLastSequenceIdInMsgs() {
        return "SELECT MAX(ID) FROM "+tablePrefix+messageTableName;
    }
    public String getFindLastSequenceIdInAcks() {
        return "SELECT MAX(LAST_ACKED_ID) FROM "+tablePrefix+durableSubAcksTableName;
    }

    public String getAddXidStatment() {
        return "INSERT INTO "+tablePrefix+txTableName+"(XID) VALUES (?)";
    }
    public String getRemoveXidStatment() {
        return "DELETE FROM "+tablePrefix+txTableName+" WHERE XID=?";
    }
    public String getFindAllXidStatment() {
        return "SELECT XID FROM "+tablePrefix+txTableName+"";
    }

    public String getCreateDurableSubStatment() {
        return "INSERT INTO "+tablePrefix+durableSubAcksTableName
        	   +"(SE_ID, SE_CLIENT_ID, SE_CONSUMER_NAME, SE_SELECTOR, SUB, CONTAINER, LAST_ACKED_ID) "
         	   +"VALUES (?, ?, ?, ?, ?, ?, ?)";
    }

    public String getUpdateDurableSubStatment() {
        return "UPDATE "+tablePrefix+durableSubAcksTableName
               +" SET SE_ID=?, SE_CLIENT_ID=?, SE_CONSUMER_NAME=?, SE_SELECTOR=? WHERE SUB=? AND CONTAINER=?";			
    }

    public String getFindDurableSubStatment() {
        return "SELECT SE_ID, SE_CLIENT_ID, SE_CONSUMER_NAME, SE_SELECTOR, CONTAINER=? "+tablePrefix+durableSubAcksTableName
				+" WHERE SUB=? AND CONTAINER=?";
    }

    public String getUpdateLastAckOfDurableSub() {
        return "UPDATE "+tablePrefix+durableSubAcksTableName
				+" SET LAST_ACKED_ID=? WHERE SUB=? AND CONTAINER=?";
    }

    public String getDeleteSubscriptionStatment() {
        return "DELETE FROM "+tablePrefix+durableSubAcksTableName
        +" WHERE SUB=? AND CONTAINER=?";
    }

    public String getFindAllDurableSubMessagesStatment() {
        return "SELECT M.ID, M.MSGID FROM "
		        +tablePrefix+messageTableName+" M, "
			    +tablePrefix+durableSubAcksTableName +" D "
		        +" WHERE D.CONTAINER=? AND D.SUB=? " 
				+" AND M.CONTAINER=D.CONTAINER AND M.ID > D.LAST_ACKED_ID"
				+" ORDER BY M.ID";
    }
    

    public String getRemoveAllMessagesStatment() {
        return "DELETE FROM "+tablePrefix+messageTableName+" WHERE CONTAINER=?";
    }

    public String getRemoveAllSubscriptionsStatment() {
        return "DELETE FROM "+tablePrefix+durableSubAcksTableName+" WHERE CONTAINER=?";
    }

    public String getDeleteOldMessagesStatment() {
        return "DELETE FROM "+tablePrefix+messageTableName+
            " WHERE ID <= ( SELECT MIN("+tablePrefix+durableSubAcksTableName+".LAST_ACKED_ID) " +
                "FROM "+tablePrefix+durableSubAcksTableName+" WHERE " +
                tablePrefix+durableSubAcksTableName+".CONTAINER="+tablePrefix+messageTableName+
                ".CONTAINER)";
    }
    
    public String getFindExpiredMessagesStatment() {
        return "SELECT ID, CONTAINER, MSGID, SENT_TO_DEADLETTER FROM "+tablePrefix+messageTableName+
            " WHERE ( EXPIRATION<>0 AND EXPIRATION<?)";
    }
    
    public String getSetDeadLetterFlagStatement() {
    	return "UPDATE "+tablePrefix+messageTableName
					+" SET SENT_TO_DEADLETTER='Y' WHERE ID=?";
    }

    public String getDeleteMessageStatement() {
    	return "DELETE FROM "+tablePrefix+messageTableName
				+" WHERE ID=? AND MSGID=?";
    }
    
    /**
     * @return Returns the containerNameDataType.
     */
    public String getContainerNameDataType() {
        return containerNameDataType;
    }
    /**
     * @param containerNameDataType The containerNameDataType to set.
     */
    public void setContainerNameDataType(String containerNameDataType) {
        this.containerNameDataType = containerNameDataType;
    }
    /**
     * @return Returns the messageDataType.
     */
    public String getBinaryDataType() {
        return binaryDataType;
    }
    /**
     * @param messageDataType The messageDataType to set.
     */
    public void setBinaryDataType(String messageDataType) {
        this.binaryDataType = messageDataType;
    }
    /**
     * @return Returns the messageTableName.
     */
    public String getMessageTableName() {
        return messageTableName;
    }
    /**
     * @param messageTableName The messageTableName to set.
     */
    public void setMessageTableName(String messageTableName) {
        this.messageTableName = messageTableName;
    }
    /**
     * @return Returns the msgIdDataType.
     */
    public String getMsgIdDataType() {
        return msgIdDataType;
    }
    /**
     * @param msgIdDataType The msgIdDataType to set.
     */
    public void setMsgIdDataType(String msgIdDataType) {
        this.msgIdDataType = msgIdDataType;
    }
    /**
     * @return Returns the sequenceDataType.
     */
    public String getSequenceDataType() {
        return sequenceDataType;
    }
    /**
     * @param sequenceDataType The sequenceDataType to set.
     */
    public void setSequenceDataType(String sequenceDataType) {
        this.sequenceDataType = sequenceDataType;
    }
    /**
     * @return Returns the tablePrefix.
     */
    public String getTablePrefix() {
        return tablePrefix;
    }
    /**
     * @param tablePrefix The tablePrefix to set.
     */
    public void setTablePrefix(String tablePrefix) {
        this.tablePrefix = tablePrefix;
    }
    /**
     * @return Returns the txTableName.
     */
    public String getTxTableName() {
        return txTableName;
    }
    /**
     * @param txTableName The txTableName to set.
     */
    public void setTxTableName(String txTableName) {
        this.txTableName = txTableName;
    }
    /**
     * @return Returns the xidDataType.
     */
    public String getXidDataType() {
        return xidDataType;
    }
    /**
     * @param xidDataType The xidDataType to set.
     */
    public void setXidDataType(String xidDataType) {
        this.xidDataType = xidDataType;
    }
    /**
     * @return Returns the durableSubAcksTableName.
     */
    public String getDurableSubAcksTableName() {
        return durableSubAcksTableName;
    }
    /**
     * @param durableSubAcksTableName The durableSubAcksTableName to set.
     */
    public void setDurableSubAcksTableName(String durableSubAcksTableName) {
        this.durableSubAcksTableName = durableSubAcksTableName;
    }
    /**
     * @return Returns the subscriptionIdDataType.
     */
    public String getSubscriptionIdDataType() {
        return subscriptionIdDataType;
    }
    /**
     * @param subscriptionIdDataType The subscriptionIdDataType to set.
     */
    public void setSubscriptionIdDataType(String subscriptionIdDataType) {
        this.subscriptionIdDataType = subscriptionIdDataType;
    }

    public String getLongDataType() {
        return longDataType;
    }
    
    public void setLongDataType(String longDataType) {
        this.longDataType = longDataType;
    }
    
    public String getStringIdDataType() {
        return stringIdDataType;
    }
    
    public void setStringIdDataType(String stringIdDataType) {
        this.stringIdDataType = stringIdDataType;
    }
    
}