/*
 * Copyright (c) 2005 Your Corporation. All Rights Reserved.
 */
package org.activemq.transport.stomp;

import org.activemq.message.TransactionInfo;
import org.activemq.message.TransactionType;

import java.io.DataInput;
import java.io.IOException;
import java.util.Properties;
import java.net.ProtocolException;

public class Begin implements Command
{
    private StompWireFormat format;
    private static final HeaderParser parser = new HeaderParser();

    public Begin(StompWireFormat format)
    {
        this.format = format;
    }

    public PacketEnvelope build(String commandLine, DataInput in) throws IOException
    {
        Properties headers = parser.parse(in);
        while (in.readByte() != 0) {}

        TransactionInfo tx = new TransactionInfo();
        String user_tx_id = headers.getProperty(Stomp.Headers.TRANSACTION);
        if (!headers.containsKey(Stomp.Headers.TRANSACTION))
        {
            throw new ProtocolException("Must specify the transaction you are beginning");
        }
        String tx_id = StompWireFormat.clientIds.generateId();
        format.registerTransactionId(user_tx_id, tx_id);
        tx.setTransactionId(tx_id);
        tx.setType(TransactionType.START);
        return new PacketEnvelope(tx, headers);
    }
}
