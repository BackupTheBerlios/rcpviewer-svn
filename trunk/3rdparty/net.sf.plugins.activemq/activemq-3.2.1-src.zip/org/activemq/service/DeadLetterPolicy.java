/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.service;
import javax.jms.JMSException;
import javax.jms.DeliveryMode;
import org.apache.commons.logging.*;
import org.activemq.broker.BrokerContainer;
import org.activemq.broker.Broker;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ActiveMQQueue;
import org.activemq.store.PersistenceAdapter;
import org.activemq.util.IdGenerator;

/**
 * Determines how messages are stored in a dead letter queue
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class DeadLetterPolicy {
    /**
     * Prefix used by dead letter queues
     */
    public static final String DEAD_LETTER_PREFIX = "org.activemq.deadletter.";
    private static final String DEFAULT_DEAD_LETTER_NAME = "DLQ";    
    private static final Log log = LogFactory.getLog(DeadLetterPolicy.class);
    private Broker broker;
    private String deadLetterPrefix = DEAD_LETTER_PREFIX;
    private String deadLetterName = DEFAULT_DEAD_LETTER_NAME;
    private boolean deadLetterEnabled = true;
    private boolean deadLetterPerDestinationName = true;
    private boolean storeNonPersistentMessages = true;
    private boolean noTopicConsumerEnabled = true;
    private boolean allowDuplicates = false;
    private boolean useDatabaseLocking = false;
    private long deadLetterQueueTTL = 0L;
    private long deadLetterTopicTTL = 0L;
    private IdGenerator idGenerator = new IdGenerator();
   
    /**
     * Construct a dead letter policy
     * 
     * @param broker
     */
    public DeadLetterPolicy(Broker broker) {
        this.broker = broker;
    }
    
    public DeadLetterPolicy(BrokerContainer brokerContainer) {
    	this(brokerContainer.getBroker());
    }

    /**
     * Default constructor
     */
    public DeadLetterPolicy() {
    }

    /**
     * @return Returns the broker.
     */
    public Broker getBroker() {
        return broker;
    }

    /**
     * @param broker The broker to set.
     */
    public void setBroker(Broker broker) {
        this.broker = broker;
    }

    /**
     * @return Returns the deadLetterEnabled.
     */
    public boolean isDeadLetterEnabled() {
        return deadLetterEnabled;
    }

    /**
     * @param deadLetterEnabled The deadLetterEnabled to set.
     */
    public void setDeadLetterEnabled(boolean deadLetterEnabled) {
        this.deadLetterEnabled = deadLetterEnabled;
    }

    /**
     * @return Returns the deadLetterPerDestinationName.
     */
    public boolean isDeadLetterPerDestinationName() {
        return deadLetterPerDestinationName;
    }

    /**
     * @param deadLetterPerDestinationName The deadLetterPerDestinationName to set.
     */
    public void setDeadLetterPerDestinationName(boolean deadLetterPerDestinationName) {
        this.deadLetterPerDestinationName = deadLetterPerDestinationName;
    }

    /**
     * @return Returns the deadLetterName.
     */
    public String getDeadLetterName() {
        return deadLetterName;
    }

    /**
     * @param deadLetterName The deadLetterName to set.
     */
    public void setDeadLetterName(String deadLetterName) {
        this.deadLetterName = deadLetterName;
    }

    /**
     * @return Returns the deadLetterPrefix.
     */
    public String getDeadLetterPrefix() {
        return deadLetterPrefix;
    }

    /**
     * @param deadLetterPrefix The deadLetterPrefix to set.
     */
    public void setDeadLetterPrefix(String deadLetterPrefix) {
        this.deadLetterPrefix = deadLetterPrefix;
    }

    /**
     * @return Returns the storeNonPersistentMessages.
     */
    public boolean isStoreNonPersistentMessages() {
        return storeNonPersistentMessages;
    }

    /**
     * @param storeNonPersistentMessages The storeNonPersistentMessages to set.
     */
    public void setStoreNonPersistentMessages(boolean storeNonPersistentMessages) {
        this.storeNonPersistentMessages = storeNonPersistentMessages;
    }
    
    /**
     * @return Returns the noTopicConsumerEnabled.
     */
    public boolean isNoTopicConsumerEnabled() {
        return noTopicConsumerEnabled;
    }
    /**
     * @param noTopicConsumerEnabled The noTopicConsumerEnabled to set.
     */
    public void setNoTopicConsumerEnabled(boolean noTopicConsumerEnabled) {
        this.noTopicConsumerEnabled = noTopicConsumerEnabled;
    }
    
    /**
	 * @return Returns the allowDuplicates.
	 */
	public boolean isAllowDuplicates() {
		return allowDuplicates;
	}
	/**
	 * @param allowDuplicates The allowDuplicates to set.
	 */
	public void setAllowDuplicates(boolean allowDuplicates) {
		this.allowDuplicates = allowDuplicates;
	}
	/**
	 * @return Returns the useDatabaseLocking.
	 */
	public boolean isUseDatabaseLocking() {
		return useDatabaseLocking;
	}	
	/**
	 * @param useDatabaseLocking The useDatabaseLocking to set.
	 */
	public void setUseDatabaseLocking(boolean useDatabaseLocking) {
		this.useDatabaseLocking = useDatabaseLocking;
	}
	/**
	 * @param deadLetterQueueTTL The deadLetterQueueTTL to set.
	 */
	public void setDeadLetterQueueTTL(long deadLetterQueueTTL) {
		this.deadLetterQueueTTL = deadLetterQueueTTL;
	}
	/**
	 * @param deadLetterTopicTTL The deadLetterTopicTTL to set.
	 */
	public void setDeadLetterTopicTTL(long deadLetterTopicTTL) {
		this.deadLetterTopicTTL = deadLetterTopicTTL;
	}
	/**
     * Get the name of the DLQ from the destination provided
     * @param destination
     * @return the name of the DLQ for this Destination
     */
    public String getDeadLetterNameFromDestination(ActiveMQDestination destination){
        String deadLetterName = deadLetterPrefix;
        if (deadLetterPerDestinationName) {
            deadLetterName += destination.getPhysicalName();
        }
        else {
            deadLetterName += this.deadLetterName;
        }
        return deadLetterName;
    }

    /**
     * Send a message to a dead letter queue
     * 
     * @param message
     * @throws JMSException
     */
    public void sendToDeadLetter(ActiveMQMessage message) {
        if (deadLetterEnabled && message != null && (message.isPersistent() || storeNonPersistentMessages) && !message.isDispatchedFromDLQ()) {
            if (broker != null) {
            	// process duplicates
            	if (!isAllowDuplicates()) {
	                PersistenceAdapter persistenceAdapter = getBroker().getPersistenceAdapter();
	                // make sure no previous dead letter was already sent
	                if (persistenceAdapter!=null
	                		&& message.getJMSMessageIdentity()!=null
							&& message.getJMSMessageIdentity().getSequenceNumber()!=null
							&& persistenceAdapter.deadLetterAlreadySent(((Long)message.getJMSMessageIdentity().getSequenceNumber()).longValue(), isUseDatabaseLocking())) {
	                	if (log.isDebugEnabled()) log.debug("Dead letter has been already sent for this message: " + message.getJMSMessageID());
	                	return;
	                }
            	}

                // send a dead letter message
                String dlqName = getDeadLetterNameFromDestination(message.getJMSActiveMQDestination());
                try {
	            	ActiveMQMessage deadMessage = createDeadLetterMessage(dlqName, message);
	                broker.sendToDeadLetterQueue(dlqName, deadMessage);
	                if (log.isDebugEnabled()) log.debug("Passed message: " + deadMessage + " to DLQ: " + dlqName);
                } catch (JMSException e) {
                	log.warn("Failed to send message to dead letter due to: " + e, e);
                }
            }
            else {
                log.warn("Broker is not initialized - cannot add to DLQ: " + message);
            }
        }else if (log.isDebugEnabled()){
            log.debug("DLQ not storing message: " + message);
        }
    }
    
    protected ActiveMQMessage createDeadLetterMessage(String dlqName, ActiveMQMessage message) throws JMSException {
    	// make a shallow copy of the orginal message
    	ActiveMQMessage deadMessage = message.shallowCopy();
    	
        // generate a new producer and message ID
        String id = idGenerator.generateId();
        String producerKey = IdGenerator.getSeedFromId(id);
        long seq = IdGenerator.getCountFromId(id);
        deadMessage.setProducerKey(producerKey);
        deadMessage.setJMSMessageID(id);
        deadMessage.setSequenceNumber(seq);
        deadMessage.getJMSMessageIdentity().setMessageID(id);
        deadMessage.getJMSMessageIdentity().setSequenceNumber(new Long(seq));

        ActiveMQQueue destination = new ActiveMQQueue(dlqName);
        deadMessage.setJMSDestination(destination);
        deadMessage.setDispatchedFromDLQ(true);
        
        // set the expiration of the dead letter message
        long expiration = 0L;
        long timeStamp = System.currentTimeMillis();
        if (message.getJMSActiveMQDestination().isTopic()) {
        	if (deadLetterTopicTTL > 0) {
        		expiration = deadLetterTopicTTL + timeStamp;
        	}
        } else {
        	if (deadLetterQueueTTL > 0) {
        		expiration = deadLetterQueueTTL + timeStamp;
        	}
        }
        deadMessage.setJMSExpiration(expiration);
        deadMessage.setJMSDeliveryMode(DeliveryMode.PERSISTENT);
        
        return deadMessage;
    }
}