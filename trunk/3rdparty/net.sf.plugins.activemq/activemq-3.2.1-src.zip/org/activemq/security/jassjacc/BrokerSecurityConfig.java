/*
 * Created on Nov 7, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.activemq.security.jassjacc;

import java.util.HashSet;

/**
 * @author Hiram
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class BrokerSecurityConfig {
	
	String brokerName;
	HashSet connectRoles = new HashSet();
	
	/**
	 * @return Returns the brokerName.
	 */
	public String getBrokerName() {
		return brokerName;
	}
	/**
	 * @param brokerName The brokerName to set.
	 */
	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}
	/**
	 * @return Returns the connectRoles.
	 */
	public HashSet getConnectRoles() {
		return connectRoles;
	}
	/**
	 * @param connectRoles The connectRoles to set.
	 */
	public void setConnectRoles(HashSet connectRoles) {
		this.connectRoles = connectRoles;
	}
}
