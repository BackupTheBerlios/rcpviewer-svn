/*
 * Copyright (c) 2005 Your Corporation. All Rights Reserved.
 */
package org.activemq.transport.stomp;

import org.activemq.message.TransactionInfo;
import org.activemq.message.TransactionType;

import java.io.DataInput;
import java.io.IOException;
import java.util.Properties;
import java.net.ProtocolException;

class Abort implements Command
{
    private StompWireFormat format;
    private static final HeaderParser parser = new HeaderParser();

    Abort(StompWireFormat format)
    {
        this.format = format;
    }

    public PacketEnvelope build(String commandLine, DataInput in) throws IOException
    {
        Properties headers = parser.parse(in);
        while (in.readByte() != 0) {}
        String user_tx_id = headers.getProperty(Stomp.Headers.TRANSACTION);

        if (!headers.containsKey(Stomp.Headers.TRANSACTION))
        {
            throw new ProtocolException("Must specify the transaction you are aborting");
        }

        String tx_id = format.getTransactionId(user_tx_id);
        TransactionInfo tx = new TransactionInfo();
        tx.setTransactionId(tx_id);
        tx.setType(TransactionType.ROLLBACK);
        format.clearTransactionId(user_tx_id);
        return new PacketEnvelope(tx, headers);
    }
}
