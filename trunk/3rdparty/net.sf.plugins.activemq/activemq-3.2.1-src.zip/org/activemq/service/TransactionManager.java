/** 
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service;

import org.activemq.broker.BrokerClient;
import org.activemq.message.ActiveMQXid;
import org.activemq.service.impl.AutoCommitTransaction;

import javax.jms.JMSException;
import javax.transaction.xa.XAException;

/**
 * A Transaction keeps track of all the tasks
 * that must be run before and after transactional events.
 *
 * @version $Revision: 1.1.1.1 $
 */
public abstract class TransactionManager implements Service {

    // Keeps track of the current transaction
    static private final ThreadLocal contextTx = new ThreadLocal();
  
    static public void setContexTransaction(Transaction tx) {
        contextTx.set(tx);
    }

    static public Transaction getContexTransaction() {
        Transaction tx = (Transaction) contextTx.get();
        if( tx == null ) {
            return AutoCommitTransaction.AUTO_COMMIT_TRANSACTION;
        }
        return tx;
    }
   
    /**
     * @return true if there is a current transaction
     */
    static public boolean isCurrentTransaction(){
        return contextTx.get() != null;
    }
    

    abstract public Transaction createLocalTransaction(BrokerClient client, String txid) throws JMSException;

    abstract public Transaction getLocalTransaction(String txid) throws JMSException;

    abstract public Transaction createXATransaction(BrokerClient client, ActiveMQXid xid) throws XAException;

    abstract public Transaction getXATransaction(ActiveMQXid xid) throws XAException;

    abstract public ActiveMQXid[] getPreparedXATransactions() throws XAException;

    /**
     * A hint to the TransactionManager that an BrokerClient has stopped
     * This enables the TransactionManager to rollback in progess transactions
     * that the client created.
     *
     * @param client
     */
    abstract public void cleanUpClient(BrokerClient client) throws JMSException;

   /**
    * Called on restart when recovering prepared transactions to reload
    * a transaction from persistent store
    */
    abstract  public void recover(Transaction transaction);

}