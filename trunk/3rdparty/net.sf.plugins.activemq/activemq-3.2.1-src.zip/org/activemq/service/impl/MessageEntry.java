/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service.impl;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import javax.jms.JMSException;
import org.activemq.io.WireFormat;
import org.activemq.io.impl.DefaultWireFormat;
import org.activemq.message.ActiveMQMessage;
import org.activemq.util.JMSExceptionHelper;


/**
 * An entry for a message in a container
 *
 * @version $Revision: 1.1.1.1 $
 */
public class MessageEntry implements Externalizable {
    private static final long serialVersionUID = -3590625465815936811L;
    private static final WireFormat wireFormat = new DefaultWireFormat();


    private ActiveMQMessage message;

    /**
     * Only used by serialisation
     */
    public MessageEntry() {
    }

    public MessageEntry(ActiveMQMessage msg) {
        this.message = msg;
    }


    /**
     * @return Returns the message.
     */
    public ActiveMQMessage getMessage() {
        return message;
    }

    /**
     * @return a hashCode for this object
     */
    public int hashCode() {
        return message != null ? message.hashCode() : super.hashCode();
    }

    /**
     * Tests equivalence with an other object
     *
     * @param obj the object to test against
     * @return true/false
     */

    public boolean equals(Object obj) {
        boolean result = false;
        if (obj != null && obj instanceof MessageEntry) {
            MessageEntry other = (MessageEntry) obj;
            result = (this.message != null && other.message != null && this.message.equals(other.message) ||
                    this.message == null && other.message == null);
        }
        return result;
    }

    public void writeExternal(ObjectOutput out) throws IOException {
        try {
            wireFormat.writePacket(message, out);
        }
        catch (JMSException e) {
            throw JMSExceptionHelper.newIOException(e);
        }
    }

    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        message = (ActiveMQMessage) wireFormat.readPacket(in);
    }
}
