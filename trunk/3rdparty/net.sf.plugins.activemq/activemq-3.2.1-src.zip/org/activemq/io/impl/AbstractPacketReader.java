/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.io.impl;
import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.IOException;
import org.activemq.message.AbstractPacket;
import org.activemq.message.Packet;
import org.activemq.util.BitArray;
import org.activemq.util.SerializationHelper;

import javax.jms.JMSException;

/**
 * Allows instances implementing Packet interface to be deserailized
 * 
 * @version $Revision: 1.1.1.1 $
 */
public abstract class AbstractPacketReader implements PacketReader {
    protected int wireFormatVersion = DefaultWireFormat.WIRE_FORMAT_VERSION;
  

    /**
     * @param packetType
     * @return true if this PacketReader can a Packet of this type
     */
    public boolean canRead(int packetType) {
        return this.getPacketType() == packetType;
    }

    /**
     * pointless method - but mirrors writer
     * 
     * @param dataIn
     * @return the String
     * @throws IOException
     */
    protected String readUTF(DataInput dataIn) throws IOException {
        return dataIn.readUTF();
    }

    /**
     * ;
     * 
     * @param dataIn
     * @return object
     * @throws IOException
     */
    protected Object readObject(DataInput dataIn) throws IOException {
        int dataLength = dataIn.readInt();
        if (dataLength > 0) {
            byte[] data = new byte[dataLength];
            dataIn.readFully(data);
            
            try {
                return SerializationHelper.readObject(data);
            }
            catch (ClassNotFoundException ex) {
                throw (IOException)new IOException("Class Not Found: "+ ex.getMessage()).initCause(ex);
            }
        }
        return null;
    }

    /**
     * build a Packet instance from the data input stream
     * 
     * @param p A Packet object
     * @param dataIn the data input stream to build the packet from
     * @throws IOException
     */
    public void buildPacket(Packet p, DataInput dataIn) throws IOException {
        AbstractPacket packet = (AbstractPacket) p;
        packet.setId(dataIn.readShort());
        BitArray ba = packet.getBitArray();
        ba.readFromStream(dataIn);
        packet.setReceiptRequired(ba.get(AbstractPacket.RECEIPT_REQUIRED_INDEX));
        if (ba.get(AbstractPacket.BROKERS_VISITED_INDEX)) {
            int visitedLen = dataIn.readShort();
            for (int i = 0;i < visitedLen;i++) {
                packet.addBrokerVisited(dataIn.readUTF());
            }
        }
    }

    /**
     * Deserailizes a Packet from a byte array
     * 
     * @param data
     * @return the deserialized Packet
     * @throws IOException
     */
    public Packet readPacketFromByteArray(byte[] data) throws IOException {
        ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
        DataInputStream dataIn = new DataInputStream(bytesIn);
        Packet packet = createPacket();
        buildPacket(packet, dataIn);
        return packet;
    }

    /**
     * Set the wire format version
     * 
     * @param version
     */
    public void setWireFormatVersion(int version) {
        this.wireFormatVersion = version;
    }

    /**
     * @return the wire format version
     */
    public int getWireFormatVersion() {
        return wireFormatVersion;
    }
}