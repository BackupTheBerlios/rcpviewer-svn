/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.transport.tcp;

import EDU.oswego.cs.dl.util.concurrent.Executor;
import org.activemq.io.WireFormat;
import org.activemq.transport.TransportChannel;

import javax.jms.JMSException;
import javax.net.SocketFactory;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URI;

/**
 * A factory of TcpTransportChannelFactory instances using a SocketFactory
 *
 * @version $Revision: 1.1.1.1 $
 */
public class SfTransportChannelFactory extends TcpTransportChannelFactory {

    private SocketFactory socketFactory;
    private Executor executor;

    public SfTransportChannelFactory(SocketFactory socketFactory) {
        this.socketFactory = socketFactory;
    }

    /**
     * Create a Channel to a remote Node - e.g. a Broker
     *
     * @param wireFormat
     * @param remoteLocation
     * @return the TransportChannel bound to the remote node
     * @throws JMSException
     */
    public TransportChannel create(WireFormat wireFormat, URI remoteLocation) throws JMSException {
        Socket socket = null;
        try {
            socket = createSocket(remoteLocation);
        }
        catch (IOException e) {
            JMSException jmsEx = new JMSException("Creation of Socket failed: " + e);
            jmsEx.setLinkedException(e);
            throw jmsEx;
        }
        return populateProperties(new TcpTransportChannel(wireFormat, socket, executor), remoteLocation);

    }

    /**
     * Create a Channel to a remote Node - e.g. a Broker
     *
     * @param wireFormat
     * @param remoteLocation
     * @param localLocation  -
     *                       e.g. local InetAddress and local port
     * @return the TransportChannel bound to the remote node
     * @throws JMSException
     */
    public TransportChannel create(WireFormat wireFormat, URI remoteLocation, URI localLocation) throws JMSException {
        Socket socket = null;
        try {
            socket = createSocket(remoteLocation, localLocation);
        }
        catch (IOException e) {
            JMSException jmsEx = new JMSException("Creation of Socket failed: " + e);
            jmsEx.setLinkedException(e);
            throw jmsEx;
        }
        return populateProperties(new TcpTransportChannel(wireFormat, socket, executor), remoteLocation);
    }

    protected Socket createSocket(URI remoteLocation) throws IOException {
        return socketFactory.createSocket(remoteLocation.getHost(), remoteLocation.getPort());
    }

    protected Socket createSocket(URI remoteLocation, URI localLocation) throws IOException {
        return socketFactory.createSocket(remoteLocation.getHost(), remoteLocation.getPort(), InetAddress
                .getByName(localLocation.getHost()), localLocation.getPort());
    }
}