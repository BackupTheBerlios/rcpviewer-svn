/**
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

import javax.jms.JMSException;
import javax.transaction.xa.XAException;

import org.activemq.message.ActiveMQXid;
import org.activemq.service.SubscriberEntry;
import org.activemq.store.TransactionStore.RecoveryListener;
import org.activemq.util.LongSequenceGenerator;
import org.activemq.service.MessageIdentity;

/**
 * @version $Revision: 1.1 $
 */
public interface JDBCAdapter {
    
    public interface MessageListResultHandler {
        public void onMessage(long seq, String messageID) throws JMSException;
    }
    
    public interface ExpiredMessageResultHandler {
        public void onMessage(long seq, String container, String messageID, boolean isSentToDeadLetter) throws JMSException;
    }
    
    public abstract LongSequenceGenerator getSequenceGenerator();
    public abstract void doCreateTables(Connection c) throws SQLException;
    public abstract void doDropTables(Connection c) throws SQLException;
    public abstract void initSequenceGenerator(Connection c);
    public abstract void doAddMessage(Connection c, long seq, String messageID,
            String destinationName, byte[] data, long expiration) throws SQLException,
            JMSException;
    public abstract byte[] doGetMessage(Connection c, long seq)
            throws SQLException;
    public abstract void doGetMessageForUpdate(Connection c, long seq, boolean useLocking, ExpiredMessageResultHandler handler)
    		throws SQLException, JMSException;
    public abstract void doRemoveMessage(Connection c, long seq)
            throws SQLException;
    public abstract void doRecover(Connection c, String destinationName, MessageListResultHandler listener)
            throws SQLException, JMSException;
    public abstract void doRemoveXid(Connection c, ActiveMQXid xid)
            throws SQLException, XAException;
    public abstract void doAddXid(Connection c, ActiveMQXid xid)
            throws SQLException, XAException;
    public abstract void doLoadPreparedTransactions(Connection c,
            RecoveryListener listener) throws SQLException;
    public abstract void doSetLastAck(Connection c, String destinationName, String sub, long seq) 
    		throws SQLException, JMSException;
    public abstract void doRecoverSubscription(Connection c, String destinationName, String sub, MessageListResultHandler listener)
    		throws SQLException, JMSException;
    public abstract void doSetSubscriberEntry(Connection c, String destinationName, String sub, SubscriberEntry subscriberEntry) 
    		throws SQLException, JMSException;
    public abstract SubscriberEntry doGetSubscriberEntry(Connection c, String destinationName, String sub) 
    		throws SQLException, JMSException;
	public abstract Long getMessageSequenceId(Connection c, String messageID)
			throws SQLException, JMSException;
    public abstract void doRemoveAllMessages(Connection c, String destinationName)
    		throws SQLException, JMSException;
    public abstract void doDeleteSubscription(Connection c, String destinationName, String subscription)
        throws SQLException, JMSException;
    public abstract void doDeleteOldMessages(Connection c)
        throws SQLException, JMSException;
    public abstract void doGetExpiredMessages(Connection c, ExpiredMessageResultHandler handler)
		throws SQLException, JMSException;
    public abstract void doDeleteExpiredMessage(Connection c, MessageIdentity messageIdentity)
		throws SQLException, JMSException;
    public void doSetDeadLetterFlag(Connection c, long seq)
		throws SQLException, JMSException;
    
    public StatementProvider getStatementProvider();

}