/**
 *
 * Copyright 2004 Protique Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/

package org.activemq.io.impl;
import java.io.DataInput;
import java.io.IOException;
import org.activemq.message.Packet;
import org.activemq.message.WireFormatInfo;

/**
 * Reads a ConnnectionInfo object from a Stream
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class WireFormatInfoReader extends AbstractPacketReader {
    
    AbstractDefaultWireFormat wireFormat;
    
    WireFormatInfoReader(){
    }
    
    WireFormatInfoReader(AbstractDefaultWireFormat format){
        this.wireFormat = format;
    }
    /**
     * Return the type of Packet
     * 
     * @return integer representation of the type of Packet
     */
    public int getPacketType() {
        return Packet.WIRE_FORMAT_INFO;
    }

    /**
     * @return a new Packet instance
     */
    public Packet createPacket() {
        return new WireFormatInfo();
    }

    /**
     * build a Packet instance from the data input stream
     * 
     * @param packet A Packet object
     * @param dataIn the data input stream to build the packet from
     * @throws IOException
     */
    public void buildPacket(Packet packet, DataInput dataIn) throws IOException {

        // The Magic has to match.
        for( int i=0; i < WireFormatInfo.MAGIC.length; i++ ) {
            if( dataIn.readByte() != WireFormatInfo.MAGIC[i]) {
                throw new IOException("Invalid WireFormatInfo packet.");
            }
        }
        
        super.buildPacket(packet, dataIn);
        WireFormatInfo info = (WireFormatInfo) packet;
        info.setVersion(dataIn.readInt());
        if (wireFormat != null){
            wireFormat.setCurrentWireFormatVersion(info.getVersion());
        }
    }
}