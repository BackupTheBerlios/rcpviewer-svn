/**
 *
 * Copyright 2004 Protique Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/


package org.activemq.io.impl;
import java.io.DataOutput;
import java.io.IOException;

import org.activemq.message.AbstractPacket;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQXid;
import org.activemq.message.MessageAck;
import org.activemq.message.Packet;
import org.activemq.util.BitArray;

/**
 * Writes a ConsumerInfo object to a Stream
 */

public class MessageAckWriter extends AbstractPacketWriter {
    private AbstractDefaultWireFormat wireFormat;
    
    MessageAckWriter(AbstractDefaultWireFormat wf){
        this.wireFormat = wf;
    }
    
    MessageAckWriter(){
    }

    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return Packet.ACTIVEMQ_MSG_ACK;
    }

    /**
     * Write a Packet instance to data output stream
     *
     * @param packet  the instance to be seralized
     * @param dataOut the output stream
     * @throws IOException thrown if an error occurs
     */

    public void writePacket(Packet packet, DataOutput dataOut) throws IOException {
        MessageAck ack = (MessageAck) packet;
        
        boolean cachingEnabled = wireFormat != null ? wireFormat.isCachingEnabled() : false;
        boolean longSequence = ack.getSequenceNumber() > Integer.MAX_VALUE;
        
       
        Object[] visited = ack.getBrokersVisited();
        boolean writeVisited = visited != null && visited.length > 0;
        BitArray ba = ack.getBitArray();
        ba.reset();
        ba.set(AbstractPacket.RECEIPT_REQUIRED_INDEX, ack.isReceiptRequired());
        ba.set(AbstractPacket.BROKERS_VISITED_INDEX,writeVisited);
        ba.set(MessageAck.MESSAGE_READ_INDEX, ack.isMessageRead());
        ba.set(MessageAck.TRANSACTION_ID_INDEX, ack.isPartOfTransaction());
        ba.set(MessageAck.XA_TRANS_INDEX, ack.isXaTransacted());
        ba.set(MessageAck.PERSISTENT_INDEX,ack.isPersistent());
        ba.set(MessageAck.EXPIRED_INDEX,ack.isExpired());
        ba.set(MessageAck.EXTERNAL_MESSAGE_ID_INDEX, ack.isExternalMessageId());
        ba.set(MessageAck.CACHED_VALUES_INDEX,cachingEnabled);
        ba.set(MessageAck.LONG_SEQUENCE_INDEX, longSequence);
        ba.writeToStream(dataOut);
        
        if (ack.isReceiptRequired()){
            dataOut.writeShort(ack.getId());
        }
        if (ack.isExternalMessageId()){
            writeUTF(ack.getMessageID(),dataOut);
        }else {
            if (cachingEnabled){
                dataOut.writeShort(wireFormat.getWriteCachedKey(ack.getProducerKey()));
            }else{
                writeUTF(ack.getProducerKey(),dataOut);
            }
            if (longSequence){
                dataOut.writeLong(ack.getSequenceNumber());
            }else {
                dataOut.writeInt((int)ack.getSequenceNumber());
            }
        }
        if (writeVisited){
            dataOut.writeShort(visited.length);
            for(int i =0; i < visited.length; i++){
                final String brokerName = visited[i].toString();
                if (brokerName != null) {
                    dataOut.writeUTF(brokerName);
                }
            }
        }
         
        if (ack.isPartOfTransaction()) {
            if (cachingEnabled){
                dataOut.writeShort(wireFormat.getWriteCachedKey(ack.getTransactionId()));
            } else {
                if( ack.isXaTransacted()) {
                    ActiveMQXid xid = (ActiveMQXid) ack.getTransactionId();
                    xid.write(dataOut);
                } else {
                    super.writeUTF((String) ack.getTransactionId(), dataOut);
                }            
            }
        }

        if (cachingEnabled){
            dataOut.writeShort(wireFormat.getWriteCachedKey(ack.getConsumerId()));
            dataOut.writeShort(wireFormat.getWriteCachedKey(ack.getDestination()));
        }else {
            super.writeUTF(ack.getConsumerId(), dataOut);
            ActiveMQDestination.writeToStream((ActiveMQDestination) ack.getDestination(), dataOut);
        }
    }


}
