/** 
 * 
 * Copyright 2004 Protique Ltd
 * Copyright 2005 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.service.boundedvm;
import java.util.List;

import javax.jms.JMSException;

import org.activemq.broker.BrokerClient;
import org.activemq.filter.Filter;
import org.activemq.io.util.MemoryBoundedQueue;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ConsumerInfo;

/**
 * A holder for Durable Queue consumer info and message routing
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class DurableQueueSubscription extends DurableSubscription {

    private MemoryBoundedQueue dispatchedQueue;
    private MemoryBoundedQueue ackedQueue; // Where messages go that are acked in a transaction

    /**
     * Construct the DurableQueueSubscription
     * 
     * @param client
     * @param dispatchedQueue
     * @param ackQueue 
     * @param filter
     * @param info
     */
    public DurableQueueSubscription(BrokerClient client, MemoryBoundedQueue dispatchedQueue, MemoryBoundedQueue ackQueue, Filter filter,
            ConsumerInfo info) {
        super(filter, info, client);
        this.dispatchedQueue = dispatchedQueue;
		this.ackedQueue = ackQueue;
    }

    /**
     * determines if the Subscription is interested in the message
     * 
     * @param message
     * @return true if this Subscription will accept the message
     * @throws JMSException
     */
    public boolean isTarget(ActiveMQMessage message) throws JMSException {
        boolean result = false;
        if (message != null) {
            //make sure we don't loop messages around the cluster
            if (!client.isClusteredConnection() || !message.isEntryCluster(clusterName)
                    || message.isEntryBroker(brokerName)) {
                result = filter.matches(message);
            }
        }
        return result;
    }

    /**
     * @return true if the consumer has capacity for more messages
     */
    public boolean canAcceptMessages() {
        return dispatchedQueue.size() <= consumerInfo.getPrefetchNumber();
    }

    /**
     * Dispatch a message to the Consumer
     * 
     * @param message
     * @throws JMSException
     */
    public void doDispatch(DurableMessagePointer message) throws JMSException {
        dispatchedQueue.enqueue(message);
        ActiveMQMessage msg = message.getMessage().shallowCopy();
        msg.setConsumerNos(new int[]{consumerInfo.getConsumerNo()});
        client.dispatch(msg);
    }
	
    
    /**
     * Acknowledge the receipt of a message by a consumer
     * 
     * @param id
     * @return the removed ActiveMQMessage with the associated id
     */
    public DurableMessagePointer acknowledgeMessage(String id) {
        return (DurableMessagePointer) dispatchedQueue.remove(id);
    }

    /**
     * @return all the unacknowledge messages
     */
    public List getUndeliveredMessages() {
        return dispatchedQueue.getContents();
    }

    /**
     * close the subscription
     */
    public void close() {
        super.close();
        dispatchedQueue.close();
        ackedQueue.close();
    }
	
	/**
     * @return true if acked a message
     */
    public boolean hasAckedMessage() {
        return !ackedQueue.isEmpty();
    }

    /**
     * Add an acked message.
     * @param message 
     */
    public void addAckedMessage(DurableMessagePointer message) {
        ackedQueue.enqueueNoBlock(message);
    }

    /**
     * @return a list of all the acked messages
     */
    public List listAckedMessages() {
        return ackedQueue.getContents();
    }

    /**
     * Add an acked message.
     */
    public void removeAllAckedMessages() {
        ackedQueue.clear();
    }

	public boolean isBrowser() {
		return consumerInfo.isBrowser();
	}
}