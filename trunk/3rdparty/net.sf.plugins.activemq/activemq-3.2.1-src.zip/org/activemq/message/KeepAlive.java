/*
 * KeepAlive.java
 */
package org.activemq.message;


/**
 * Keep-alive packet which holds not information and is only intended to keep connections
 * from being idle.
 *
 */
public class KeepAlive extends AbstractPacket {

	public KeepAlive() {
		setReceiptRequired(true);
	}
	
    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return KEEP_ALIVE;
    }

    /**
     * @return pretty print
     */
    public String toString() {
        return super.toString() + " KeepAlive{}";
    }
    
    
}
