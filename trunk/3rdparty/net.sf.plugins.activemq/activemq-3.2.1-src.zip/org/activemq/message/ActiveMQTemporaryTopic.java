/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

import javax.jms.TemporaryTopic;

/**
 * A <CODE>TemporaryTopic</CODE> object is a unique <CODE>Topic</CODE> object
 * created for the duration of a <CODE>Connection</CODE>. It is a
 * system-defined topic that can be consumed only by the
 * <CODE>Connection</CODE> that created it.
 * <p/>
 * <P>A <CODE>TemporaryTopic</CODE> object can be created either at the
 * <CODE>Session</CODE> or <CODE>TopicSession</CODE> level. Creating it at the
 * <CODE>Session</CODE> level allows the <CODE>TemporaryTopic</CODE> to participate
 * in the same transaction with objects from the PTP domain.
 * If a <CODE>TemporaryTopic</CODE> is  created at the
 * <CODE>TopicSession</CODE>, it will only
 * be able participate in transactions with objects from the Pub/Sub domain.
 *
 * @see javax.jms.Session#createTemporaryTopic()
 * @see javax.jms.TopicSession#createTemporaryTopic()
 */

public class ActiveMQTemporaryTopic extends ActiveMQTopic implements TemporaryTopic {

    private static final long serialVersionUID = 8331978134488919460L;

    /**
     * Default constructor for an ActiveMQTemporaryTopic Destination
     */
    public ActiveMQTemporaryTopic() {
        super();
    }

    /**
     * Construct a named ActiveMQTemporaryTopic Destination
     *
     * @param name
     */

    public ActiveMQTemporaryTopic(String name) {
        super(name);
    }

    /**
     * @return Returns the Destination type
     */
    public int getDestinationType() {
        return ACTIVEMQ_TEMPORARY_TOPIC;
    }    
    
    /**
     * Returns true if a temporary Destination
     *
     * @return true/false
     */

    public boolean isTemporary() {
        return true;
    }

}
