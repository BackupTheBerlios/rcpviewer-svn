/**
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.vm;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jms.JMSException;

import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQQueue;
import org.activemq.store.MessageStore;
import org.activemq.store.PersistenceAdapter;
import org.activemq.store.TopicMessageStore;
import org.activemq.store.TransactionStore;

import EDU.oswego.cs.dl.util.concurrent.ConcurrentHashMap;

/**
 * @version $Revision: 1.1.1.1 $
 */
public class VMPersistenceAdapter implements PersistenceAdapter {

    VMTransactionStore transactionStore = null;
    ConcurrentHashMap destinations = new ConcurrentHashMap();
    
    public Map getInitialDestinations() {
        HashMap rc = new HashMap(destinations.size());
        for (Iterator iter = destinations.keySet().iterator(); iter.hasNext();) {
            ActiveMQDestination dest = (ActiveMQDestination) iter.next();
            rc.put(dest.getPhysicalName(), dest);
        }
        return rc;
    }

    public static VMPersistenceAdapter newInstance(File file) {
        return new VMPersistenceAdapter();
    }

    public MessageStore createQueueMessageStore(String destinationName) throws JMSException {
        ActiveMQQueue dest = new ActiveMQQueue(destinationName);
        MessageStore rc = (MessageStore)destinations.get(dest);
        if(rc==null) {
            rc = new VMMessageStore();
            if( transactionStore !=null ) {
                rc = transactionStore.proxy(rc);
            }
            destinations.put(dest, rc);
        }
        return rc;
    }

    public TopicMessageStore createTopicMessageStore(String destinationName) throws JMSException {
        ActiveMQQueue dest = new ActiveMQQueue(destinationName);
        TopicMessageStore rc = (TopicMessageStore)destinations.get(dest);
        if(rc==null) {
            rc = new VMTopicMessageStore();
            if( transactionStore !=null ) {
                rc = transactionStore.proxy(rc);
            }
            destinations.put(dest, rc);
        }
        return rc;
    }

    public TransactionStore createTransactionStore() throws JMSException {
        if( transactionStore==null ) {
            transactionStore = new VMTransactionStore();
        }
        return transactionStore;
    }

    public void beginTransaction() {
    }

    public void commitTransaction() {
    }

    public void rollbackTransaction() {
    }

    public void start() throws JMSException {
    }

    public void stop() throws JMSException {
    }

    /**
     * Verifies if a dead letter has already been sent for a message  
     * @param seq
     * @param useLocking to prevent concurrency/dups
     * @return
     */
    public boolean deadLetterAlreadySent(long seq, boolean useLocking) {
    	return false;
    }
}
