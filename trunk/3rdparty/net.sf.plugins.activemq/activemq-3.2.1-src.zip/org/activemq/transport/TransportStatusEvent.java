/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.transport;
import java.net.URI;

/**
 * A TransportStatusEvent is raised when the state of the underlying transport channel changes
 * 
 * @version $Revision: 1.2 $
 */
public class TransportStatusEvent {
    /**
     * The channel has been intially and successfully connected
     */
    public static final int CONNECTED = 1;
    /**
     * The channel has been disconnected, but maybe reconnected
     */
    public static final int DISCONNECTED = 2;
    /**
     * The channel has successfully reconnected after a disconnect
     */
    public static final int RECONNECTED = 3;
    /**
     * The channel has failed
     */
    public static final int FAILED = 4;
    
    /**
     * The channel has been STOPPED
     */
    public static final int STOPPED = 5;
    
    private URI remoteURI;
    private int channelStatus;
    private TransportChannel transportChannel;

    /**
     * Default Constructor
     */
    public TransportStatusEvent() {
    }
    
    /**
     * Constructs an event with the given channel status.
     * @param tc
     * @param channelStatus the channel status
     */
    public TransportStatusEvent(TransportChannel tc, int channelStatus) {
        this.transportChannel = tc;
        this.channelStatus = channelStatus;
    }

    /**
     * @return a pretty print of this
     */
    public String toString() {
        StringBuffer rc = new StringBuffer();
        rc.append("Channel: ");
        if( transportChannel !=null )
            rc.append(transportChannel);
        else if( remoteURI!=null )
            rc.append(remoteURI);
        rc.append(" has ");
        rc.append(getStatusAsString(channelStatus));        
        return rc.toString(); 
    }

    private String getStatusAsString(int status) {
        String result = null;
        switch (status) {
            case CONNECTED :
                result = "connected";
                break;
            case DISCONNECTED :
                result = "disconnected";
                break;
            case RECONNECTED :
                result = "reconnected";
                break;
            case FAILED :
                result = "failed";
                break;
            case STOPPED:
                result = "stopped";
                break;
            default :
                result = "unknown";
        }
        return result;
    }

    /**
     * @return Returns the channelStatus.
     */
    public int getChannelStatus() {
        return channelStatus;
    }

    /**
     * @param channelStatus The channelStatus to set.
     */
    public void setChannelStatus(int channelStatus) {
        this.channelStatus = channelStatus;
    }
    
    /**
     * @return Returns the transportChannel.
     */
    public TransportChannel getTransportChannel() {
        return transportChannel;
    }
    /**
     * @param transportChannel The transportChannel to set.
     */
    public void setTransportChannel(TransportChannel transportChannel) {
        this.transportChannel = transportChannel;
    }

    /**
     * @return Returns the remoteURI.
     */
    public URI getRemoteURI() {
        return remoteURI;
    }

    /**
     * @param remoteURI The remoteURI to set.
     */
    public void setRemoteURI(URI remoteURI) {
        this.remoteURI = remoteURI;
    }
}