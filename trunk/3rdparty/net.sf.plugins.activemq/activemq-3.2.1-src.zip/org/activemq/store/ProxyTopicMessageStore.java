/*
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 */
package org.activemq.store;

import javax.jms.JMSException;

import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ConsumerInfo;
import org.activemq.message.MessageAck;
import org.activemq.service.MessageIdentity;
import org.activemq.service.SubscriberEntry;

/**
 * A simple proxy that delegates to another MessageStore.
 */
public class ProxyTopicMessageStore implements TopicMessageStore {

    final TopicMessageStore delegate;
    
    public ProxyTopicMessageStore(TopicMessageStore delegate) {
        this.delegate = delegate;
    }
    
    public MessageStore getDelegate() {
        return delegate;
    }
    
    public void addMessage(ActiveMQMessage message) throws JMSException {
        delegate.addMessage(message);
    }
    public ActiveMQMessage getMessage(MessageIdentity identity) throws JMSException {
        return delegate.getMessage(identity);
    }
    public void recover(RecoveryListener listener) throws JMSException {
        delegate.recover(listener);
    }
    public void removeAllMessages() throws JMSException {
        delegate.removeAllMessages();
    }
    public void removeMessage(MessageAck ack) throws JMSException {
        delegate.removeMessage(ack);
    }
    public void start() throws JMSException {
        delegate.start();
    }
    public void stop() throws JMSException {
        delegate.stop();
    }
    
    public void decrementMessageCountAndMaybeDelete(MessageIdentity msgId)
            throws JMSException {
        delegate.decrementMessageCountAndMaybeDelete(msgId);
    }
    public MessageIdentity getLastestMessageIdentity() throws JMSException {
        return delegate.getLastestMessageIdentity();
    }
    public SubscriberEntry getSubscriberEntry(ConsumerInfo info) throws JMSException {
        return delegate.getSubscriberEntry(info);
    }
    public void incrementMessageCount(MessageIdentity messageId) throws JMSException {
        delegate.incrementMessageCount(messageId);
    }
    public void setLastAcknowledgedMessageIdentity(String subscription, MessageIdentity messageIdentity)
            throws JMSException {
        delegate.setLastAcknowledgedMessageIdentity(subscription, messageIdentity);
    }
    public void setSubscriberEntry(ConsumerInfo info, SubscriberEntry subscriberEntry) throws JMSException {
        delegate.setSubscriberEntry(info, subscriberEntry);
    }
    public void deleteSubscription(String subscription) throws JMSException {
        delegate.deleteSubscription(subscription);
    }

    public void recoverSubscription(String subscriptionId, MessageIdentity lastDispatchedMessage, RecoveryListener listener) throws JMSException {
        delegate.recoverSubscription(subscriptionId, lastDispatchedMessage, listener);
    }
}
