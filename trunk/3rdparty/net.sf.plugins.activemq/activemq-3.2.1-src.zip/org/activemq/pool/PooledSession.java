/**
 * 
 * Copyright 2005 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.pool;

import org.activemq.ActiveMQMessageProducer;
import org.activemq.ActiveMQQueueSender;
import org.activemq.ActiveMQSession;
import org.activemq.ActiveMQTopicPublisher;
import org.activemq.AlreadyClosedException;
import org.activemq.util.JMSExceptionHelper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.pool.ObjectPool;

import javax.jms.*;
import java.io.Serializable;

/**
 * @version $Revision: 1.1 $
 */
public class PooledSession implements TopicSession, QueueSession {
    private static final transient Log log = LogFactory.getLog(PooledSession.class);

    private ActiveMQSession session;
    private ObjectPool sessionPool;
    private ActiveMQMessageProducer messageProducer;
    private ActiveMQQueueSender queueSender;
    private ActiveMQTopicPublisher topicPublisher;
    private boolean transactional = true;

    public PooledSession(ActiveMQSession aSession, ObjectPool sessionPool) {
        this.session = aSession;
        this.sessionPool = sessionPool;
        this.transactional = session.isTransacted();
    }


    public void close() throws JMSException {
        // TODO a cleaner way to reset??

        // lets reset the session
        getSession().setMessageListener(null);

        // maybe do a rollback?
        if (transactional) {
            try {
                getSession().rollback();
            }
            catch (JMSException e) {
                log.warn("Caught exception trying rollback() when putting session back into the pool: " + e, e);

                // lets close the session and not put the session back into the pool
                try {
                    session.close();
                }
                catch (JMSException e1) {
                    log.trace("Ignoring exception as discarding session: " + e1, e1);
                }
                session = null;
                return;
            }
        }

        try {
            sessionPool.returnObject(this);
        }
        catch (Exception e) {
            throw JMSExceptionHelper.newJMSException("Failed to return session to pool: " + e, e);
        }
    }

    public void commit() throws JMSException {
        getSession().commit();
    }

    public BytesMessage createBytesMessage() throws JMSException {
        return getSession().createBytesMessage();
    }

    public MapMessage createMapMessage() throws JMSException {
        return getSession().createMapMessage();
    }

    public Message createMessage() throws JMSException {
        return getSession().createMessage();
    }

    public ObjectMessage createObjectMessage() throws JMSException {
        return getSession().createObjectMessage();
    }

    public ObjectMessage createObjectMessage(Serializable serializable) throws JMSException {
        return getSession().createObjectMessage(serializable);
    }

    public Queue createQueue(String s) throws JMSException {
        return getSession().createQueue(s);
    }

    public StreamMessage createStreamMessage() throws JMSException {
        return getSession().createStreamMessage();
    }

    public TemporaryQueue createTemporaryQueue() throws JMSException {
        return getSession().createTemporaryQueue();
    }

    public TemporaryTopic createTemporaryTopic() throws JMSException {
        return getSession().createTemporaryTopic();
    }

    public void unsubscribe(String s) throws JMSException {
        getSession().unsubscribe(s);
    }

    public TextMessage createTextMessage() throws JMSException {
        return getSession().createTextMessage();
    }

    public TextMessage createTextMessage(String s) throws JMSException {
        return getSession().createTextMessage(s);
    }

    public Topic createTopic(String s) throws JMSException {
        return getSession().createTopic(s);
    }

    public int getAcknowledgeMode() throws JMSException {
        return getSession().getAcknowledgeMode();
    }

    public boolean getTransacted() throws JMSException {
        return getSession().getTransacted();
    }

    public void recover() throws JMSException {
        getSession().recover();
    }

    public void rollback() throws JMSException {
        getSession().rollback();
    }

    public void run() {
        if (session != null) {
            session.run();
        }
    }


    // Consumer related methods
    //-------------------------------------------------------------------------
    public QueueBrowser createBrowser(Queue queue) throws JMSException {
        return getSession().createBrowser(queue);
    }

    public QueueBrowser createBrowser(Queue queue, String selector) throws JMSException {
        return getSession().createBrowser(queue, selector);
    }

    public MessageConsumer createConsumer(Destination destination) throws JMSException {
        return getSession().createConsumer(destination);
    }

    public MessageConsumer createConsumer(Destination destination, String selector) throws JMSException {
        return getSession().createConsumer(destination, selector);
    }

    public MessageConsumer createConsumer(Destination destination, String selector, boolean noLocal) throws JMSException {
        return getSession().createConsumer(destination, selector, noLocal);
    }

    public TopicSubscriber createDurableSubscriber(Topic topic, String selector) throws JMSException {
        return getSession().createDurableSubscriber(topic, selector);
    }

    public TopicSubscriber createDurableSubscriber(Topic topic, String name, String selector, boolean noLocal) throws JMSException {
        return getSession().createDurableSubscriber(topic, name, selector, noLocal);
    }

    public MessageListener getMessageListener() throws JMSException {
        return getSession().getMessageListener();
    }

    public void setMessageListener(MessageListener messageListener) throws JMSException {
        getSession().setMessageListener(messageListener);
    }

    public TopicSubscriber createSubscriber(Topic topic) throws JMSException {
        return getSession().createSubscriber(topic);
    }

    public TopicSubscriber createSubscriber(Topic topic, String selector, boolean local) throws JMSException {
        return getSession().createSubscriber(topic, selector, local);
    }

    public QueueReceiver createReceiver(Queue queue) throws JMSException {
        return getSession().createReceiver(queue);
    }

    public QueueReceiver createReceiver(Queue queue, String selector) throws JMSException {
        return getSession().createReceiver(queue, selector);
    }


    // Producer related methods
    //-------------------------------------------------------------------------
    public MessageProducer createProducer(Destination destination) throws JMSException {
        return new PooledProducer(getMessageProducer(), destination);
    }

    public QueueSender createSender(Queue queue) throws JMSException {
        return new PooledQueueSender(getQueueSender(), queue);
    }

    public TopicPublisher createPublisher(Topic topic) throws JMSException {
        return new PooledTopicPublisher(getTopicPublisher(), topic);
    }

    // Implementation methods
    //-------------------------------------------------------------------------
    protected ActiveMQSession getSession() throws AlreadyClosedException {
        if (session == null) {
            throw new AlreadyClosedException("The session has already been closed");
        }
        return session;
    }

    public ActiveMQMessageProducer getMessageProducer() throws JMSException {
        if (messageProducer == null) {
            messageProducer = (ActiveMQMessageProducer) getSession().createProducer(null);
        }
        return messageProducer;
    }

    public ActiveMQQueueSender getQueueSender() throws JMSException {
        if (queueSender == null) {
            queueSender = (ActiveMQQueueSender) getSession().createSender(null);
        }
        return queueSender;
    }

    public ActiveMQTopicPublisher getTopicPublisher() throws JMSException {
        if (topicPublisher == null) {
            topicPublisher = (ActiveMQTopicPublisher) getSession().createPublisher(null);
        }
        return topicPublisher;
    }

}
