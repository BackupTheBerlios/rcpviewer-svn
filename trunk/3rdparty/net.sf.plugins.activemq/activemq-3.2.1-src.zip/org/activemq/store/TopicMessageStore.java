/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store;

import javax.jms.JMSException;

import org.activemq.message.ConsumerInfo;
import org.activemq.service.MessageIdentity;
import org.activemq.service.SubscriberEntry;

/**
 * A MessageStore for durable topic subscriptions
 *
 * @version $Revision: 1.1.1.1 $
 */
public interface TopicMessageStore extends MessageStore {

    /**
     * Increments the reference count of the message ID as its been dispatched
     * to another subscriber.
     *
     * @param messageId
     */
    public void incrementMessageCount(MessageIdentity messageId) throws JMSException;

    /**
     * Decrement the reference count of this message ID and if there
     * are no more references then delete the message from persistent store
     * (or maybe archive it off somewhere)
     *
     * @param msgId
     */
    public void decrementMessageCountAndMaybeDelete(MessageIdentity msgId) throws JMSException;

    /**
     * Stores the last acknowledged messgeID for the given subscription
     * so that we can recover and commence dispatching messages from the last
     * checkpoint
     *
     * @param subscriptionPersistentId
     * @param messageIdentity
     */
    public void setLastAcknowledgedMessageIdentity(String subscription, MessageIdentity messageIdentity) throws JMSException;

    /**
     * @param sub
     * @throws JMSException 
     */
    public void deleteSubscription(String subscription) throws JMSException;
    
    /**
     * For the new subcription find the last acknowledged message ID
     * and then find any new messages since then and dispatch them
     * to the subscription.
     * <p/>
     * If this is a new subscription then the lastDispatchMessage should be written to the
     * acknowledgement table to write a checkpoint so that when we recover we will start
     * from the correct point.
     * <p/>
     * e.g. if we dispatched some messages to a new durable topic subscriber, then went down before
     * acknowledging any messages, we need to know the correct point from which to recover from.
     *
     * @param subscription
     * @param lastDispatchedMessage
     */
    public void recoverSubscription(String subscriptionId, MessageIdentity lastDispatchedMessage, RecoveryListener listener) throws JMSException;

    /**
     * Returns the last message identity that was delivered on this container which can then be used as a
     * checkpoint so that when new durable consumers start, we know where to checkpoint their subscriptions.
     * <p/>
     * Note that this method does not need to return a valid messageID, purely the sequence number.
     *
     * @return the last message identity which was persisted in the durable store or null if the store is empty.
     */
    public MessageIdentity getLastestMessageIdentity() throws JMSException;

    /**
     * Finds the subscriber entry for the given consumer info
     *
     * @param info
     * @return
     */
    public SubscriberEntry getSubscriberEntry(ConsumerInfo info) throws JMSException;

    /**
     * Inserts or updates the subscriber info due to a subscription change
     *
     * @param info
     * @param subscriberEntry
     * @throws JMSException
     */
    public void setSubscriberEntry(ConsumerInfo info, SubscriberEntry subscriberEntry) throws JMSException;

}
