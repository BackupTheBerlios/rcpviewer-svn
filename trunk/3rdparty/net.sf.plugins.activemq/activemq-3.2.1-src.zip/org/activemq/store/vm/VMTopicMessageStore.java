/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.vm;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.jms.JMSException;

import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ConsumerInfo;
import org.activemq.service.MessageIdentity;
import org.activemq.service.SubscriberEntry;
import org.activemq.store.RecoveryListener;
import org.activemq.store.TopicMessageStore;

/**
 * @version $Revision: 1.1.1.1 $
 */
public class VMTopicMessageStore extends VMMessageStore implements TopicMessageStore {
    private static final Integer ONE = new Integer(1);

    private Map ackDatabase;
    private Map messageCounts;
    private Map subscriberDatabase;

    public VMTopicMessageStore() {
        this(new LinkedHashMap(), makeMap(), makeMap(), makeMap());
    }

    public VMTopicMessageStore(LinkedHashMap messageTable, Map subscriberDatabase, Map ackDatabase, Map messageCounts) {
        super(messageTable);
        this.subscriberDatabase = subscriberDatabase;
        this.ackDatabase = ackDatabase;
        this.messageCounts = messageCounts;
    }

    public synchronized void incrementMessageCount(MessageIdentity messageId) throws JMSException {
        Integer number = (Integer) messageCounts.get(messageId.getMessageID());
        if (number == null) {
            number = ONE;
        }
        else {
            number = new Integer(number.intValue() + 1);
        }
        messageCounts.put(messageId.getMessageID(), number);
    }

    public synchronized void decrementMessageCountAndMaybeDelete(MessageIdentity msgId) throws JMSException {
        Integer number = (Integer) messageCounts.get(msgId.getMessageID());
        if (number == null || number.intValue() <= 1) {
            removeMessage(msgId);
            if (number != null) {
                messageCounts.remove(msgId.getMessageID());
            }
        }
        else {
            messageCounts.put(msgId.getMessageID(), new Integer(number.intValue() - 1));
            number = ONE;
        }
    }

    public void setLastAcknowledgedMessageIdentity(String subscription, MessageIdentity messageIdentity) throws JMSException {
        ackDatabase.put(subscription, messageIdentity);
    }

    public synchronized void recoverSubscription(String subscriptionId, MessageIdentity lastDispatchedMessage, RecoveryListener listener) throws JMSException {
        //iterate through the message table and populate the subscriber
        Map map = new HashMap(messageTable);
        boolean alreadyAcked = true;
        MessageIdentity lastAcked = (MessageIdentity)ackDatabase.get(subscriptionId);
		if( lastAcked==null )
			return;
		
        for (Iterator i = map.values().iterator(); i.hasNext(); ){
            ActiveMQMessage msg = (ActiveMQMessage)i.next();			
            if (!alreadyAcked){
                listener.recoverMessage(msg.getJMSMessageIdentity());
            }
            if (lastAcked.getMessageID().equals(msg.getJMSMessageID())){
                alreadyAcked = false;
            }			
        }
    }

    public MessageIdentity getLastestMessageIdentity() throws JMSException {
        return super.lastMessageIdentity;
    }

    public SubscriberEntry getSubscriberEntry(ConsumerInfo info) throws JMSException {
        Object key = info.getConsumerKey();
        return (SubscriberEntry) subscriberDatabase.get(key);
    }

    public void setSubscriberEntry(ConsumerInfo info, SubscriberEntry subscriberEntry) throws JMSException {
        subscriberDatabase.put(info.getConsumerKey(), subscriberEntry);
    }

    public void stop() throws JMSException {
    }

    protected static Map makeMap() {
        return Collections.synchronizedMap(new HashMap());
    }

    public void deleteSubscription(String sub) {
        ackDatabase.remove(sub);        
    }

}
