/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service;

import java.io.Serializable;

/**
 * Represents a message identity, either by using a unique
 * message number, which is ordered and must not be zero or
 * by specifying the String messageID.
 * <p/>
 * Typically a client accessing the MessageStore may have
 * one or the other. Depending on which one is specified the
 * other value may be filled in by operations on the MessageStore
 *
 * @version $Revision: 1.1.1.1 $
 */
public class MessageIdentity implements Comparable, Serializable {
    private static final long serialVersionUID = -5754338187296859149L;

    private String messageID;
    private Object sequenceNumber;

    public MessageIdentity() {
    }

    public MessageIdentity(String messageID) {
        this.messageID = messageID;
    }

    public MessageIdentity(String messageID, Object sequenceNumber) {
        this.messageID = messageID;
        this.sequenceNumber = sequenceNumber;
    }

    public int hashCode() {
        return messageID != null ? messageID.hashCode() ^ 0xcafebabe : -1;
    }

    public boolean equals(Object that) {
        return that instanceof MessageIdentity && equals((MessageIdentity) that);
    }

    public boolean equals(MessageIdentity that) {
        return messageID.equals(that.messageID);
    }

    public int compareTo(Object object) {
        if (this == object) {
            return 0;
        }
        else {
            if (object instanceof MessageIdentity) {
                MessageIdentity that = (MessageIdentity) object;
                return messageID.compareTo(that.messageID);
            }
            else {
                return -1;
            }
        }
    }

    public String toString() {
        return super.toString() + "[id=" + messageID + "; sequenceNo=" + sequenceNumber + "]";
    }

    public String getMessageID() {
        return messageID;
    }

    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    /**
     * @return the sequence number which may be a number or some database specific type
     */
    public Object getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(Object sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

}
