/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.io.impl;
import java.io.DataInput;
import java.io.IOException;
import javax.jms.Destination;

import org.activemq.io.util.WireByteArrayInputStream;
import org.activemq.message.AbstractPacket;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ActiveMQXid;
import org.activemq.message.Packet;
import org.activemq.util.BitArray;

/**
 * Writes a ProducerInfo object to a Stream
 */
public class ActiveMQMessageReader extends AbstractPacketReader {
    
    private AbstractDefaultWireFormat wireFormat;
   
    
    ActiveMQMessageReader(AbstractDefaultWireFormat wf){
        this.wireFormat = wf;
    }
    /**
     * Return the type of Packet
     * 
     * @return integer representation of the type of Packet
     */
    public int getPacketType() {
        return Packet.ACTIVEMQ_MESSAGE;
    }

    /**
     * @return a new Packet instance
     */
    public Packet createPacket() {
        return new ActiveMQMessage();
    }

    /**
     * build a Packet instance from the data input stream
     *
     * @param packet A Packet object
     * @param dataIn the data input stream to build the packet from
     * @throws IOException
     */
    public void buildPacket(Packet packet, DataInput dataIn) throws IOException {
        ActiveMQMessage msg = (ActiveMQMessage) packet;
        BitArray ba = msg.getBitArray();
        ba.readFromStream(dataIn);
        
        boolean receiptRequired = ba.get(AbstractPacket.RECEIPT_REQUIRED_INDEX);
        if (receiptRequired){
            msg.setReceiptRequired(receiptRequired);
            msg.setId(dataIn.readShort());
        }
        boolean externalMessageId = ba.get(ActiveMQMessage.EXTERNAL_MESSAGE_ID_INDEX);
        
        if (externalMessageId){
            msg.setExternalMessageId(externalMessageId);
            msg.setJMSMessageID(readUTF(dataIn));
        }
        
        boolean cachingEnabled = ba.get(ActiveMQMessage.CACHED_VALUES_INDEX);
        boolean cachingDestination = ba.get(ActiveMQMessage.CACHED_DESTINATION_INDEX);
        
        boolean messagePart = ba.get(ActiveMQMessage.MESSAGE_PART_INDEX);
        msg.setMessagePart(messagePart);
        if (messagePart){
            msg.setParentMessageID(dataIn.readUTF());
            msg.setNumberOfParts(dataIn.readShort());
            msg.setPartNumber(dataIn.readShort());
        }
       
        if (ba.get(AbstractPacket.BROKERS_VISITED_INDEX)){
            int visitedLen = dataIn.readShort();
            for (int i =0; i < visitedLen; i++){
                msg.addBrokerVisited(dataIn.readUTF());
            }        
        }
        if (cachingEnabled){
            short key = dataIn.readShort();
            msg.setJMSClientID((String)wireFormat.getValueFromReadCache(key));
            key = dataIn.readShort();
            msg.setProducerKey((String)wireFormat.getValueFromReadCache(key));
            if (cachingDestination){
                key = dataIn.readShort();
                msg.setJMSDestination((Destination)wireFormat.getValueFromReadCache(key));
            }else{
                msg.setJMSDestination(ActiveMQDestination.readFromStream(dataIn));
            }
            if (ba.get(ActiveMQMessage.REPLY_TO_INDEX)) {
                key = dataIn.readShort();
                msg.setJMSReplyTo((Destination)wireFormat.getValueFromReadCache(key));
            }
            if (ba.get(ActiveMQMessage.TRANSACTION_ID_INDEX)) {
                key = dataIn.readShort();
                msg.setTransactionId(wireFormat.getValueFromReadCache(key));
            }
            
        }else {
            msg.setJMSClientID(super.readUTF(dataIn));
            msg.setProducerKey(dataIn.readUTF());
            msg.setJMSDestination(ActiveMQDestination.readFromStream(dataIn));
            if (ba.get(ActiveMQMessage.REPLY_TO_INDEX)) {
                msg.setJMSReplyTo(ActiveMQDestination.readFromStream(dataIn));
            }
            if (ba.get(ActiveMQMessage.TRANSACTION_ID_INDEX)) {
                if( ba.get(ActiveMQMessage.XA_TRANS_INDEX) ) {
                    msg.setTransactionId(ActiveMQXid.read(dataIn));                
                } else {
                    msg.setTransactionId(super.readUTF(dataIn));
                }
            } else {
                msg.setTransactionId(null);
            }
        }
        
        
        msg.setJMSDeliveryMode(dataIn.readByte());
        msg.setJMSPriority(dataIn.readByte());
     
        msg.setJMSRedelivered(ba.get(ActiveMQMessage.REDELIVERED_INDEX));

        if (ba.get(ActiveMQMessage.CORRELATION_INDEX)) {
            msg.setJMSCorrelationID(super.readUTF(dataIn));
        }
        if (ba.get(ActiveMQMessage.TYPE_INDEX)) {
            msg.setJMSType(super.readUTF(dataIn));
        }
        if (ba.get(ActiveMQMessage.BROKER_NAME_INDEX)) {
            msg.setEntryBrokerName(super.readUTF(dataIn));
        }
        if (ba.get(ActiveMQMessage.CLUSTER_NAME_INDEX)) {
            msg.setEntryClusterName(super.readUTF(dataIn));
        }
        
        if (ba.get(ActiveMQMessage.TIMESTAMP_INDEX)) {
            msg.setJMSTimestamp(dataIn.readLong());
        }
        if (ba.get(ActiveMQMessage.EXPIRATION_INDEX)) {
            msg.setJMSExpiration(dataIn.readLong());
        }
        if (ba.get(ActiveMQMessage.LONG_SEQUENCE_INDEX)){
            msg.setSequenceNumber(dataIn.readLong());
        }else {
            msg.setSequenceNumber(dataIn.readInt());
        }
        msg.setDeliveryCount(dataIn.readByte());
        if (ba.get(ActiveMQMessage.DISPATCHED_FROM_DLQ_INDEX)){
            msg.setDispatchedFromDLQ(true);
        }
        
        if (ba.get(ActiveMQMessage.CID_INDEX)) {
            int cidlength = dataIn.readShort();
            if (cidlength > 0) {
                int[] cids = new int[cidlength];
                for (int i = 0; i < cids.length; i++) {
                    cids[i] = dataIn.readShort();
                }
                msg.setConsumerNos(cids);
            }
        }
        if (ba.get(ActiveMQMessage.PROPERTIES_INDEX)) {
            msg.setProperties(msg.readMapProperties(dataIn));
        }
        
        if (ba.get(ActiveMQMessage.PAYLOAD_INDEX)) {
            int payloadLength = dataIn.readInt();
            if (payloadLength >= 0) {
                if (dataIn instanceof WireByteArrayInputStream){
                    WireByteArrayInputStream wireIn = (WireByteArrayInputStream)dataIn;
                    msg.setBodyAsBytes(wireIn.getRawData(), wireIn.position(), payloadLength);
                }else {
                byte[] payload = new byte[payloadLength];
                dataIn.readFully(payload);
                msg.setBodyAsBytes(payload,0,payload.length);
                }
            }
        }
        
           
    }
}
