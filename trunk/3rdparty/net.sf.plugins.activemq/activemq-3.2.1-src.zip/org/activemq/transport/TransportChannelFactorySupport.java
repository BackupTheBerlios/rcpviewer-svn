/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.transport;
import org.activemq.io.WireFormat;
import org.activemq.io.WireFormatLoader;
import org.activemq.util.BeanUtils;
import org.activemq.util.URIHelper;
import java.net.URI;
import java.util.Map;
import javax.jms.JMSException;

/**
 * Useful for implementation inheritence
 * 
 * @version $Revision: 1.1.1.1 $
 */
public abstract class TransportChannelFactorySupport implements TransportChannelFactory {

    /**
     * If a query string is present in the URI then set any simple bean properties on the channel
     * 
     * @param channel
     * @param uri
     * @return the channel, with properties set
     * @throws JMSException
     */
    protected TransportChannel populateProperties(TransportChannel channel, URI uri) throws JMSException {
        Map properties = URIHelper.parseQuery(uri);
        return populateProperties(channel, properties);
    }

    /**
     * If a query string is present in the URI then set any simple bean properties on the channel
     *
     * @param channel
     * @param uri
     * @return the channel, with properties set
     * @throws JMSException
     */
    protected TransportChannel populateProperties(TransportChannel channel, String uri) throws JMSException {
        Map properties = URIHelper.parseQuery(uri);
        return populateProperties(channel, properties);
    }


    protected TransportChannel populateProperties(TransportChannel channel, Map properties) throws JMSException {
        String wireFormatName = (String) properties.remove("wireFormat");
        if (wireFormatName != null) {
            wireFormatName = wireFormatName.trim();
            if (wireFormatName.length() > 0) {
                WireFormat wf = WireFormatLoader.getWireFormat(wireFormatName);
                if (wf != null) {
                    channel.setWireFormat(wf);
                }
            }
        }
        if (!properties.isEmpty()) {
            BeanUtils.populate(channel, properties);
        }
        return channel;
    }
}