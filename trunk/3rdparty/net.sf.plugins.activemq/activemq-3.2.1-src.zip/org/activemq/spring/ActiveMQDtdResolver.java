/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.spring;

import org.activemq.ActiveMQConnectionMetaData;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * EntityResolver implementation for the ActiveMQ DTD,
 * to load the DTD from the ActiveMQ classpath JAR file.
 * <p/>
 * <p>Fetches "activemq.dtd" from the classpath resource
 * "/org/activemq/activemq.dtd",
 * no matter if specified as some local URL or as
 * "http://activemq.org/dtd/activemq.dtd".
 *
 * @version $Revision$
 */
public class ActiveMQDtdResolver implements EntityResolver {

    private static final String CHECK_FOR_DTD_UPDATE = "activemq.check_for_dtd_update";
    private static final String DTD_NAME = "activemq.dtd";
    private static final String SEARCH_PACKAGE = "/org/activemq/";

    protected final Log logger = LogFactory.getLog(getClass());

    public InputSource resolveEntity(String publicId, String systemId) throws IOException {
        logger.debug("Trying to resolve XML entity with public ID [" + publicId +
                "] and system ID [" + systemId + "]");
        
        InputSource source = null;
        if (systemId != null && systemId.indexOf(DTD_NAME) > systemId.lastIndexOf("/")) {
            
            if( "true".equals(System.getProperty(CHECK_FOR_DTD_UPDATE, "true")) ) {
                source = resolveRemotely(publicId, systemId);
            }
            if( source == null ) {
                source = resolveLocally(publicId, systemId);
            }
        }
        return source;
    }
    
    /**
     * Try to resolve against the latest DTD for this version of activemq.
     * 
     * @param publicId
     * @param systemId
     * @return
     */
    InputSource resolveRemotely(String publicId, String systemId) {
        InputSource source=null;
        if( systemId.endsWith(DTD_NAME) ) {
            String dtdFile = "http://activemq.org/dtd/"+ActiveMQConnectionMetaData.PROVIDER_VERSION+"/"+DTD_NAME;
            logger.debug("Trying to locate [" + dtdFile + "]");
            try {
                URL url = new URL(dtdFile);
                InputStream stream = url.openStream();
                if( stream!=null ) {
                    source = new InputSource(stream);
                    source.setPublicId(publicId);
                    source.setSystemId(systemId);
                    logger.debug("Found beans DTD [" + systemId + "] at: "+dtdFile);
                }
            }
            catch (IOException ex) {
                logger.debug("Could not resolve beans DTD [" + systemId + "]: not found in classpath", ex);
            }
        }
        return null;
    }

    /**
     * Use the DTD that this version of ActiveMQ shipped with.
     * 
     * @param publicId
     * @param systemId
     * @return
     */
    InputSource resolveLocally(String publicId, String systemId) {        
        String dtdFile = systemId.substring(systemId.indexOf(DTD_NAME));
        logger.debug("Trying to locate [" + dtdFile + "] under [" + SEARCH_PACKAGE + "]");
        try {
            String name = SEARCH_PACKAGE + dtdFile;
            Resource resource = new ClassPathResource(name, getClass());
            InputSource source = new InputSource(resource.getInputStream());
            source.setPublicId(publicId);
            source.setSystemId(systemId);
            logger.debug("Found beans DTD [" + systemId + "] in classpath");
            return source;
        }
        catch (IOException ex) {
            logger.debug("Could not resolve beans DTD [" + systemId + "]: not found in classpath", ex);
            // use the default behaviour -> download from website or wherever
            return null;
        }
    }

}
