/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.spring;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.core.io.Resource;
import org.activemq.broker.BrokerContainer;

/**
 * A Spring {@link FactoryBean} to make it easy to create an embedded broker
 * inside Spring.
 *
 * @version $Revision: 1.1 $
 */
public class BrokerFactoryBean implements FactoryBean, InitializingBean, DisposableBean {
    private Resource config;
    private BrokerContainer broker;

    public Object getObject() throws Exception {
        return broker;
    }

    public Class getObjectType() {
        return BrokerContainer.class;
    }

    public boolean isSingleton() {
        return true;
    }

    public void afterPropertiesSet() throws Exception {
        if (config == null) {
            throw new IllegalArgumentException("configu property must be set");
        }
        broker = SpringBrokerContainerFactory.newInstance(config);
        broker.start();
    }

    public void destroy() throws Exception {
        if (broker != null) {
            broker.stop();
        }
    }

    public Resource getConfig() {
        return config;
    }

    public void setConfig(Resource config) {
        this.config = config;
    }
}
