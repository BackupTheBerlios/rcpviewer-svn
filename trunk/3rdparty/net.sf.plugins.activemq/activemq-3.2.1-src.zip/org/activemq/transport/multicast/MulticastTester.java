/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.transport.multicast;
import java.net.URI;
import java.net.URISyntaxException;

import javax.jms.JMSException;

import org.activemq.io.impl.DefaultWireFormat;
import org.activemq.message.ActiveMQTextMessage;
import org.activemq.message.Packet;
import org.activemq.message.PacketListener;
import org.activemq.util.IdGenerator;

import EDU.oswego.cs.dl.util.concurrent.SynchronizedBoolean;

/**
 * An agent used to discover other instances of a service
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class MulticastTester implements PacketListener {
    
    private static final IdGenerator idGenerator = new IdGenerator();
    public static final String DEFAULT_DISCOVERY_URI = "multicast://224.1.2.3:6066";
    
    private SynchronizedBoolean started = new SynchronizedBoolean(false);
    private MulticastTransportChannel channel;
    
    private URI uri;
    private String localId = idGenerator.generateId();
    
    public static void main(String[] args) throws URISyntaxException, JMSException, InterruptedException {
        
        MulticastTester tester = new MulticastTester();
        tester.setUri(new URI(DEFAULT_DISCOVERY_URI));
        
        if( args.length > 0 ) {
            tester.setUri(new URI(args[0]));            
        }
        if( args.length > 1 ) {
            tester.setLocalId(args[1]);            
        }
        
        tester.start();
        
        ActiveMQTextMessage message = new ActiveMQTextMessage();
        int counter = 0;
        while( true ) {
            message.setText("Message "+counter+" from "+tester.getLocalId());
            tester.send(message);
            counter++;
            Thread.sleep(1000);
        }
        
    }

    private void send(ActiveMQTextMessage message) throws JMSException {
        channel.asyncSend(message);
    }

    public void start() throws JMSException {
        if (started.commit(false, true)) {
            System.out.println("Opening: "+uri);
            channel = new MulticastTransportChannel(new DefaultWireFormat(), uri);
            channel.setClientID(localId);
            channel.setPacketListener(this);
            channel.start();
        }
    }

    public void stop() throws JMSException {
        if (started.commit(true, false)) {
            channel.stop();
        }
    }

    public void consume(Packet packet) {
        if( packet instanceof ActiveMQTextMessage ) {
            try {
                System.out.println("Received Text Packet: "+((ActiveMQTextMessage)packet).getText());
            } catch (JMSException e) {
                e.printStackTrace();
            }            
        } else {
            System.out.println("Received Unknown Packet: "+packet);
        }
    }
    /**
     * @return Returns the localId.
     */
    public String getLocalId() {
        return localId;
    }
    /**
     * @param localId The localId to set.
     */
    public void setLocalId(String localId) {
        this.localId = localId;
    }
    /**
     * @return Returns the uri.
     */
    public URI getUri() {
        return uri;
    }
    /**
     * @param uri The uri to set.
     */
    public void setUri(URI uri) {
        this.uri = uri;
    }
    
}