/**
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.spring;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.w3c.dom.Document;
import org.xml.sax.EntityResolver;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;

/**
 * @version $Revision$
 */
public class ActiveMQBeanDefinitionReader extends XmlBeanDefinitionReader {
    private String brokerName;

    public ActiveMQBeanDefinitionReader(BeanDefinitionRegistry beanDefinitionRegistry, String brokerName) {
        super(beanDefinitionRegistry);
        this.brokerName = brokerName;
        setEntityResolver(createEntityResolver());
    }

    public int registerBeanDefinitions(Document document, Resource resource) throws BeansException {
        try {
            Document newDocument = transformDocument(document);
            return super.registerBeanDefinitions(newDocument, resource);
        }
        catch (Exception e) {
            throw new ConfigurationParseException(resource, e);
        }
    }

    public static Transformer createTransformer(Source source) throws TransformerConfigurationException {
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer = factory.newTransformer(source);
        transformer.setURIResolver(new URIResolver() {
            public Source resolve(String href, String base) {
                System.out.println("Called with href:  " + href + " base: " + base);
                return null;
            }
        });
        return transformer;
    }


    // Properties
    //-------------------------------------------------------------------------
    public String getBrokerName() {
        return brokerName;
    }

    public void setBrokerName(String brokerName) {
        this.brokerName = brokerName;
    }

    // Implementation methods
    //-------------------------------------------------------------------------

    /**
     * A hook to transform the source document into a default Spring XML configuration
     *
     * @param document
     * @return
     */
    protected Document transformDocument(Document document) throws IOException, TransformerException {
        Transformer transformer = createTransformer(createXslSource());
        transformer.setParameter("brokerName", getBrokerName());
        DOMResult result = new DOMResult();
        transformer.transform(new DOMSource(document), result);
        return (Document) result.getNode();
    }

    /**
     * Creates the XSL resource for the transformation
     *
     * @return
     */
    protected Source createXslSource() throws IOException {
        return new StreamSource(getXslResource().getInputStream(), getXslResource().getURL().toString());
    }

    /**
     * @return the resource to use for the XSLT
     */
    protected ClassPathResource getXslResource() {
        return new ClassPathResource("org/activemq/activemq-to-spring.xsl");
    }

    /**
     * @return a new EnittyResolver
     */
    protected EntityResolver createEntityResolver() {
        return new ActiveMQDtdResolver();
    }
}
