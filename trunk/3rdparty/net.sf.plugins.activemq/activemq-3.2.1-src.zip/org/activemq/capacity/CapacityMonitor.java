/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/


package org.activemq.capacity;
/**
 * Fires CapacityChangedEvents
 * 
 * @version $Revision: 1.1.1.1 $
 */
public interface CapacityMonitor {
    
/**
 *
 * A CapacityMonitor holds percentage values
 * for some resource that has a capacity - 
 * e.g. a MemoryBoundedQueue
 * @version $Revision: 1.1.1.1 $
 */
public class BasicCapacityMonitor{

}
    /**
     * Get the name of the CapacityMonitor
     * @return the name
     */
    public String getName();
    
    /**
     * Set the name of the CapacityMonitor
     * @param newName
     */
    public void setName(String newName);
    
    /**
     * Get the rounding factor - default is 10
     * @return the rounding factor
     */
    public int getRoundingFactor();
    
    /**
     * Set the rounding factor (between 1-100)
     * @param newRoundingFactor
     */
    public void setRoundingFactor(int newRoundingFactor);
    
    /**
     * Add a CapacityMonitorEventListener
     * 
     * @param l
     */
    public void addCapacityEventListener(CapacityMonitorEventListener l);

    /**
     * Remove a CapacityMonitorEventListener
     * 
     * @param l
     */
    public void removeCapacityEventListener(CapacityMonitorEventListener l);

    /**
     * Get the current capacity of the service as a percentage
     * 
     * @return
     */
    public int getCurrentCapacity();
    
    /**
     * Calculates the capacity rounded down to the rounding factor
     * @return
     */
    public int getRoundedCapacity();

    /**
     * Get the current value of the CapacityMonitor
     * 
     * @return
     */
    public long getCurrentValue();

    /**
     * set the current value of the capacity
     * 
     * @param newCurrentValue
     */
    public void setCurrentValue(long newCurrentValue);

    /**
     * @return The upper limit of the value of the CapacityMonitor
     */
    public long getValueLimit();

    /**
     * set a new value limit for the CapacityMonitor
     * 
     * @param newValueLimit
     */
    public void setValueLimit(long newValueLimit);
    
    /**
     * @return a CapacityMontorEvent for the currentCapacity
     */
    public CapacityMonitorEvent generateCapacityMonitorEvent();
}
