/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.transport.multicast;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.MulticastSocket;
import java.net.URI;

import javax.jms.JMSException;

import org.activemq.io.WireFormat;
import org.activemq.transport.udp.UdpTransportChannel;

/**
 * A multicast implementation of a TransportChannel
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class MulticastTransportChannel extends UdpTransportChannel {

    private boolean loopbackMode = false; // no loopback by default as we don't
    // need to see our own messages
 
    private int timeToLive = 1; // don't send multicast messages beyound our local subnet
    

    /**
     * Connect to a remote Node - e.g. a Broker
     * @param wireFormat
     * @param remoteLocation
     * @throws JMSException
     */
    public MulticastTransportChannel(WireFormat wireFormat, URI remoteLocation) throws JMSException {
        super(wireFormat, remoteLocation);
    }

    /**
     * @param wireFormat
     * @param socket
     * @throws JMSException
     */
    public MulticastTransportChannel(WireFormat wireFormat, MulticastSocket socket) throws JMSException {
        super(wireFormat, socket);
    }

    /**
     * @return true
     */
    public boolean isMulticast() {
        return true;
    }

    /**
     * pretty print for object
     * 
     * @return String representation of this object
     */
    public String toString() {
        return "MulticastTransportChannel: " + socket;
    }
    
    /**
     * @return Returns the timeToLive.
     */
    public int getTimeToLive() {
        return timeToLive;
    }
    /**
     * @param timeToLive The timeToLive to set.
     * @throws IOException
     */
    public void setTimeToLive(int timeToLive) throws IOException {
        this.timeToLive = timeToLive;
        MulticastSocket msocket = (MulticastSocket) socket;
        if (msocket != null){
            msocket.setTimeToLive(timeToLive);
        }
    }

    protected void connect() throws IOException {
        MulticastSocket msocket = (MulticastSocket) socket;
        
        //log.info("Creating multicast socket on port: " + port + " on
        msocket.setLoopbackMode(loopbackMode);
        msocket.setTimeToLive(getTimeToLive());
        msocket.joinGroup(inetAddress);
    }

    protected DatagramSocket createSocket(int port) throws IOException {
        return new MulticastSocket(port);
    }

}