/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.transport;

import org.activemq.broker.BrokerContainer;

/**
 * Represents a connector to one or more remote brokers.
 * This class manages a number of {@link NetworkChannel} instances
 * which may or may not be connected to a
 * remote broker at any point in time.
 * <p/>
 * The implementation of this class could use a fixed number of
 * configured {@link NetworkChannel} instances or could use
 * discovery to find them.
 *
 * @version $Revision: 1.1.1.1 $
 */
public class RemoteNetworkConnector extends NetworkConnector {
   
    
    /**
     * RemoteNetworkConnector
     * @param brokerContainer
     */
    public RemoteNetworkConnector(BrokerContainer brokerContainer) {
        super(brokerContainer);
    }

    /**
     * Create a channel from the url
     * @param url
     * @return
     */
    protected NetworkChannel createNetworkChannel(String url) {
        NetworkChannel answer = new RemoteNetworkChannel(this,getBrokerContainer(), url);
        answer.setRemoteUserName(getRemoteUserName());
        answer.setRemotePassword(getRemotePassword());
        return answer;
    }

}
