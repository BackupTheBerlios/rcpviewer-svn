/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.service.boundedvm;


import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import org.activemq.filter.Filter;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ConsumerInfo;
import org.activemq.broker.BrokerClient;

/**
 * A holder for Transient Topic consumer info and message routing
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class TransientTopicSubscription  extends TransientSubscription{
   
    
    /**
     * Construct the TransientTopicSubscription
     * @param filter
     * @param info
     */
    public TransientTopicSubscription(Filter filter, ConsumerInfo info, BrokerClient client) {
        super(filter, info, client);
    }

    
    /**
     * determines if the Subscription is interested in the message
     *
     * @param message
     * @return true if this Subscription will accept the message
     * @throws JMSException
     */
    public boolean isTarget(ActiveMQMessage message) throws JMSException {
        boolean result = false;
        if (message != null) {
            //make sure we don't loop messages around the cluster
            if (!client.isClusteredConnection() || !message.isEntryCluster(clusterName)
                    || message.isEntryBroker(brokerName)) {
                result = filter.matches(message);
                //if we are durable, check we only send non-persistent messages
                if (result && consumerInfo.isDurableTopic()) {
                    result = message.getJMSDeliveryMode() == DeliveryMode.NON_PERSISTENT;
                }
            }
        }
        return result;
    }

    public boolean isDurableTopic() {
        return consumerInfo.isDurableTopic();
    }
}