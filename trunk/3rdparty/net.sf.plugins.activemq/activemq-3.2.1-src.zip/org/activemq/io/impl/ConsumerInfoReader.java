/**
 *
 * Copyright 2004 Protique Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/


package org.activemq.io.impl;
import java.io.DataInput;
import java.io.IOException;
import org.activemq.message.ActiveMQDestination;
import org.activemq.message.ConsumerInfo;
import org.activemq.message.Packet;

/**
 * Reads a ConsumerInfo object from a Stream
 */

public class ConsumerInfoReader extends AbstractPacketReader {

    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return Packet.CONSUMER_INFO;
    }

    /**
     * @return a new Packet instance
     */

    public Packet createPacket() {
        return new ConsumerInfo();
    }


    /**
     * build a Packet instance from the data input stream
     *
     * @param packet A Packet object
     * @param dataIn the data input stream to build the packet from
     * @throws IOException
     */

    public void buildPacket(Packet packet, DataInput dataIn) throws IOException {
        super.buildPacket(packet, dataIn);
        ConsumerInfo info = (ConsumerInfo) packet;
        info.setConsumerId(dataIn.readUTF());
        info.setClientId(dataIn.readUTF());
        info.setSessionId(dataIn.readShort());
        info.setSelector(dataIn.readUTF());
        info.setConsumerName(dataIn.readUTF());
        info.setConsumerNo(dataIn.readInt());
        info.setPrefetchNumber(dataIn.readShort());
        info.setStartTime(dataIn.readLong());
        info.setStarted(dataIn.readBoolean());
        info.setReceiptRequired(dataIn.readBoolean());
        info.setNoLocal(dataIn.readBoolean());
        info.setBrowser(dataIn.readBoolean());
        info.setDestination(ActiveMQDestination.readFromStream(dataIn));
    }


}
