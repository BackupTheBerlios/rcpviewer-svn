/** 
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.cache;

import org.activemq.message.ActiveMQMessage;

/**
 * Defines the interface used to cache messages.
 *
 * @version $Revision: 1.1.1.1 $
 */
public interface MessageCache {
	/**
	 * Gets a message that was previously <code>put</code> into this object.   
	 * 
	 * @param msgid
	 * @return null if the message was not previously put or if the message has expired out of the cache.
	 */
	public ActiveMQMessage get(String msgid);

	/**
	 * Puts a message into the cache.
	 * 
	 * @param messageID
	 * @param message
	 */
	public void put(String messageID, ActiveMQMessage message);

	/**
	 * Remvoes a message from the cache.
	 * 
	 * @param messageID
	 */
	public void remove(String messageID);

    /**
     * Lets a cache know it will not be used any further and that it can release 
     * aquired resources
     */
    public void close();
	
}