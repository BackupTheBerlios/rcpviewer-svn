/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service;

import org.activemq.message.ActiveMQMessage;
import org.activemq.message.MessageAck;

import javax.jms.JMSException;

/**
 * A MessageContainer holds the messages for a particular destination
 *
 * @version $Revision: 1.1.1.1 $
 */
public interface MessageContainer extends Service {

    /**
     * @return the adminstration interface of the container.
     */
    public MessageContainerAdmin getMessageContainerAdmin();

    /**
     * @return the destinationName of the Container
     */
    public String getDestinationName();

    /**
     * Add an ActiveMQMessage to the message container
     *
     * @param msg
     * @throws JMSException
     */
    public void addMessage(ActiveMQMessage msg) throws JMSException;

    /**
     * Delete a message - if no
     *
     * @param messageIdentity
     * @param ack
     * @throws JMSException
     */
    public void delete(MessageIdentity messageIdentity, MessageAck ack) throws JMSException;

    /**
     * Return the ActiveMQMessage that matches the Id
     *
     * @param messageIdentity
     * @return the message or null
     * @throws JMSException
     */
    public ActiveMQMessage getMessage(MessageIdentity messageIdentity) throws JMSException;

    /**
     * Register that a consumer will be interested in this message
     *
     * @param messageIdentity
     * @throws javax.jms.JMSException
     */
    public void registerMessageInterest(MessageIdentity messageIdentity) throws JMSException;

    /**
     * A message consumer calls this when it's no longer interested in a message
     * so that we know when we can delete (or archive) it
     *
     * @param ack
     * @throws JMSException
     */
    public void unregisterMessageInterest(MessageIdentity ack) throws JMSException;

    /**
     * Returns whether or not this container contains the given message identity which
     * provides an optimisation over getMessage() where the message does not need to be loaded.
     *
     * @param messageIdentity
     * @return true if the container contains the given message
     */
    public boolean containsMessage(MessageIdentity messageIdentity) throws JMSException;
    
    /**
     * returns true if this container is a dead letter queue
     * @return
     */
    public boolean isDeadLetterQueue();

}
