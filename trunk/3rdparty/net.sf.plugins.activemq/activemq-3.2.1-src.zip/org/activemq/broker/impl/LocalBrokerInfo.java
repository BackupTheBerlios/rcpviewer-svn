/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.broker.impl;

import java.util.Properties;

import org.activemq.message.BrokerInfo;

/**
 * Information about a connected Broker
 */

public class LocalBrokerInfo extends BrokerInfo{

    DefaultBroker broker;
    /**
     * Constructor
     * 
     * @param broker
     */
    protected LocalBrokerInfo(DefaultBroker broker){
        this.broker = broker;
    }
    /**
     * @param newBrokerName
     *            The brokerName to set.
     */
    public void setBrokerName(String newBrokerName){
        if(broker.isStarted()){
            throw new RuntimeException("Cannot change the name of the broker after it's started");
        }
        if(broker.getBrokerContainer()!=null){
            broker.getBrokerContainer().doDeRegistration(getBrokerName());
            broker.getBrokerContainer().doRegistration(newBrokerName);
        }
        super.setBrokerName(newBrokerName);
    }

    /**
     * @param newClusterName
     *            The clusterName to set.
     */
    public void setClusterName(String newClusterName){
        if(broker.isStarted()){
            throw new RuntimeException("Cannot change the cluster of the broker after it's started");
        }
        super.setClusterName(newClusterName);
    }

}
