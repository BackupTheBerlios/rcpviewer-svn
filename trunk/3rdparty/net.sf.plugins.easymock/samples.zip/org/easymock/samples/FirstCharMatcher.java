/*
 * Copyright (c) 2001-2004 OFFIS. This program is made available under the terms of
 * the MIT License.
 */
package org.easymock.samples;

import org.easymock.AbstractMatcher;

public class FirstCharMatcher extends AbstractMatcher {
    protected boolean argumentMatches(Object expected, Object actual) {
		if (expected instanceof String) {
			expected = first(expected);
		}
		if (actual instanceof String) {
			actual = first(actual);
		}
        return super.argumentMatches(expected, actual);
    }

    protected String argumentToString(Object argument) {
        if (argument instanceof String) {
            argument=first(argument) + "...";
        }
        return super.argumentToString(argument);
    }

    private String first(Object expected) {
        String first = (String) expected;
        if (first == null || first.length() == 0) {
            return first;
        }
        return first.substring(0, 1);
    }
}
