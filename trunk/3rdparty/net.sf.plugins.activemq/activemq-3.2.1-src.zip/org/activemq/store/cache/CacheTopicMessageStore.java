/**
 * 
 * Copyright 2004 Hiram Chirino
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.store.cache;

import javax.jms.JMSException;

import org.activemq.message.ConsumerInfo;
import org.activemq.service.MessageIdentity;
import org.activemq.service.SubscriberEntry;
import org.activemq.store.RecoveryListener;
import org.activemq.store.TopicMessageStore;

/**
 * A MessageStore that uses an in memory cache to speed up getMessage() method calls.
 *
 * @version $Revision: 1.1.1.1 $
 */
public class CacheTopicMessageStore extends CacheMessageStore implements TopicMessageStore {

    private final TopicMessageStore longTermStore;

    public CacheTopicMessageStore(CachePersistenceAdapter adapter, TopicMessageStore longTermStore, MessageCache cache) {
        super(adapter, longTermStore, cache);
        this.longTermStore = longTermStore;
    }

    //
    // The following methods just delegate to the longTermStore.
    //
    public void setLastAcknowledgedMessageIdentity(String subscription, MessageIdentity messageIdentity) throws JMSException {
        longTermStore.setLastAcknowledgedMessageIdentity(subscription, messageIdentity);
    }

    public MessageIdentity getLastestMessageIdentity() throws JMSException {
        return longTermStore.getLastestMessageIdentity();
    }

    public synchronized void recoverSubscription(String subscriptionId, MessageIdentity lastDispatchedMessage, RecoveryListener listener) throws JMSException {
        longTermStore.recoverSubscription(subscriptionId, lastDispatchedMessage, listener);
    }

    public void setSubscriberEntry(ConsumerInfo info, SubscriberEntry subscriberEntry) throws JMSException {
        longTermStore.setSubscriberEntry(info, subscriberEntry);
    }

    public SubscriberEntry getSubscriberEntry(ConsumerInfo info) throws JMSException {
        return longTermStore.getSubscriberEntry(info);
    }

    public void incrementMessageCount(MessageIdentity messageId) throws JMSException {
        longTermStore.incrementMessageCount(messageId);
    }

    public void decrementMessageCountAndMaybeDelete(MessageIdentity msgId) throws JMSException {
        longTermStore.decrementMessageCountAndMaybeDelete(msgId);
    }

    public void deleteSubscription(String subcription) throws JMSException {
        longTermStore.deleteSubscription(subcription);
    }

}
