/*
 * Created on Apr 22, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package org.activemq.service;

import javax.jms.JMSException;
import org.activemq.message.ActiveMQMessage;

/**
 * A manager of MessageContainer instances
 */
public interface QueueMessageContainerManager extends MessageContainerManager {
    
    /**
     * Add a message to a dead letter queue
     * @param deadLetterName
     * @param message
     * @throws JMSException
     */
    public void sendToDeadLetterQueue(String deadLetterName,ActiveMQMessage message) throws JMSException;
    
}