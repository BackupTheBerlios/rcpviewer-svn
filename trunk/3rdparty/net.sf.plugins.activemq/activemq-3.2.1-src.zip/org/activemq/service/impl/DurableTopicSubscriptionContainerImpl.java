/**
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service.impl;

import org.activemq.broker.BrokerClient;
import org.activemq.filter.Filter;
import org.activemq.message.ConsumerInfo;
import org.activemq.service.DeadLetterPolicy;
import org.activemq.service.Dispatcher;
import org.activemq.service.Subscription;
import org.activemq.service.RedeliveryPolicy;

import java.util.Map;

/**
 * An implemenation of {@link SubscriptionContainerImpl} for durable topic
 * subscriptions
 *
 * @version $Revision: 1.1.1.1 $
 */
public class DurableTopicSubscriptionContainerImpl extends SubscriptionContainerImpl {
    
    public DurableTopicSubscriptionContainerImpl(RedeliveryPolicy redeliveryPolicy,DeadLetterPolicy deadLetterPolicy) {
        super(redeliveryPolicy,deadLetterPolicy);
    }

    public DurableTopicSubscriptionContainerImpl(Map subscriptions, RedeliveryPolicy redeliveryPolicy,DeadLetterPolicy deadLetterPolicy) {
        super(subscriptions, redeliveryPolicy,deadLetterPolicy);
    }

    protected Subscription createSubscription(Dispatcher dispatcher, BrokerClient client,ConsumerInfo info, Filter filter) {
        return new DurableTopicSubscription(dispatcher,client, info, filter, getRedeliveryPolicy(),getDeadLetterPolicy());
    }

}
