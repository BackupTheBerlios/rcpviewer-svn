/** 
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service.impl;

import java.util.ArrayList;
import java.util.Iterator;

import javax.transaction.xa.XAException;

import org.activemq.service.Transaction;
import org.activemq.service.TransactionTask;

/**
 * Keeps track of all the actions the need to be done when
 * a transaction does a commit or rollback.
 *
 * @version $Revision: 1.1.1.1 $
 */
public abstract class AbstractTransaction implements Transaction {

    static final public byte START_STATE = 0;      // can go to: 1,2,3
    static final public byte IN_USE_STATE = 1;     // can go to: 2,3
    static final public byte PREPARED_STATE = 2;   // can go to: 3
    static final public byte FINISHED_STATE = 3;


    private ArrayList prePrepareTasks = new ArrayList();
    private ArrayList postCommitTasks = new ArrayList();
    private ArrayList postRollbackTasks = new ArrayList();
    private byte state = START_STATE;

    public byte getState() {
        return state;
    }

    public void setState(byte state) {
        this.state = state;
    }

    public void addPostCommitTask(TransactionTask r) {
        postCommitTasks.add(r);
        if (state == START_STATE) {
            state = IN_USE_STATE;
        }
    }

    public void addPostRollbackTask(TransactionTask r) {
        postRollbackTasks.add(r);
        if (state == START_STATE) {
            state = IN_USE_STATE;
        }
    }

    public void addPrePrepareTask(TransactionTask r) {
        prePrepareTasks.add(r);
        if (state == START_STATE) {
            state = IN_USE_STATE;
        }
    }

    public void prePrepare() throws Throwable {

        // Is it ok to call prepare now given the state of the
        // transaction?
        switch (state) {
            case START_STATE:
            case IN_USE_STATE:
                break;
            default:
                XAException xae = new XAException("Prepare cannot be called now.");
                xae.errorCode = XAException.XAER_PROTO;
                throw xae;
        }

        // Run the prePrepareTasks
        for (Iterator iter = prePrepareTasks.iterator(); iter.hasNext();) {
            TransactionTask r = (TransactionTask) iter.next();
            r.execute();
        }
    }

    protected void postCommit() throws Throwable {
        // Run the postCommitTasks
        for (Iterator iter = postCommitTasks.iterator(); iter.hasNext();) {
            TransactionTask r = (TransactionTask) iter.next();
            r.execute();
        }
    }

    public void postRollback() throws Throwable {
        // Run the postRollbackTasks
        for (Iterator iter = postRollbackTasks.iterator(); iter.hasNext();) {
            TransactionTask r = (TransactionTask) iter.next();
            r.execute();
        }
    }

    public String toString() {
        return super.toString() + "[prePrepares=" + prePrepareTasks + "; postCommits=" + postCommitTasks
                + "; postRollbacks=" + postRollbackTasks + "]";
    }

}
