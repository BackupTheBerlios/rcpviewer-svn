package org.activemq.filter;

import java.io.ByteArrayInputStream;
import java.io.StringReader;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.xpath.CachedXPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.InputSource;

public class XalanXPathEvaluator implements XPathExpression.XPathEvaluator {
    
    private final String xpath;

    public XalanXPathEvaluator(String xpath) {
        this.xpath = xpath;
    }
    
    public boolean evaluate(Message message) throws JMSException {
        if( message instanceof TextMessage ) {
            String text = ((TextMessage)message).getText();
            return evaluate(text);                
        } else if ( message instanceof BytesMessage ) {
            BytesMessage bm = (BytesMessage) message;
            byte data[] = new byte[(int) bm.getBodyLength()];
            bm.readBytes(data);
            return evaluate(data);
        }            
        return false;
    }

    private boolean evaluate(byte[] data) {
        try {
            
            InputSource inputSource = new InputSource(new ByteArrayInputStream(data));
            
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            DocumentBuilder dbuilder = factory.newDocumentBuilder();
            Document doc = dbuilder.parse(inputSource);
            
            CachedXPathAPI cachedXPathAPI = new CachedXPathAPI();
            NodeIterator iterator = cachedXPathAPI.selectNodeIterator(doc,xpath);
            return iterator.nextNode()!=null;
            
        } catch (Throwable e) {
            return false;
        }
    }

    private boolean evaluate(String text) {
        try {
            InputSource inputSource = new InputSource(new StringReader(text));
            
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            DocumentBuilder dbuilder = factory.newDocumentBuilder();
            Document doc = dbuilder.parse(inputSource);
            
            // We should associated the cachedXPathAPI object with the message being evaluated
            // since that should speedup subsequent xpath expressions.
            CachedXPathAPI cachedXPathAPI = new CachedXPathAPI();
            NodeIterator iterator = cachedXPathAPI.selectNodeIterator(doc,xpath);
            return iterator.nextNode()!=null;
        } catch (Throwable e) {
            return false;
        }
    }
}
