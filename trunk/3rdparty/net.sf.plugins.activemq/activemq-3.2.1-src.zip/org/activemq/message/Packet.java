/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

/**
 * Denotes an object that can be serialized/deserailized using a PacketReader or PacketWriter
 */

public interface Packet {

    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType();

    /**
     * @return the unique id for this Packet
     */

    public short getId();

    /**
     * Set the unique id for this Packet
     *
     * @param newId
     */

    public void setId(short newId);

    /**
     * @return true if a Recipt is required
     */
    public boolean isReceiptRequired();

    /**
     * @return true if this is a Receipt
     */
    public boolean isReceipt();

    /**
     * Set if a Recipt if required on receiving this Packet
     *
     * @param value
     */

    public void setReceiptRequired(boolean value);

    /**
     * Retrieve if a JMS Message type or not
     *
     * @return true if it is a JMS Message
     */
    public boolean isJMSMessage();

    /**
     * Get a hint about how much memory this Packet is consuming
     *
     * @return an aproximation of the current memory used by this instance
     */
    public int getMemoryUsage();

    /**
     * Set a hint about how mujch memory this packet is consuming
     *
     * @param newMemoryUsage
     */
    public void setMemoryUsage(int newMemoryUsage);

    /**
     * Increment reference count for bounded memory collections
     *
     * @return the incremented reference value
     * @see org.activemq.io.util.MemoryBoundedQueue
     */
    public int incrementMemoryReferenceCount();


    /**
     * Decrement reference count for bounded memory collections
     *
     * @return the decremented reference value
     * @see org.activemq.io.util.MemoryBoundedQueue
     */
    public int decrementMemoryReferenceCount();

    /**
     * @return the current reference count for bounded memory collections
     * @see org.activemq.io.util.MemoryBoundedQueue
     */
    public int getMemoryUsageReferenceCount();

    /**
     * As the packet passes through the broker add the broker to the visited list
     *
     * @param brokerName the name of the broker
     */
    public void addBrokerVisited(String brokerName);
    
    /**
     * clear list of brokers visited
     */
    public void clearBrokersVisited();


    /**
     * test to see if the named broker has already seen this packet
     *
     * @param brokerName the name of the broker
     * @return true if the packet has visited the broker
     */
    public boolean hasVisited(String brokerName);

    /**
     * @return Returns the brokersVisited.
     */
    public String getBrokersVisitedAsString();

    /**
     * Unspecified Packet type
     */
    public static final int NOT_SET = 0;

    /**
     * ActiveMQMessage object
     */
    public static final int ACTIVEMQ_MESSAGE = 6;

    /**
     * ActiveMQTextMessage object
     */

    public static final int ACTIVEMQ_TEXT_MESSAGE = 7;

    /**
     * ActiveMQObjectMessage object
     */

    public static final int ACTIVEMQ_OBJECT_MESSAGE = 8;

    /**
     * ActiveMQBytesMessage
     */

    public static final int ACTIVEMQ_BYTES_MESSAGE = 9;

    /**
     * ActiveMQStreamMessage object
     */

    public static final int ACTIVEMQ_STREAM_MESSAGE = 10;

    /**
     * ActiveMQMapMessage object
     */

    public static final int ACTIVEMQ_MAP_MESSAGE = 11;

    /**
     * Message acknowledge
     */
    public static final int ACTIVEMQ_MSG_ACK = 15;

    /**
     * Recipt message
     */

    public static final int RECEIPT_INFO = 16;

    /**
     * Consumer Infomation
     */

    public static final int CONSUMER_INFO = 17;

    /**
     * Producer Info
     */

    public static final int PRODUCER_INFO = 18;

    /**
     * Transaction info
     */

    public static final int TRANSACTION_INFO = 19;

    /**
     * XA Transaction info
     */

    public static final int XA_TRANSACTION_INFO = 20;

    /**
     * Broker infomation message
     */

    public static final int ACTIVEMQ_BROKER_INFO = 21;

    /**
     * Connection info message
     */

    public static final int ACTIVEMQ_CONNECTION_INFO = 22;


    /**
     * Session Info message
     */
    public static final int SESSION_INFO = 23;

    /**
     * Durable Unsubscribe message
     */

    public static final int DURABLE_UNSUBSCRIBE = 24;


    /**
     * A receipt with an Object reponse.
     */
    public static final int RESPONSE_RECEIPT_INFO = 25;


    /**
     * A receipt with an Integer reponse.
     */
    public static final int INT_RESPONSE_RECEIPT_INFO = 26;

    /**
     * Infomation about the Capacity for more Messages for either Connection/Broker
     */
    public static final int CAPACITY_INFO = 27;

    /**
     * Request infomation  about the current capacity
     */
    public static final int CAPACITY_INFO_REQUEST = 28;
    
    /**
     * Infomation about the wire format expected
     */
    public static final int WIRE_FORMAT_INFO = 29;

    /**
     * Keep-alive message
     */
    public static final int KEEP_ALIVE = 30;
    
    /**
     * A command to the Broker Admin
     */
    public static final int BROKER_ADMIN_COMMAND = 31;
    
    /**
     * transmit cached values for the wire format
     */
    public static final int CACHED_VALUE_COMMAND = 32;

    /**
     * transmit cached values for the wire format
     */
    public static final int CLEANUP_CONNECTION_INFO = 33;
}
