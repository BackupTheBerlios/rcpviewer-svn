/*
 * Copyright (c) 2005 Your Corporation. All Rights Reserved.
 */
package org.activemq.transport.stomp;

import org.activemq.message.ConnectionInfo;

import java.io.DataInput;
import java.io.IOException;
import java.util.Properties;

class Disconnect implements Command
{
    private final String clientId;

    public Disconnect(String clientId)
    {
        this.clientId = clientId;
    }

    public PacketEnvelope build(String line, DataInput in) throws IOException
    {
        ConnectionInfo ci = new ConnectionInfo();
        ci.setClientId(clientId);
        ci.setClosed(true);
        ci.setStarted(false);
        while (in.readByte() != 0) {}
        return new PacketEnvelope(ci, new Properties());
    }
}
