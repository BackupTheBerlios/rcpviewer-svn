/** 
 * 
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.transport.activeio;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.jms.JMSException;

import org.activeio.AsynchChannel;
import org.activeio.ChannelFactory;
import org.activemq.io.WireFormat;
import org.activemq.transport.TransportChannel;
import org.activemq.transport.TransportChannelFactorySupport;
import org.activemq.util.JMSExceptionHelper;

/**
 * A tcp implementation of a TransportChannelFactory
 *
 * @version $Revision: 1.1.1.1 $
 */
public class ActiveIOTransportChannelFactory extends TransportChannelFactorySupport {

    /**
     * Create a Channel to a remote Node - e.g. a Broker
     *
     * @param wireFormat
     * @param remoteLocation
     * @return the TransportChannel bound to the remote node
     * @throws JMSException
     */
    public TransportChannel create(WireFormat wireFormat, URI remoteLocation) throws JMSException {
        AsynchChannel asynchChannel = createAsynchChannel(remoteLocation);
        ActiveIOTransportChannel channel = new ActiveIOTransportChannel(wireFormat, asynchChannel);
        return populateProperties(channel, remoteLocation);
    }

    /**
     * Create a Channel to a remote Node - e.g. a Broker
     *
     * @param wireFormat
     * @param remoteLocation
     * @param localLocation  -
     *                       e.g. local InetAddress and local port
     * @return the TransportChannel bound to the remote node
     * @throws JMSException
     */
    public TransportChannel create(WireFormat wireFormat, URI remoteLocation, URI localLocation) throws JMSException {
        AsynchChannel asynchChannel = createAsynchChannel(remoteLocation);
        ActiveIOTransportChannel channel = new ActiveIOTransportChannel(wireFormat, asynchChannel);
        return populateProperties(channel, remoteLocation);
    }

    public boolean requiresEmbeddedBroker() {
        return false;
    }

    /**
     * @param remoteLocation
     * @return
     * @throws JMSException
     */
    private AsynchChannel createAsynchChannel(URI remoteLocation) throws JMSException {
        try {
            remoteLocation = URIConverter.convert(remoteLocation);
            AsynchChannel channel = new ChannelFactory().openAsynchChannel(remoteLocation);
            // If the channel is not allready buffered.. lets buffer it.
            //if( channel.narrow(WriteBufferedAsynchChannel.class)==null && channel.narrow(WriteBufferedSynchChannel.class)==null ) {
            //    channel = new WriteBufferedAsynchChannel(channel);
            //}
            return channel;
        } catch (IOException e) {
            throw JMSExceptionHelper.newJMSException(e.getMessage(), e);
        } catch (URISyntaxException e) {
            throw JMSExceptionHelper.newJMSException(e.getMessage(), e);
        }
    }

}