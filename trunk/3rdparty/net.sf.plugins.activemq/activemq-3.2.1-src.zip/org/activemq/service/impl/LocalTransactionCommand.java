/**
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.service.impl;

import java.util.Map;

import javax.transaction.xa.XAException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.activemq.store.TransactionStore;

/**
 * @version $Revision: 1.1.1.1 $
 */
public class LocalTransactionCommand extends AbstractTransaction {
    private static final Log log = LogFactory.getLog(LocalTransactionCommand.class);

    private Map localTxs;
    private String txid;

    private final TransactionStore transactionStore;


    public LocalTransactionCommand(Map localTxs, String txid, TransactionStore transactionStore) {
        this.localTxs = localTxs;
        this.txid = txid;
        this.transactionStore = transactionStore;
    }

    public void commit(boolean onePhase) throws XAException {
        // Get ready for commit.
        try {
            prePrepare();
        }
        catch (XAException e) {
            throw e;
        }
        catch (Throwable e) {
            log.warn("COMMIT FAILED: ", e);
            rollback();
            // Let them know we rolled back.
            XAException xae = new XAException("COMMIT FAILED: Transaction rolled back.");
            xae.errorCode = XAException.XA_RBOTHER;
            xae.initCause(e);
            throw xae;
        }

        setState(AbstractTransaction.FINISHED_STATE);
        localTxs.remove(txid);
        transactionStore.commit(getTransactionId(), false);
        
        try {
            postCommit();
        }
        catch (Throwable e) {
            // I guess this could happen.  Post commit task failed
            // to execute properly.
            log.warn("POST COMMIT FAILED: ", e);
            XAException xae = new XAException("POST COMMIT FAILED");
            xae.errorCode = XAException.XAER_RMERR;
            xae.initCause(e);
            throw xae;
        }
    }

    public void rollback() throws XAException {

        setState(AbstractTransaction.FINISHED_STATE);
        localTxs.remove(txid);
        transactionStore.rollback(getTransactionId());

        try {
            postRollback();
        }
        catch (Throwable e) {
            log.warn("POST ROLLBACK FAILED: ", e);
            XAException xae = new XAException("POST ROLLBACK FAILED");
            xae.errorCode = XAException.XAER_RMERR;
            xae.initCause(e);
            throw xae;
        }
    }

    public int prepare() throws XAException {
        XAException xae = new XAException("Prepare not implemented on Local Transactions.");
        xae.errorCode = XAException.XAER_RMERR;
        throw xae;
    }

    public boolean isXaTransacted() {
        return false;
    }

    public Object getTransactionId() {
        return txid;
    }

}
